﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Globalization;

namespace Odev41.TagHelpers
{
    public class KucukTagHelper : TagHelper
    {
        public string Kelime { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            bool uyumlu = KucukUnluUyumunaUyarMi(Kelime);
            if (uyumlu)
                output.Content.SetContent(Kelime + " kelimesi küçük ünlü uyumuna uyar.");
            else
                output.Content.SetContent(Kelime + " kelimesi küçük ünlü uyumuna uymaz.");
        }

        private bool KucukUnluUyumunaUyarMi(string kelime)
        {
            char[] eUunluler = { 'a', 'e', 'ı', 'i' };
            char[] iUunluler = { 'o', 'ö', 'u', 'ü' };

            bool eVar = kelime.Any(c => eUunluler.Contains(char.ToLowerInvariant(c)));
            bool iVar = kelime.Any(c => iUunluler.Contains(char.ToLowerInvariant(c)));

            return (eVar && !iVar) || (!eVar && iVar);


            //char[] dizi1 = { 'a', 'e', 'ı', 'i' };
            //char[] dizi2 = { 'o', 'ö', 'u', 'ü' };
            //char[] dizi3 = { 'a', 'e', 'u', 'ü' };

            //bool dizi1Var = kelime.Any(c => dizi1.Contains(char.ToLowerInvariant(c)));
            //bool dizi2Var = kelime.Any(c => dizi2.Contains(char.ToLowerInvariant(c)));
            //bool dizi3Var = kelime.Any(c => dizi3.Contains(char.ToLowerInvariant(c)));

            //if (dizi1Var && !dizi2Var)
            //    return true;
            //else if(dizi2Var && dizi3Var)
            //    return true;
            //else 
            //    return false;


        }
    }
}
