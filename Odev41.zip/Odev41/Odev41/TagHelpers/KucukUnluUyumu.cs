﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Odev41.TagHelpers
{
    [HtmlTargetElement("uyum")]
    public class KucukUnluUyumu:TagHelper
    {
        public string kelime { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName ="div";
            output.Attributes.SetAttribute("class", "alert alert-info");
            output.Content.SetContent(KKUyumu());
        }

        private string KKUyumu()
        {
            string harfler1 = "aeıi";
            string harfler2 = "oöuü";
            string harfler3 = "aeuü";

            string sesli = new String(kelime.Where(x => (harfler1 + harfler2 + harfler3).Contains(x)).ToArray());

            for (int i = 0; i < sesli.Length-1; i++)
            {
                if (harfler1.Contains(sesli[i]) && harfler1.Contains(sesli[i + 1]))
                    continue;
                if (harfler2.Contains(sesli[i]) && harfler3.Contains(sesli[i + 1]))
                    continue;
                if("uü".Contains(sesli[i]) && "ae".Contains(sesli[i + 1]))
                    continue;
                return "Uymaz";
            }
            return "Uyar";

            
        }
    }


}
