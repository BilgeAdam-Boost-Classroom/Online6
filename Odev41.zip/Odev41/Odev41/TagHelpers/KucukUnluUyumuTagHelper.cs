﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Runtime.CompilerServices;

namespace Odev41.TagHelpers
{
    public class KucukUnluUyumuTagHelper : TagHelper
    {
        public string Kelime { get; set; } = null!;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if (KucukUnluyeUygunMu(Kelime))
                output.Content.SetContent(Kelime + " Küçük Ünlü Uyumuna Uygundur.");
            else
                output.Content.SetContent(Kelime + " Küçük Ünlü Uyumuna Uymaz.");
        }

        public bool KucukUnluyeUygunMu(string kelime)
        {
            string duzUnlu = "aeıi";
            string yuvarlakUnlu = "oöuü";
            string yuvarlakSonrasi = "aeuü";

            List<char> kelimedekiSesliler = new List<char>();

            foreach (char c in kelime)
            {
                if (duzUnlu.Contains(c) || yuvarlakUnlu.Contains(c))
                    kelimedekiSesliler.Add(c);
            }

            if (kelimedekiSesliler.Count == 0) { return false; }

            for (int i = 0; i < kelimedekiSesliler.Count() - 1; i++)
            {
                if (duzUnlu.Contains(kelimedekiSesliler[i]) && !duzUnlu.Contains(kelimedekiSesliler[i + 1]))
                    return false;
                if (yuvarlakUnlu.Contains(kelimedekiSesliler[i]) && !yuvarlakSonrasi.Contains(kelimedekiSesliler[i + 1]))
                    return false;
            }
            return true;
        }
    }
}
