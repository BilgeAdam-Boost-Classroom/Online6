﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System;
using System.Linq;

namespace Odev41.CustomTagHelpers
{
    public class KucukUnluUyumuTagHelper : TagHelper
    {
        public string Kelime { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            if (KucukUnluUyumuVarMi(Kelime))
            {
                output.Content.SetContent("Küçük Ünlü Uyumuna Uyuyor.");
                output.Attributes.SetAttribute("style", "color: green");
            }
            else
            {
                output.Content.SetContent("Küçük Ünlü Uyumuna Uymuyor.");
                output.Attributes.SetAttribute("style", "color: red");
            }
        }

        private bool KucukUnluUyumuVarMi(string kelime)
        {
            char[] genisUnluler = { 'a', 'e', 'ı', 'i' };
            char[] darUnluler = { 'o', 'ö', 'u', 'ü' };

            if (!string.IsNullOrEmpty(kelime))
            {
                kelime = kelime.ToLower();

                bool genisUyum = genisUnluler.Any(genis => kelime.Contains(genis) &&
                                                            kelime.SkipWhile(c => c != genis).Skip(1).Any(sonraki =>
                                                                genisUnluler.Contains(sonraki) && sonraki != 'a' && sonraki != 'e'));

                bool darUyum = darUnluler.Any(dar => kelime.Contains(dar) &&
                                                     kelime.SkipWhile(c => c != dar).Skip(1).Any(sonraki =>
                                                         darUnluler.Contains(sonraki) && (sonraki == 'a' || sonraki == 'e')));

                return genisUyum && darUyum;
            }

            return true;
        }
    }
}
