﻿namespace Odev41.Models
{
    public class KelimeViewModel
    {
        public string Kelime { get; set; }
    }
}
