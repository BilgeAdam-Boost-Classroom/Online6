﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Odev41.TagHelpers
{
    [HtmlTargetElement("kucuk-unlu")]
    public class KucukUnluUyumuTagHelper : TagHelper
    {
        public string Kelime { get; set; }
        public bool uyumluMu { get; set; }
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";


            char[] duzUnlu = { 'a', 'e', 'ı', 'i' };
            char[] yuvarlakUnlu = { 'o', 'ö', 'u', 'ü' };

            if (IceriyorMu(Kelime, duzUnlu) && IceriyorMu(Kelime, yuvarlakUnlu))
            {
                uyumluMu = false;
            }
            else if (IceriyorMu(Kelime, duzUnlu) || IceriyorMu(Kelime, yuvarlakUnlu))
            {
                uyumluMu = true;
            }
            else
            {
                uyumluMu = false;
            }


            if (uyumluMu)
            {
                output.Content.SetHtmlContent($"{Kelime} kelimesi büyük ünlü uyumuna uyar.");
            }
            else
            {
                output.Content.SetHtmlContent($"{Kelime} kelimesi büyük ünlü uyumuna uymaz.");
            }
        }

        static bool IceriyorMu(string kelime, char[] harfler)
        {
            foreach (char harf in harfler)
            {
                if (kelime.Contains(harf.ToString(), StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
