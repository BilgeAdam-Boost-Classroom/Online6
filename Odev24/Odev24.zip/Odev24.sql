﻿-- 1) Employees tablosundan Country’si 
-- UK veya Turkey olanları getiren 
-- SQL sorgusunu yazınız.

select * from Employees
where Country in ('UK', 'Turkey')

-- 2) Employees tablosundan Region’ı 
-- NULL olanları getiren SQL sorgusunu yazınız.

select * from Employees
where Region is null

-- 3) Employees tablosundan LastName’i Fuller
-- veya King olanları getiren SQL sorgusunu yazınız.

select * from Employees
where LastName in ('Fuller','King')


-- 4) Products tablosundan UnitPrice’ı 15’ten büyük olup
-- Discontinued’u 0 olanları veya 
-- UnitsOnOrder ‘ ı 70’ten küçük olup 
-- ReorderLevel’ı 5’ten büyük olanları getiren SQL sorgusunu yazınız.


select * from Products
where (UnitPrice > 15 and Discontinued = 0)
OR (UnitsOnOrder < 70 and ReorderLevel > 5) 

-- 5) Products tablosundan
-- CategoryID’si 1,4 veya 8 olanların 
-- SADECE ProductName’ini ve CategoryID’sini 
-- getiren SQL sorgusunu yazınız.

select CategoryID, ProductName from Products
where CategoryID in (1, 4, 8)

-- 6) Suppliers tablosundan 
-- Fax’ı NULL olan veya City’si New Orleans olanların 
-- SADECE Address’ini getiren SQL sorgusunu yazınız.

select Address from Suppliers
where Fax is null or city = N'New Orleans'

-- 7) Region tablosundaki bütün verileri
-- getiren SQL sorgusunu yazınız. 
-- (Kolon isimleri şu şekilde görüntülenmelidir: 
-- RegionID ➔ BolgeNo, RegionDescription➔BolgeTanimi)

select RegionID BolgeNo, RegionDescription BolgeTanimi
from Region

-- 8) OrderDetails tablosundan 
-- Discount’u sıfırdan farklı olanları veya 
-- Quantity’si 10 ile 40 arasında olanları 
-- (sınırlar dahil) getiren SQL sorgusunu yazınız.

select * from [Order Details]
where Discount <> 0
OR (Quantity >= 10 and Quantity <=40) 

-- 9) Employees tablosundaki 
-- bütün Title’ları TEKRARSIZ BİR ŞEKİLDE 
-- ve Gorev ismiyle getiren 
-- SQL sorgusunu yazınız.

select distinct Title as Gorev from Employees