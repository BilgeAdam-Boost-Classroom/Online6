﻿namespace Odev22
{
    internal class Program
    {
        /*
        * İstenildiği kadar tam sayıyı parametre olarak alan ve bu sayıların toplamını döndüren bir metot yazınız. (ör: sayılar a,b,c ve d ise a+b+c+d hesaplanmalı ve döndürülmelidir)  

        * İstenildiği kadar tam sayıyı parametre olarak alan ve bu sayıların farklarını döndüren (ör: sayılar a,b,c ve d ise a-b-c-d hesaplanmalı ve döndürülmelidir) bir metod yazınız. 

        * İstenildiği kadar tam sayıyı parametre olarak alan ve bu sayıların çarpımlarını döndüren (ör: sayılar a,b,c ve d ise a*b*c*d hesaplanmalı ve döndürülmelidir) bir metod yazınız. 

        * Islem adında bir metot yazınız. Bu metot, yukarıda belirtilen metotlardan herhangi birisini ve işlem yapılacak sayıları parametre olarak almalıdır. Dolayısıyla gönderilen metoda göre sayılara yapılacak işlem değişmelidir. 
         */
        public delegate int IslemDlg(params int[] sayi);
        public static int Islem(IslemDlg islem, int[] sayi)
        {
            return islem(sayi);
        }
        static void Main(string[] args)
        {
            int[] sayilar = { 1, 2, 3, 4 };
            Console.WriteLine(Islem(Topla, sayilar));
            Console.WriteLine(Islem(Cikar, sayilar));
            Console.WriteLine(Islem(Carp, sayilar));
            Console.ReadLine();
        }

        public static int Topla(params int[] sayi)
        {
            int toplam = 0;
            foreach (int i in sayi)
                toplam += i;
            return toplam;
        }

        public static int Cikar(params int[] sayi)
        {
            int ilksayi = sayi[0];
            for (int i = 1; i < sayi.Length; i++)
                ilksayi -= sayi[i];
            return ilksayi;
        }
        public static int Carp(params int[] sayi)
        {
            int carpim = 1;
            foreach (int i in sayi)
                carpim *= i;
            return carpim;
        }

        
    }
}