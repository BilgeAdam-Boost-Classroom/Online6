﻿namespace Odev22
{
    internal class Program
    {
        public delegate int Islemler(int[] sayilar);
        
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            int[] islemSayilari = { 2, 4, 12, 47 };
            Islem(Toplama, islemSayilari );
            Islem(Cikarma, islemSayilari );
            Islem(Carpma, islemSayilari );
            



            int Toplama(int[] sayilar)
            {
                int toplam = 0;
                foreach (int sayi in sayilar)
                {
                    toplam += sayi;
                }
                return toplam;
            }

            static void Islem(Islemler islem, int[] sayilar)
            {
                Console.WriteLine(islem(sayilar));
            }


            int Cikarma(int[] sayilar)
            {
                int sonuc = sayilar[0];
                for (int i = 1; i < sayilar.Length; i++)
                {
                    sonuc -= sayilar[i];
                }
                return sonuc;
            }

            int Carpma(int[] sayilar)
            {
                int carpim = 1;
                foreach (int sayi in sayilar)
                {
                    carpim *= sayi;
                }
                return carpim;
            }

            Console.ReadKey();
        }

        
    }
}