﻿namespace Odev19_CerenKaya
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DateTime tarih = new DateTime(2023, 12, 09);
            Cihaz c1 = new Cihaz("Iphone15", 49999,tarih);
            c1.BilgileriGoster();
            Console.ReadKey();

        }
    }
}