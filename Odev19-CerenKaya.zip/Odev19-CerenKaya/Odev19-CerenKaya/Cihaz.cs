﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev19_CerenKaya
{
    internal class Cihaz
    {
        Random rnd = new Random();
        public Cihaz(string ad,int fiyat,DateTime uretimTarihi)
        {
            Ad = ad;
            Fiyat = fiyat;
            UretimTarihi = uretimTarihi;
            SeriNumarasi = SeriNumarasiUret();

        }
        public string Ad { get; set; }

        public int Fiyat { get; set; }
        public int SeriNumarasi { get; private set; }
        public DateTime UretimTarihi { get; set; }

        private int SeriNumarasiUret()
        {
            int sayi = rnd.Next(1000, 10000);
            return sayi;
        }

        public void BilgileriGoster()
        {
            Console.WriteLine("Ad:  "+Ad+Environment.NewLine+"Fiyat:  "+Fiyat+Environment.NewLine+"Üretim Tarihi: "+UretimTarihi+Environment.NewLine+"serino: "+ SeriNumarasi);

        }
    }


}
