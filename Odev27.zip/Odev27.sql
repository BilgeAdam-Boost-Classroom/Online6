CREATE DATABASE BilgeAdam6Db;
USE BilgeAdam6Db;

CREATE TABLE Ogretmenler(
OgretmenId INT PRIMARY KEY IDENTITY,
OgretmenAd  NVARCHAR(50) NOT NULL,
OgretmenSoyad  NVARCHAR(50) NOT NULL);

CREATE TABLE Siniflar(
SinifId INT PRIMARY KEY IDENTITY,
SinifAd NVARCHAR(10) NOT NULL UNIQUE,
OgretmenId INT FOREIGN KEY (OgretmenId) REFERENCES Ogretmenler(OgretmenId) NULL
);

INSERT INTO Ogretmenler(OgretmenAd, OgretmenSoyad) VALUES
('Salih', 'Y�lmaz'),
('Burcu', 'Demir'),
('Nazmi', 'Kaya'),
('Pelin', '�elik'),
('Remzi', 'Ayd�n');

INSERT INTO Siniflar (SinifAd, OgretmenId) VALUES 
('A', 1),
('B', 2), 
('C', 3), 
('D', 5),
('E', 5),
('F', 5),
('G', NULL),
('H', NULL),
('I', NULL), 
('J', NULL);

--*S�n�f� olan ��retmenlerin ad,soyad,s�n�fId ve s�n�fad listesi
SELECT Ogretmenler.OgretmenAd, Ogretmenler.OgretmenSoyad, Siniflar.SinifId, Siniflar.SinifAd FROM Ogretmenler
JOIN Siniflar ON Ogretmenler.OgretmenId = Siniflar.OgretmenId;

--**S�n�f� olmayan ��retmenlerin ad ve soyad listesi 
SELECT Ogretmenler.OgretmenAd, Ogretmenler.OgretmenSoyad FROM Ogretmenler LEFT JOIN Siniflar ON Ogretmenler.OgretmenId = Siniflar.OgretmenId
WHERE Siniflar.OgretmenId IS NULL;

--***��retmeni olmayan s�n�flar�n Id�leri ve sinifadlar� listesi 
SELECT Siniflar.SinifId, Siniflar.SinifAd FROM Siniflar LEFT JOIN Ogretmenler ON Siniflar.OgretmenId = Ogretmenler.OgretmenId
WHERE Siniflar.OgretmenId IS NULL;

--****GENEL liste: Ogretmen ad, ogretmen soyad,s�n�f�d ve s�n�fad. De�erler varsa yazmal� yoksa NULL yazmal�.

SELECT Ogretmenler.OgretmenAd, Ogretmenler.OgretmenSoyAd, Siniflar.SinifId, Siniflar.SinifAd FROM Ogretmenler
LEFT JOIN Siniflar ON Ogretmenler.OgretmenId = Siniflar.OgretmenId;