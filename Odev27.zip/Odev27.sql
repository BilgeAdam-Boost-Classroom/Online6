﻿USE master;
GO

DROP DATABASE IF EXISTS Odev27Db;
GO

CREATE DATABASE Odev27Db;
GO

USE Odev27Db;
GO

CREATE TABLE Ogretmenler
(
   OgretmenId INT PRIMARY KEY IDENTITY(1,1),
   OgretmenAd NVARCHAR(50) NOT NULL,
   OgretmenSoyad NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Siniflar
(
  SinifAd NVARCHAR(10) NOT NULL,
  OgretmenId INT FOREIGN KEY REFERENCES Ogretmenler(OgretmenId) NULL 
);
GO

INSERT INTO Ogretmenler (OgretmenAd, OgretmenSoyad) VALUES 
(N'Salih', N'Çelik'),
(N'Burcu', N'Kobak'),
(N'Nazmi', N'Tepetam'),
(N'Pelin', N'Demiray'),
(N'Remzi', N'Kırıkgöz');

INSERT INTO Siniflar (SinifAd, OgretmenId) VALUES
(N'9/A', 1),
(N'9/B', 2),
(N'9/C', 3),
(N'9/D', 5),
(N'10/A', 5),
(N'10/B', 5),
(N'10/C', NULL),
(N'10/D', NULL),
(N'11/A', NULL),
(N'11/B', NULL);


SELECT DISTINCT O.OgretmenAd, O.OgretmenSoyad, STRING_AGG(S.SinifAd, ', ') FROM Ogretmenler [O] INNER JOIN Siniflar [S] ON S.OgretmenId = O.OgretmenId
GROUP BY O.OgretmenAd, O.OgretmenSoyad;

SELECT O.OgretmenAd, O.OgretmenSoyad FROM Ogretmenler [O] LEFT JOIN Siniflar [S] ON S.OgretmenId = O.OgretmenId 
WHERE S.OgretmenId IS NULL;

SELECT S.SinifAd, S.OgretmenId FROM Siniflar [S] LEFT JOIN Ogretmenler [O] ON S.OgretmenId = O.OgretmenId 
WHERE S.OgretmenId IS NULL;

SELECT O.OgretmenId [Öğretmen Id], O.OgretmenAd [Öğretmen Adı], O.OgretmenSoyad [Öğretmen Soyad], S.SinifAd [Sınıf Adı]  FROM  Ogretmenler [O] FULL JOIN Siniflar [S] ON S.OgretmenId = O.OgretmenId;