USE master;
GO

DROP DATABASE IF EXISTS Odev27Db
GO

CREATE DATABASE Odev27Db
GO

USE Odev27Db
GO

CREATE TABLE Ogretmenler
(
	OgretmenId INT PRIMARY KEY IDENTITY(1,1),
	OgretmenAd NVARCHAR(50) NOT NULL,
	OgretmenSoyad NVARCHAR(50) NOT NULL

);
GO


CREATE TABLE Siniflar
(
	SinifId INT PRIMARY KEY IDENTITY(1,1),
	SinifAd NVARCHAR(10) UNIQUE NOT NULL,
	OgretmenId INT FOREIGN KEY REFERENCES Ogretmenler(OgretmenId) NULL

);
GO

INSERT INTO Ogretmenler(OgretmenAd,OgretmenSoyad) VALUES
(N'Salih' , N'Y�lmaz'),
(N'Burcu' , N'Y�lmaz'),
(N'Nazmi' , N'Y�lmaz'),
(N'Pelin' , N'Y�lmaz'),
(N'Remzi' , N'Y�lmaz');
GO

INSERT INTO Siniflar(SinifAd,OgretmenId) VALUES
(N'1. S�n�f' , 1),(N'2. S�n�f' , 2),
(N'3. S�n�f' , 3),(N'4. S�n�f' , 5),
(N'5. S�n�f' , 5),(N'6. S�n�f' , 5),
(N'7. S�n�f' , NULL),(N'8. S�n�f' , NULL),
(N'9. S�n�f' , NULL),(N'10. S�n�f' , NULL);
GO

SELECT o.OgretmenId,O.OgretmenAd,o.OgretmenSoyad , STRING_AGG(SinifAd,N', ')
FROM Ogretmenler o
JOIN Siniflar ON Siniflar.OgretmenId=o.OgretmenId
GROUP BY o.OgretmenId,O.OgretmenAd,o.OgretmenSoyad

SELECT Ogretmenler.OgretmenAd, Ogretmenler.OgretmenSoyad
FROM Ogretmenler
FULL JOIN Siniflar ON Ogretmenler.OgretmenId=Siniflar.OgretmenId
WHERE SinifId IS NULL

SELECT SinifId,SinifAd 
FROM Ogretmenler
FULL JOIN Siniflar ON Ogretmenler.OgretmenId=Siniflar.OgretmenId
WHERE Ogretmenler.OgretmenId IS NULL

SELECT O.OgretmenAd,O.OgretmenSoyad,SinifId,SinifAd
FROM Ogretmenler o
FULL JOIN Siniflar ON o.OgretmenId=Siniflar.OgretmenId

