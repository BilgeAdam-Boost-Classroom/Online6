﻿USE master;
GO

DROP DATABASE IF EXISTS Odev27

CREATE DATABASE Odev27;
GO

USE Odev27;
GO

CREATE TABLE Ogretmenler
(
	OgretmenId INT PRIMARY KEY IDENTITY,
	OgretmenAd NVARCHAR(50) NOT NULL,
	OgretmenSoyAd NVARCHAR(50) NOT NULL
);

CREATE TABLE Siniflar
(
	SinifId INT PRIMARY KEY IDENTITY,
	SinifAd NVARCHAR(10) NOT NULL UNIQUE,
	OgretmenId INT FOREIGN KEY REFERENCES Ogretmenler(OgretmenId) NULL
);

INSERT INTO Ogretmenler(OgretmenAd, OgretmenSoyAd) VALUES
(N'Salih', N'Uçan'),
(N'Burcu', N'Çiçek'),
(N'Nazmi', N'Kara'),
(N'Pelin', N'Kartal'),
(N'Remzi', N'Çınar');

INSERT INTO Siniflar(SinifAd, OgretmenId) VALUES
(N'1/A', 1), (N'1/B', 2), (N'2/A', 3), (N'2/B', 5), (N'3/A', 5), (N'3/B', 5), (N'4/A', NULL), (N'4/B', NULL), (N'5/A', NULL), (N'5/B', NULL); 


SELECT OgretmenAd, OgretmenSoyAd, SinifId, SinifAd FROM Ogretmenler O JOIN Siniflar S ON O.OgretmenId = S.OgretmenId

SELECT OgretmenAd, OgretmenSoyAd FROM Ogretmenler O LEFT JOIN Siniflar S ON O.OgretmenId = S.OgretmenId WHERE SinifId IS NULL

SELECT SinifId, SinifAd FROM Siniflar S LEFT JOIN Ogretmenler O ON S.OgretmenId = O.OgretmenId WHERE S.OgretmenId IS NULL

SELECT * FROM Siniflar S FULL JOIN Ogretmenler O ON S.OgretmenId = O.OgretmenId 