﻿using Odev33.Models;

NorthwndContext db = new NorthwndContext();
var tumCalisanlar = db.Employees.ToList();
foreach (var calisan in tumCalisanlar)
{
    Console.WriteLine($"Ad: {calisan.FirstName}");
}



Console.ReadKey();