﻿using System;
using System.Collections.Generic;

namespace Odev33.Models;

public partial class Calisan
{
    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;
}
