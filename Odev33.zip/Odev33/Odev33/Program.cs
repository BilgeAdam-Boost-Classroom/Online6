﻿using Microsoft.EntityFrameworkCore;
using Odev33.Models;
using System.Globalization;
using System.Text;

namespace Odev33
{
    
    internal class Program
    {
     
        
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            NorthwndContext db = new NorthwndContext();

            // Soru 1-) Tüm Employeeleri listeleyiniz.
            var allEmployees = db.Employees.ToList();
            WriteRedText("Soru 1-)");

            foreach (var employee in allEmployees)
            {
                Console.WriteLine($"ID: {employee.EmployeeId}, Name: {employee.FirstName} {employee.LastName}");
            }
            Console.WriteLine();


            // Soru 2-) İlk Employee'i yazdırınız.
            var firstEmployee = db.Employees.First();
            WriteRedText("Soru 2-)");

            Console.WriteLine($"ID: {firstEmployee.EmployeeId}, Name: {firstEmployee.FirstName} {firstEmployee.LastName}");
            Console.WriteLine();


            // Soru 3-) Employeeleri FirstName'e göre sıralayıp son Employee'i yazdırınız.
            var LastEmployeeSortedByFirstName = db.Employees.OrderBy(e => e.FirstName).Last();
            WriteRedText("Soru 3-)");

            Console.WriteLine($"ID: {LastEmployeeSortedByFirstName.EmployeeId}, Name: {LastEmployeeSortedByFirstName.FirstName} {LastEmployeeSortedByFirstName.LastName}");
            Console.WriteLine();


            // Soru 4-) İsmi A ile başlayan Employeeleri listeleyiniz.
            var emplooyesWithNameStartingWithA = db.Employees.Where(e => e.FirstName.ToUpper().Substring(0,1) == "A").ToList();
            WriteRedText("Soru 4-)");

            foreach (var employee in emplooyesWithNameStartingWithA)
            {
                Console.WriteLine($"ID: {employee.EmployeeId}, Name: {employee.FirstName} {employee.LastName}");
            }
            Console.WriteLine();


            // Soru 5-) İsmi A ile başlayan ilk Employee'i yazdırınız.
            var firstEmployeeWithNameStartingWithA = db.Employees.Where(e => e.FirstName.ToUpper().Substring(0, 1) == "A").First();
            WriteRedText("Soru 5-)");

            Console.WriteLine($"ID: {firstEmployeeWithNameStartingWithA.EmployeeId}, Name: {firstEmployeeWithNameStartingWithA.FirstName} {firstEmployeeWithNameStartingWithA.LastName}");
            Console.WriteLine();


            // Soru 6-) İsmi içerisinde a harfi içeren Employeeleri listeleyiniz.
            var employeesWithNameContaningA = db.Employees.Where(e => e.FirstName.Contains("A")).ToList();
            WriteRedText("Soru 6-)");

            foreach (var employee in employeesWithNameContaningA)
            {
                Console.WriteLine($"ID: {employee.EmployeeId}, Name: {employee.FirstName} {employee.LastName}");
            }
            Console.WriteLine();


            // Soru 7-) İsmi içerisinde a harfi içeren ilk employee yi yazdırınız.
            var firstEmployeeWithNameContainingA = db.Employees.Where(e => e.FirstName.Contains("A")).First();
            WriteRedText("Soru 7-)");

            Console.WriteLine($"ID: {firstEmployeeWithNameContainingA.EmployeeId}, Name: {firstEmployeeWithNameContainingA.FirstName} {firstEmployeeWithNameContainingA.LastName}");
            Console.WriteLine();


            // Soru 8-) Adı Andrew olan Employeeleri yazdırınız.
            var andrewEmployees = db.Employees.Where(e => e.FirstName.ToLower() == "andrew").ToList();
            WriteRedText("Soru 8-)");

            foreach (var employee in andrewEmployees)
            {
                Console.WriteLine($"ID: {employee.EmployeeId}, Name: {employee.FirstName} {employee.LastName}");
            }
            Console.WriteLine();


            // Soru 9-)  En pahalı Product'ı yazdırınız.
            var usCulture = new CultureInfo("en-US");
            var mostExpensiveProduct = db.Products.OrderBy(p => p.UnitPrice).Last();
            WriteRedText("Soru 9-)");

            Console.WriteLine($"ID: {mostExpensiveProduct.ProductId}, Name: {mostExpensiveProduct.ProductName}, Unit Price: {usCulture.NumberFormat.CurrencySymbol}{mostExpensiveProduct.UnitPrice:F}");
            Console.WriteLine();


            // Soru 10-) En ucuz productı yazdırınız.

            var cheapestProduct = db.Products.OrderBy(p => p.UnitPrice).First();
            WriteRedText("Soru 10-)");

            Console.WriteLine($"ID: {cheapestProduct.ProductId}, Name: {cheapestProduct.ProductName}, Unit Price: {usCulture.NumberFormat.CurrencySymbol}{cheapestProduct.UnitPrice:F}");
            Console.WriteLine();


            // Soru 11-) Fiyatı ortalama fiyatın üzerinde olan ürünleri yazdırınız.
            var aboveAveragePriceProducts = db.Products.Where(p => p.UnitPrice > db.Products.Average(x => x.UnitPrice)).ToList();
            WriteRedText("Soru 11-)");

            Console.WriteLine($"Ortalama Fiyat: {usCulture.NumberFormat.CurrencySymbol}{db.Products.Average(x => x.UnitPrice):F}");

            foreach (var product in aboveAveragePriceProducts)
            {
                Console.WriteLine($"ID: {product.ProductId, -3}, Name: {product.ProductName,-35}, Unit Price: {usCulture.NumberFormat.CurrencySymbol}{product.UnitPrice,-10:F}");
            }
            Console.WriteLine();


            // Soru 12-) Product ları Stock sayısına göre sıralayınız.
            var productsSortedByStock = db.Products.OrderBy(p => p.UnitsInStock);
            WriteRedText("Soru 12-)");

            foreach (var product in productsSortedByStock)
            {
                Console.WriteLine($"ID: {product.ProductId,-3}, Name: {product.ProductName,-35}, Stock: {product.UnitsInStock}");
            }
            Console.WriteLine();


            // Soru 13-) Product ları önce Stock sayısına göre sonra ProductName e göre büyükten küçüğe sıralayın.
            // (iki sıralama da büyükten küçüğe olmalıdır)
            var productsSortedByStockThenSortedByProductName = db.Products.OrderByDescending(p => p.UnitsInStock).ThenByDescending(p => p.ProductName).ToList();
            WriteRedText("Soru 13-)");

            foreach (var product in productsSortedByStockThenSortedByProductName)
            {
                Console.WriteLine($"ID: {product.ProductId,-3}, Name: {product.ProductName,-35}, Stock: {product.UnitsInStock}");
            }
            Console.WriteLine();

            // Soru 14-) Order detaillarda, order bazında toplam satış tutarı 500 ve altında olan orderid'leri getirip,
            // toplam tutara göre sıralayınız.
            var ordersUnder500 = db.OrderDetails.GroupBy(od => od.OrderId).Where(g => g.Sum(od => od.Quantity * od.UnitPrice) <= 500)
                .OrderByDescending(g => g.Sum(od => od.Quantity * od.UnitPrice)).Select(g => g.Key).ToList();
            WriteRedText("Soru 14-)");

            foreach (var orderId in ordersUnder500)
            {
                Console.WriteLine($"Order ID: {orderId}");
            }
            Console.WriteLine();

            // Soru 15-) Tüm product ları category leri ile birlikte listeleyiniz.
            var productsWithCategoriesList = db.Products.Include(p => p.Category).ToList();
            WriteRedText("Soru 15-)");

            foreach (var product in productsWithCategoriesList)
            {
                Console.WriteLine($"ID: {product.ProductId}, Name: {product.ProductName,-30}, Category: {product.Category?.CategoryName}");
            }
            Console.WriteLine();


            // Soru 16-) ProductName, CategoryName, Suplier'ın CompanyName 'ini ile birlikte yazdırınız. 
            var productsWithCategoryAndSupplierList = db.Products.Include(p => p.Category).Include(p => p.Supplier).ToList();
            WriteRedText("Soru 16-)");

            foreach (var product in productsWithCategoryAndSupplierList)
            {
                Console.WriteLine($"Name: {product.ProductName,-30}, Category: {product.Category?.CategoryName,-20}, Supplier: {product.Supplier?.CompanyName}");
            }



            static void WriteRedText(string text)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(text);
                Console.ResetColor();
            }

            Console.ReadKey();
        }
    }
}
