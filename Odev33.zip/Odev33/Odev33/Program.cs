﻿using Microsoft.EntityFrameworkCore;
using Odev33.Models;

NorthwndContext db = new NorthwndContext();


// Soru 1) Tüm Employeeleri listeleyiniz.

//foreach (var employee in db.Employees)
//{
//    Console.WriteLine(employee.FirstName + " " + employee.LastName);
//}

// Soru 2) İlk Employee yi yazdırınız.

//var employee2 = db.Employees.Select(e => e.EmployeeId + " " + e.FirstName + " " + e.LastName).FirstOrDefault();
//Console.WriteLine(employee2);

// Soru 3) Employeeleri , FirstName e göre sıralayıp son employee yi yazdırınız.

//var employee3 = db.Employees.Select(e => e).OrderBy(e => e.FirstName).LastOrDefault();
//Console.WriteLine(employee3.FirstName);

// Soru 4) İsmi A ile başlayan employee leri listeleyiniz.

//var employee4 = db.Employees.Select(e => e).Where(e => e.FirstName.StartsWith("A"));
//foreach (var e in employee4)
//{
//    Console.WriteLine(e.FirstName);
//}

// Soru 5) İsmi A ile başlayan ilk Employee yi yazdırınız.

//var employee5 = db.Employees.Select(e => e).Where(e => e.FirstName.StartsWith("A")).FirstOrDefault();
//Console.WriteLine(employee5.FirstName);

// Soru 6) İsmi içerisinde a harfi içeren employeeleri listeleyiniz.

//var employee6 = db.Employees.Select(e => e).Where(e => EF.Functions.Like(e.FirstName, "%a%"));
//foreach (var e in employee6)
//{
//    Console.WriteLine(e.FirstName);
//}

// Soru 7) İsmi içerisinde a harfi içeren ilk employee yi yazdırınız.
//var employee7 = db.Employees.Select(e => e).Where(e => EF.Functions.Like(e.FirstName, "%a%")).FirstOrDefault();
//Console.WriteLine(employee7.FirstName + " " + employee7.LastName);

// Soru 8)

//var employee8 = db.Employees.Select(e => e).Where(e => e.FirstName == "Andrew").FirstOrDefault();
//Console.WriteLine(employee8.FirstName + " " + employee8.LastName);


// Soru 9)

//var product = db.Products.OrderByDescending(p => p.UnitPrice).FirstOrDefault();
//Console.WriteLine(product.ProductName + " " + product.UnitPrice);

// Soru 10)

//var product2 = db.Products.OrderBy(p => p.UnitPrice).FirstOrDefault();
//Console.WriteLine(product2.ProductName + " " + product2.UnitPrice);

// Soru 11)

//decimal? averagePrice = db.Products.Average(p => p.UnitPrice);
//var product3 = db.Products.Where(p => p.UnitPrice > averagePrice).ToList();

//foreach (var p in product3)
//{
//    Console.WriteLine(p.ProductName + " - " + p.UnitPrice);
//}

// Soru 12) Product ları önce Stock sayısına göre sonra ProductName e göre büyükten küçüğe sıralayın. (iki sıralama da büyükten küçüğe olmalıdır)

//var product4 = db.Products.OrderBy(p => p.UnitsInStock).ToList();
//foreach (var p in product4)
//{
//    Console.WriteLine(p.ProductName + " - " + p.UnitsInStock);
//}

// Soru 13) Product ları önce Stock sayısına göre sonra ProductName e göre büyükten küçüğe sıralayın. (iki sıralama da büyükten küçüğe olmalıdır)

//var product5 = db.Products.ToList().OrderByDescending(p => p.ProductName).OrderByDescending(p => p.UnitsInStock);
//foreach (var p in product5)
//{
//    Console.WriteLine(p.UnitsInStock + " - " + p.ProductName);
//}

// Soru 14) Order detaillarda, order bazında toplam satış tutarı 500 ve altında olan orderid'leri getirip, toplam tutara göre sıralayınız.

//var orderdetails = db.OrderDetails.GroupBy(od => od.OrderId)
//                .Select(group => new
//                {
//                    OrderId = group.Key,
//                    TotalSales = group.Sum(od => od.Quantity * od.UnitPrice * (1m - Convert.ToDecimal(od.Discount)))
//                })
//                .Where(order => order.TotalSales <= 500)
//                .OrderBy(order => order.TotalSales)
//                .ToList();

//foreach (var o in orderdetails)
//{
//    Console.WriteLine(o.OrderId + " - " + o.TotalSales);
//}

// Soru 15) Tüm product ları category leri ile birlikte listeleyiniz.

//var product6 = db.Products.Include(p => p.Category).ToList();

//foreach (var p in product6)
//{
//    Console.WriteLine(p.ProductName + " - " + p.Category.CategoryName);
//}

// Soru 16) ProductName, CategoryName, Suplier'ın CompanyName 'ini ile birlikte yazdırınız. 

//var product7 = db.Products.Include(p => p.Category).Include(p => p.Supplier).ToList();
//Console.WriteLine("{0,-35} {1,-35} {2,-35}", "ProductName", "CategoryName", "CompanyName");

//foreach (var p in product7)
//{
//    Console.WriteLine("{0,-35} {1,-35} {2,-35}", p.ProductName, p.Category.CategoryName, p.Supplier.CompanyName);
//}


Console.ReadKey();
