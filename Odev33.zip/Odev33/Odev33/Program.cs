﻿
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Odev33.Models;
using System.Linq;

NorthwndContext db = new NorthwndContext();


// 1

Console.WriteLine("\nSoru1\n");

var sonuc = db.Employees.Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).ToList();

foreach (var x in sonuc)
    Console.WriteLine(x);

// 2

Console.WriteLine("\nSoru2\n");

var sonuc2 = db.Employees.Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).FirstOrDefault();

Console.WriteLine(sonuc2);

// 3

Console.WriteLine("\nSoru3\n");


var sonuc3 = db.Employees.Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).OrderBy(x => x.FirstName).LastOrDefault();

Console.WriteLine(sonuc3);

// 4

Console.WriteLine("\nSoru4\n");


var sonuc4 = db.Employees.Where(x => x.FirstName.StartsWith("A")).Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).ToList();

foreach (var x in sonuc4)
    Console.WriteLine(x);

// 5

Console.WriteLine("\nSoru5\n");

var sonuc5 = db.Employees.Where(x => x.FirstName.StartsWith("A")).Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).ToList().FirstOrDefault();

Console.WriteLine(sonuc5);

// 6

Console.WriteLine("\nSoru6\n");


var sonuc6 = db.Employees.Where(x => x.FirstName.ToLower().Contains("a")).Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).ToList();

foreach (var x in sonuc6)
    Console.WriteLine(x);

// 7 

Console.WriteLine("\nSoru7\n");

var sonuc7 = db.Employees.Where(x => x.FirstName.ToLower().Contains("a")).Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).ToList().FirstOrDefault();

Console.WriteLine(sonuc7);

// 8

Console.WriteLine("\nSoru8\n");

var sonuc8 = db.Employees.Where(x => x.FirstName == "Andrew").Select(x => new { x.EmployeeId, x.FirstName, x.LastName }).ToList();

foreach (var x in sonuc8)
    Console.WriteLine(x);

// 9

Console.WriteLine("\nSoru9\n");

var sonuc9 = db.Products.Select(x => new { x.ProductId, x.ProductName, x.UnitPrice }).FirstOrDefault(x => x.UnitPrice == db.Products.Max(x => x.UnitPrice));
//var sonuc9 = db.Products.OrderByDescending(x => x.UnitPrice).Select(x => new { x.ProductId, x.ProductName, x.UnitPrice }).FirstOrDefault();

Console.WriteLine(sonuc9);

// 10

Console.WriteLine("\nSoru10\n");

var sonuc10 = db.Products.OrderBy(x => x.UnitPrice).Select(x => new { x.ProductId, x.ProductName, x.UnitPrice }).FirstOrDefault();

Console.WriteLine(sonuc10);

// 11

Console.WriteLine("\nSoru11\n");

var sonuc11 = db.Products.Where(x => x.UnitPrice > db.Products.Average(x => x.UnitPrice)).Select(x => new { x.ProductId, x.ProductName, x.UnitPrice }).ToList();

foreach (var x in sonuc11)
    Console.WriteLine(x);

// 12

Console.WriteLine("\nSoru12\n");

var sonuc12 = db.Products.Select(x => new { x.ProductId, x.ProductName, x.UnitsInStock }).OrderBy(x => x.UnitsInStock).ToList();

foreach (var x in sonuc12)
    Console.WriteLine(x);

// 13

Console.WriteLine("\nSoru13\n");

var sonuc13 = db.Products.Select(x => new { x.ProductId, x.ProductName, x.UnitsInStock }).OrderByDescending(x => x.UnitsInStock).ThenByDescending(x => x.ProductName).ToList();

foreach (var x in sonuc13)
    Console.WriteLine(x);

// 14

Console.WriteLine("\nSoru14\n");

var sonuc14 = db.OrderDetails
    .GroupBy(x => x.OrderId)
    .Select(x => new
    {
        OrderId = x.Key,
        TotalAmount = x.Sum(y => y.Quantity * y.UnitPrice * (decimal)(1 - y.Discount))
    })
    .Where(x => x.TotalAmount < 500)
    .OrderBy(x => x.TotalAmount)
    .ToList();


foreach (var x in sonuc14)
    Console.WriteLine(x);

// 15

Console.WriteLine("\nSoru15\n");

var sonuc15 = db.Products.Include(x => x.Category).Select(x => new { x.ProductId, x.ProductName, x.Category.CategoryName }).ToList();

foreach (var x in sonuc15)
    Console.WriteLine(x);

// 16

Console.WriteLine("\nSoru16\n");

var sonuc16 = db.Products.Include(x => x.Category).Include(x => x.Supplier).Select(x => new { x.ProductName, x.Category.CategoryName, x.Supplier.CompanyName }).ToList();

foreach (var x in sonuc16)
    Console.WriteLine(x);

Console.ReadKey();


