﻿using System;
using System.Collections.Generic;

namespace Odev33.Models;

public partial class KritikSeviyeUrunBilgileri
{
    public string ÜrünAdı { get; set; } = null!;

    public string Kategori { get; set; } = null!;

    public string TedarikçiFirma { get; set; } = null!;

    public short? MinimumSatışAdedi { get; set; }

    public decimal? BirimFiyat { get; set; }
}
