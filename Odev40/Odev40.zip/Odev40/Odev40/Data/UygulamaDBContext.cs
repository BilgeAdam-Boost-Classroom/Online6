﻿using Microsoft.EntityFrameworkCore;

namespace Odev40.Data
{
    public class UygulamaDBContext : DbContext
    {
        public UygulamaDBContext(DbContextOptions<UygulamaDBContext> options) : base(options)
        {

        }

        public DbSet<Oyun> Oyunlar { get; set; }
    }
}
