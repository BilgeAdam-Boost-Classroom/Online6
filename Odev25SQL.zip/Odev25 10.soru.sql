﻿CREATE DATABASE SatrancDb;
GO

USE SatrancDb;

CREATE TABLE Taslar 
(
    ID INT PRIMARY KEY,
    Ad NVARCHAR(50) NOT NULL,
    Hareket NVARCHAR(MAX) NOT NULL,
    Renk BIT NOT NULL,
);

INSERT INTO Taslar (ID, Ad, Hareket, Renk) VALUES
(1, 'Piyon', 'Öne doğru bir kare', 1),
(2, 'Kale', 'Dikey ve yatay hareket', 1),
(3, 'At', 'L şeklinde hareket', 1),
(4, 'Fil', 'Çapraz hareket', 1),
(5, 'Vezir', 'Her yöne hareket', 1),
(6, 'Sah', 'Her yöne bir kare', 1);

SELECT * FROM Taslar;