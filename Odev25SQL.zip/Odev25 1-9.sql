﻿USE NORTHWND;

-- 1
SELECT * FROM Employees
WHERE FirstName NOT LIKE '[A-I]%';

-- 2
SELECT * FROM Employees
WHERE FirstName NOT LIKE '_A%' AND FirstName NOT LIKE'_T%';

-- 3
SELECT * FROM Employees
WHERE FirstName LIKE 'LA%' OR FirstName LIKE'LN%' OR FirstName LIKE'AA%' OR FirstName LIKE'AN%';

-- 4
SELECT FirstName FROM Employees
WHERE FirstName LIKE '%_%';


-- 5
SELECT TOP 10 PERCENT CustomerID
FROM Customers
WHERE CustomerID LIKE '_A_T%'
ORDER BY CustomerID DESC;

-- 6
SELECT FirstName, LastName, FORMAT(BirthDate, 'hh:mm:ss') AS Saat
FROM Employees
ORDER BY Saat DESC;

-- 7
SELECT FirstName, LastName, 
    (DATEPART(hour, BirthDate) * 60 + DATEPART(minute, BirthDate)) AS Dakika
FROM Employees
ORDER BY Dakika DESC;

-- 8
SELECT DATEDIFF(DAY,'1994-05-16', GETDATE()) AS Yas;

-- 9
SELECT OrderDate, ShippedDate FROM Orders 
WHERE MONTH(OrderDate) = 7 OR DAY(ShippedDate) > 15;

