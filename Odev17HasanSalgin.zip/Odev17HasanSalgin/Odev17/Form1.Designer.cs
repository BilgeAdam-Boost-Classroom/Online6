﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDersler = new TextBox();
            btnEkle = new Button();
            cmbDersler = new ComboBox();
            lbDersler = new ListBox();
            btnHicBirSeySecme = new Button();
            SuspendLayout();
            // 
            // txtDersler
            // 
            txtDersler.Location = new Point(12, 14);
            txtDersler.Name = "txtDersler";
            txtDersler.Size = new Size(449, 29);
            txtDersler.TabIndex = 0;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(476, 14);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(137, 55);
            btnEkle.TabIndex = 1;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // cmbDersler
            // 
            cmbDersler.FormattingEnabled = true;
            cmbDersler.Location = new Point(12, 75);
            cmbDersler.Name = "cmbDersler";
            cmbDersler.Size = new Size(601, 29);
            cmbDersler.TabIndex = 2;
            cmbDersler.SelectedIndexChanged += cmbDersler_SelectedIndexChanged;
            // 
            // lbDersler
            // 
            lbDersler.FormattingEnabled = true;
            lbDersler.ItemHeight = 21;
            lbDersler.Location = new Point(12, 122);
            lbDersler.Name = "lbDersler";
            lbDersler.Size = new Size(601, 277);
            lbDersler.TabIndex = 3;
            lbDersler.SelectedIndexChanged += lbDersler_SelectedIndexChanged;
            // 
            // btnHicBirSeySecme
            // 
            btnHicBirSeySecme.Location = new Point(12, 405);
            btnHicBirSeySecme.Name = "btnHicBirSeySecme";
            btnHicBirSeySecme.Size = new Size(601, 55);
            btnHicBirSeySecme.TabIndex = 1;
            btnHicBirSeySecme.Text = "hiçbir şey seçme";
            btnHicBirSeySecme.UseVisualStyleBackColor = true;
            btnHicBirSeySecme.Click += btnHicBirSeySecme_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(625, 470);
            Controls.Add(lbDersler);
            Controls.Add(cmbDersler);
            Controls.Add(btnHicBirSeySecme);
            Controls.Add(btnEkle);
            Controls.Add(txtDersler);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4, 4, 4, 4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDersler;
        private Button btnEkle;
        private ComboBox cmbDersler;
        private ListBox lbDersler;
        private Button btnHicBirSeySecme;
    }
}