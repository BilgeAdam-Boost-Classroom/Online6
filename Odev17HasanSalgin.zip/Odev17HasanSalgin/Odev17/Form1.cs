namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            Dersler ders = new Dersler();

            foreach (string dersim in lbDersler.Items)
            {
                if (dersim == txtDersler.Text)
                {
                    MessageBox.Show("Ayn� dersi ekleyemezsiniz");
                    txtDersler.Clear();
                    return;
                }
            }

            if (txtDersler.Text == "")
                MessageBox.Show("ALAN bo� kalamaz , l�tfen ge�erli bir ders ad� giriniz!");

            else
            {
                ders.Ad = txtDersler.Text;
                cmbDersler.Items.Add(ders.Ad);
                lbDersler.Items.Add(ders.Ad);
            }
            txtDersler.Clear();

        }

        private void cmbDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("combobox 'tan se�ilen eleman: " + cmbDersler.Text);
        }

        private void lbDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("listbox 'tan se�ilen eleman: " + lbDersler.Text);
        }

        private void btnHicBirSeySecme_Click(object sender, EventArgs e)
        {
            cmbDersler.SelectedIndex = -1;
            lbDersler.SelectedIndex = -1;
        }
    }
}