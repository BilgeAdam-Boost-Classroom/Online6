namespace Gorev2
{
    public partial class Form1 : Form
    {
        List<Araba> arabalar = new List<Araba>();
        Araba araba1 = new() { Marka = "A", Model = "A1", Renk = "Siyah", UretimYili = "2010" };
        Araba araba2 = new() { Marka = "B", Model = "B1", Renk = "Siyah", UretimYili = "2020" };
        Araba araba3 = new() { Marka = "C", Model = "C1", Renk = "Mavi", UretimYili = "2016" };
        Araba araba4 = new() { Marka = "D", Model = "D1", Renk = "Metalik Gri", UretimYili = "2018" };


        public Form1()
        {
            InitializeComponent();
            arabalar.Add(araba1);
            arabalar.Add(araba2);
            arabalar.Add(araba3);
            arabalar.Add(araba4);
            foreach (Araba araba in arabalar)
            {
                lstArabalar.Items.Add(araba.Marka + " - " + araba.Model);
            }

        }

        private void lstArabalar_SelectedIndexChanged(object sender, EventArgs e)
        {
            int secili = lstArabalar.SelectedIndex;

            Araba seciliAraba = arabalar[secili];
            lblOzellikler.Text = seciliAraba.OzellikleriYaz();

            // casting ile alakal� sorular�m var ?
        }
    }
}