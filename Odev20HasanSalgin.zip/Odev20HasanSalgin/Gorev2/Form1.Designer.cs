﻿namespace Gorev2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstArabalar = new ListBox();
            lblOzellikler = new Label();
            SuspendLayout();
            // 
            // lstArabalar
            // 
            lstArabalar.FormattingEnabled = true;
            lstArabalar.ItemHeight = 21;
            lstArabalar.Location = new Point(17, 17);
            lstArabalar.Margin = new Padding(4, 4, 4, 4);
            lstArabalar.Name = "lstArabalar";
            lstArabalar.Size = new Size(738, 214);
            lstArabalar.TabIndex = 0;
            lstArabalar.SelectedIndexChanged += lstArabalar_SelectedIndexChanged;
            // 
            // lblOzellikler
            // 
            lblOzellikler.BackColor = Color.SandyBrown;
            lblOzellikler.Location = new Point(57, 287);
            lblOzellikler.Margin = new Padding(4, 0, 4, 0);
            lblOzellikler.Name = "lblOzellikler";
            lblOzellikler.Size = new Size(671, 143);
            lblOzellikler.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(774, 472);
            Controls.Add(lblOzellikler);
            Controls.Add(lstArabalar);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4, 4, 4, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstArabalar;
        private Label lblOzellikler;
    }
}