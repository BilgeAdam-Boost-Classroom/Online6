﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev20HasanSalgin
{
    internal class MotorluTasit
    {
        public virtual void Git()
        {
            Console.WriteLine("motorlu taşıt gidiyor...");
        }
    }
}
