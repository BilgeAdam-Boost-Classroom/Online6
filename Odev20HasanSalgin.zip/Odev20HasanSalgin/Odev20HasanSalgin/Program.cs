﻿
using Odev20HasanSalgin;

MotorluTasit m1 = new();
m1.Git();
Console.WriteLine("********************");

Araba a1 = new();
a1.Git();
Console.WriteLine("********************");

MotorluTasit m2= new Araba();
m2.Git();













Console.ReadKey();