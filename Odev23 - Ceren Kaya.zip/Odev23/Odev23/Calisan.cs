﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev23
{
    public delegate void Hediye();
    public class Calisan
    {
        public string? malzeme1 { get; set; }

        public string? malzeme2 { get; set; }

        public event Hediye? AnahtarDegisti;

        public void AnahtarCek(int i)
        {
          
            malzeme1 = RastgeleMalzemeSec().ToString();
            Console.WriteLine($"{i}. çalışanın ilk çektiği anahtarlık malzemesi : " + malzeme1);
            malzeme2 = RastgeleMalzemeSec().ToString();
            Console.WriteLine($"{i}.çalışan ikinci anahtarlığı çekti.");
 
            if (malzeme1 != malzeme2)
            {
                Console.WriteLine("malzeme değişti "+ malzeme1  + " ==> "+malzeme2);
                if (AnahtarDegisti != null)
                AnahtarDegisti();
               
            }
            Console.WriteLine($"{i}. çalışanın ikinci çektiği anahtarlık malzemesi : " + malzeme2);
            Console.WriteLine(" ");

        }

        private Malzeme RastgeleMalzemeSec()
        {
            Random rnd = new Random();
            Malzeme rastgeleMalzeme = (Malzeme)rnd.Next(0, 2);
            return rastgeleMalzeme;
        }
    }



}
