﻿namespace Odev23
{
    public class Kazandiniz
    {
        static void Main(string[] args)
        {


            for (int i = 1; i < 6; i++)
            {
                Calisan calisan = new Calisan();
                calisan.AnahtarDegisti += Calisan_AnahtarDegistiHandler;
                calisan.AnahtarCek(i);
            }
            Console.ReadKey();
        }


        private static void Calisan_AnahtarDegistiHandler()
        {

            Console.WriteLine("Hediyeyi Kazandınız :)");
        }
    }
}
