﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev23
{
    public class Fabrika
    {
        // Kendi tanımladığımız event
        public event HediyeVerHandler HediyeVer;

        public void CalisanHediyeKontrol(string calisanAdi, Malzeme ilkAnahtarlik, Malzeme ikinciAnahtarlik)
        {
            Console.WriteLine($"{calisanAdi} isimli çalışan ilk anahtarlığı çekti: {ilkAnahtarlik}");
            Console.WriteLine($"{calisanAdi} isimli çalışan ikinci anahtarlığı çekti: {ikinciAnahtarlik}");

            // Hediye kazanıp kazanmadığını kontrol et.
            if (ilkAnahtarlik != ikinciAnahtarlik)
            {
                HediyeVer?.Invoke(calisanAdi);
            }
            Console.WriteLine();
        }
    }
}
