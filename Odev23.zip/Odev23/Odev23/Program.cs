﻿using Odev23;



for (int i = 1; i < 6; i++)
{
    Console.WriteLine(i + " .çalışanın ");
    Calisan calisan = new Calisan();
    calisan.hediyeSonuc += Yazdır;
    calisan.Sonuc();
}

Console.ReadKey();

static void Yazdır(Calisan kisi)
{
    Console.WriteLine("İlk çektiği anahtarlık malzemesi: "+kisi.cekIlk);
    Console.WriteLine("İkinci çektiği anahtarlık malzemesi: "+kisi.cekSon);
    Console.WriteLine("Hediyeyi "+(kisi.cekIlk==kisi.cekSon? "kazandınız":"kaybettiniz"));

}