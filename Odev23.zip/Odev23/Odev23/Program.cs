﻿namespace Odev23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> calisanlar = new List<string> { "Çalışan 1", "Çalışan 2", "Çalışan 3", "Çalışan 4", "Çalışan 5" };
            Fabrika fabrika = new Fabrika();

            // metot
            void HediyeKazan(string calisanAdi)
            {
                Console.WriteLine($"{calisanAdi} isimli çalışan hediye kazandı!");
            }

            // Event'e metot baglama
            fabrika.HediyeVer += HediyeKazan;

            // Her çalışan için anahtarlık çekimi:
            foreach (string calisan in calisanlar)
            {
                Random rnd = new Random();
                Malzeme ilkAnahtarlik = (Malzeme)rnd.Next(2);
                Malzeme ikinciAnahtarlik = (Malzeme)rnd.Next(2);

                fabrika.CalisanHediyeKontrol(calisan, ilkAnahtarlik, ikinciAnahtarlik);
            }

            Console.ReadKey();
        }


    }
}