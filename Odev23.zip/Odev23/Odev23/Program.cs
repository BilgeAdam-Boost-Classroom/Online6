﻿namespace Odev23
{
    internal class Program
    {
        static void Main(string[] args)
        {

            for (int i = 1; i <= 5; i++)
            {
                Calisan calisan = new Calisan();
                calisan.AnahtarlikSecme += Calisan_AnahtarlikSecme;
                calisan.HediyeKazanmaDurumu += Calisan_HediyeKazanmaDurumu;

                AnahtarlikMalzeme[] sonuclar = new AnahtarlikMalzeme[2];
                for (int j = 0; j <= 1; j++)
                {
                    sonuclar[j] = Calisan_AnahtarlikSecme();
                    Console.WriteLine($"{i}. Çalışanın {j + 1}. Çektiği Anahtarlığın Malzemesi: {sonuclar[j]}.");

                }
                AnahtarlikMalzeme sonuc1 = sonuclar[0];
                AnahtarlikMalzeme sonuc2 = sonuclar[1];
                if (Calisan_HediyeKazanmaDurumu(sonuc1 , sonuc2))
                {
                    Console.WriteLine($"{i}. Çalışan Hediye Almaya Hak Kazandı.");
                }
                else
                {
                    Console.WriteLine($"{i}. Çalışan Hediye Almaya Hak Kazanamadı.");
                }
            }

            Console.ReadKey();
        }

        private static AnahtarlikMalzeme Calisan_AnahtarlikSecme()
        {
            Random random = new Random();
            return (AnahtarlikMalzeme)random.Next(0,2);//0 ve 1 
        }
        private static bool Calisan_HediyeKazanmaDurumu(AnahtarlikMalzeme sonuc1, AnahtarlikMalzeme sonuc2)
        {
            if (sonuc1 == sonuc2)
                return false;
            else
                return true;
        }
    }
}








