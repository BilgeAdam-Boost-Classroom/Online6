﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev23
{
    public delegate void HediyeVerHandler(string calisanAdi);
}
