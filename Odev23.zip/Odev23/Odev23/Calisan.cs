﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev23
{
    public delegate void Sans(Calisan kisi);
    public class Calisan
    {

        public Anahtarlik cekIlk { get; } = (Anahtarlik)new Random().Next(2);
        public Anahtarlik cekSon { get; } = (Anahtarlik)new Random().Next(2);

        public event Sans hediyeSonuc;

        public void Sonuc()
        {
            hediyeSonuc(this);
        }
  
    }
}
