﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev23
{
    public delegate AnahtarlikMalzeme BakmadanAnahtarlikSecme();
    public delegate bool HediyeKazandiMi(AnahtarlikMalzeme sonuc1, AnahtarlikMalzeme sonuc2);
    public class Calisan
    {
        public event BakmadanAnahtarlikSecme? AnahtarlikSecme;
        public event HediyeKazandiMi? HediyeKazanmaDurumu;
    }
}
