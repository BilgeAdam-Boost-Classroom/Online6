namespace Soru03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            
        }

        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            if(txtUsername.Text == "admin" && txtPassword.Text == "1234")
            {
                Form2 form2 = new Form2();
                form2.Owner = this;
                form2.Show();
            }
            else
                MessageBox.Show("Kullan�c� Ad� veya Parola Hatal�","Uyar� Mesaj�",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning);
        }
    }
}