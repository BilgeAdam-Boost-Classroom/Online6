namespace Soru01
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {

            string alinanDeger = txtSifre.Text;
            int sifreKarakterSayisi = txtSifre.Text.Trim().Count();

            bool harfVarMi = false;
            bool sayiVarMi = false;

            foreach (char c in alinanDeger)
                if (c > '9' || c < '0')
                    harfVarMi = true;
                else
                    sayiVarMi = true;

            if (sifreKarakterSayisi == 0)
            {
                lblZorluk.Text = "(L�tfen �ifre giriniz..)";
                lblZorluk.ForeColor = Color.Black;
            }
            else
            {

                if ((sifreKarakterSayisi > 0 && sifreKarakterSayisi <= 6) || sayiVarMi || harfVarMi)
                {
                    lblZorluk.Text = "D���k";
                    lblZorluk.ForeColor = Color.Red;
                }
                if (sifreKarakterSayisi == 7 && (sayiVarMi && harfVarMi))
                {
                    lblZorluk.Text = "Orta";
                    lblZorluk.ForeColor = Color.DarkOrange;
                }
                if (sifreKarakterSayisi > 7 && (sayiVarMi && harfVarMi))
                {
                    lblZorluk.Text = "Y�ksek";
                    lblZorluk.ForeColor = Color.DarkSeaGreen;
                }

            }
        }
    }
}