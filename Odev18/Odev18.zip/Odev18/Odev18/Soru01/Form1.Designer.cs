﻿namespace Soru01
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSifre = new TextBox();
            label1 = new Label();
            label2 = new Label();
            lblZorluk = new Label();
            SuspendLayout();
            // 
            // txtSifre
            // 
            txtSifre.Location = new Point(149, 20);
            txtSifre.Margin = new Padding(5);
            txtSifre.Name = "txtSifre";
            txtSifre.Size = new Size(313, 32);
            txtSifre.TabIndex = 0;
            txtSifre.TextChanged += txtSifre_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 25);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(126, 25);
            label1.TabIndex = 1;
            label1.Text = "Şifreyi giriniz:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 93);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(190, 25);
            label2.TabIndex = 2;
            label2.Text = "Şifre Zorluk Derecesi:";
            // 
            // lblZorluk
            // 
            lblZorluk.AutoSize = true;
            lblZorluk.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            lblZorluk.Location = new Point(261, 93);
            lblZorluk.Margin = new Padding(5, 0, 5, 0);
            lblZorluk.Name = "lblZorluk";
            lblZorluk.Size = new Size(201, 25);
            lblZorluk.TabIndex = 3;
            lblZorluk.Text = "(Lütfen Şifre giriniz..)";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(478, 149);
            Controls.Add(lblZorluk);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtSifre);
            Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(5);
            Name = "Form1";
            Text = "Şifre Zorluk Seviyesi Ölçer";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSifre;
        private Label label1;
        private Label label2;
        private Label lblZorluk;
    }
}