﻿namespace Soru02
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ddlRenk = new ComboBox();
            label1 = new Label();
            btnTamam = new Button();
            btnIptal = new Button();
            SuspendLayout();
            // 
            // ddlRenk
            // 
            ddlRenk.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlRenk.FormattingEnabled = true;
            ddlRenk.Items.AddRange(new object[] { "Renk Seçiniz..", "AliceBlue", "Red", "Green", "Blue" });
            ddlRenk.Location = new Point(146, 10);
            ddlRenk.Margin = new Padding(5);
            ddlRenk.Name = "ddlRenk";
            ddlRenk.Size = new Size(286, 33);
            ddlRenk.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 15);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(120, 25);
            label1.TabIndex = 1;
            label1.Text = "Renk Seçiniz:";
            // 
            // btnTamam
            // 
            btnTamam.Location = new Point(19, 53);
            btnTamam.Name = "btnTamam";
            btnTamam.Size = new Size(197, 62);
            btnTamam.TabIndex = 2;
            btnTamam.Text = "Tamam";
            btnTamam.UseVisualStyleBackColor = true;
            btnTamam.Click += btnTamam_Click;
            // 
            // btnIptal
            // 
            btnIptal.Location = new Point(222, 53);
            btnIptal.Name = "btnIptal";
            btnIptal.Size = new Size(210, 62);
            btnIptal.TabIndex = 3;
            btnIptal.Text = "İptal";
            btnIptal.UseVisualStyleBackColor = true;
            btnIptal.Click += btnIptal_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(464, 136);
            Controls.Add(btnIptal);
            Controls.Add(btnTamam);
            Controls.Add(label1);
            Controls.Add(ddlRenk);
            Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(5);
            Name = "Form2";
            Text = "Renk Seçim Ekranı";
            FormClosed += Form2_FormClosed;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox ddlRenk;
        private Label label1;
        private Button btnTamam;
        private Button btnIptal;
    }
}