﻿/* 
 
Soru04 için 

https://github.com/alicans/SayiTahminOyunu

linkinden ulaşabilirsiniz.

*/