﻿using Odev43.Attributes;
using System.ComponentModel.DataAnnotations;

namespace Odev43.Models
{
    public class Maillist
    {
        [Required(ErrorMessage = "E-mail adresi girmediniz.")]
        [EmailAddress (ErrorMessage = "Hatalı bir mail adresi girdiniz.")]
        [BilgeAdam]
        public string Email { get; set; } = null!;
    }
}
