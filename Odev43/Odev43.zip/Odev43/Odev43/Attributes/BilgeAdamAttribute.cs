﻿using System.ComponentModel.DataAnnotations;

namespace Odev43.Attributes
{
    public class BilgeAdamAttribute : ValidationAttribute
    {
        public BilgeAdamAttribute()
        {
            ErrorMessage = "bilgeadam.com domaini dışında sağlayıcı desteklenmemektedir.";
        }
        public override bool IsValid(object? value)
        {
            if (value == null) return true;
            string mailAdresi = (string)value;
            string domain = mailAdresi.Substring(mailAdresi.IndexOf("@") + 1);

            if (domain == "bilgeadam.com")
                return true;
            else
                return false;
        }

    }
}
