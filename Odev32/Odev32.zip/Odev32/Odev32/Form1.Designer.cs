﻿namespace Odev32
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtDersId = new TextBox();
            txtDersKredisi = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtDersKodu = new TextBox();
            label4 = new Label();
            txtDersAdi = new TextBox();
            label5 = new Label();
            dgvDersler = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            groupBox1 = new GroupBox();
            cmbHarfNotu = new ComboBox();
            btnDersEkle = new Button();
            groupBox2 = new GroupBox();
            btnDersSil = new Button();
            btnDersGuncelle = new Button();
            groupBox3 = new GroupBox();
            btnIstatistikGoster = new Button();
            btnOrtalamaHesapla = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(33, 32);
            label1.Name = "label1";
            label1.Size = new Size(47, 15);
            label1.TabIndex = 0;
            label1.Text = "Ders ID:";
            // 
            // txtDersId
            // 
            txtDersId.Location = new Point(86, 29);
            txtDersId.Name = "txtDersId";
            txtDersId.Size = new Size(100, 23);
            txtDersId.TabIndex = 0;
            // 
            // txtDersKredisi
            // 
            txtDersKredisi.Location = new Point(86, 146);
            txtDersKredisi.Name = "txtDersKredisi";
            txtDersKredisi.Size = new Size(100, 23);
            txtDersKredisi.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 149);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 2;
            label2.Text = "Kredisi:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(17, 120);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 4;
            label3.Text = "Harf Notu:";
            // 
            // txtDersKodu
            // 
            txtDersKodu.Location = new Point(86, 88);
            txtDersKodu.Name = "txtDersKodu";
            txtDersKodu.Size = new Size(100, 23);
            txtDersKodu.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 91);
            label4.Name = "label4";
            label4.Size = new Size(64, 15);
            label4.TabIndex = 6;
            label4.Text = "Ders Kodu:";
            // 
            // txtDersAdi
            // 
            txtDersAdi.Location = new Point(86, 59);
            txtDersAdi.Name = "txtDersAdi";
            txtDersAdi.Size = new Size(100, 23);
            txtDersAdi.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(26, 62);
            label5.Name = "label5";
            label5.Size = new Size(54, 15);
            label5.TabIndex = 8;
            label5.Text = "Ders Adı:";
            // 
            // dgvDersler
            // 
            dgvDersler.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDersler.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dgvDersler.Location = new Point(12, 12);
            dgvDersler.MultiSelect = false;
            dgvDersler.Name = "dgvDersler";
            dgvDersler.Size = new Size(537, 320);
            dgvDersler.TabIndex = 10;
            dgvDersler.SelectionChanged += dgvDersler_SelectionChanged;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Id";
            Column1.HeaderText = "ID";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Ad";
            Column2.HeaderText = "Ders Adı";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Kod";
            Column3.HeaderText = "Ders Kodu";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.DataPropertyName = "HarfNotu";
            Column4.HeaderText = "Harf Notu";
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Kredi";
            Column5.HeaderText = "Kredisi";
            Column5.Name = "Column5";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cmbHarfNotu);
            groupBox1.Controls.Add(txtDersKredisi);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtDersAdi);
            groupBox1.Controls.Add(txtDersId);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtDersKodu);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Location = new Point(12, 338);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(204, 187);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "Kontroller";
            // 
            // cmbHarfNotu
            // 
            cmbHarfNotu.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbHarfNotu.FormattingEnabled = true;
            cmbHarfNotu.Items.AddRange(new object[] { "A", "B", "C", "D", "F" });
            cmbHarfNotu.Location = new Point(86, 117);
            cmbHarfNotu.Name = "cmbHarfNotu";
            cmbHarfNotu.Size = new Size(100, 23);
            cmbHarfNotu.TabIndex = 9;
            // 
            // btnDersEkle
            // 
            btnDersEkle.Location = new Point(6, 22);
            btnDersEkle.Name = "btnDersEkle";
            btnDersEkle.Size = new Size(119, 41);
            btnDersEkle.TabIndex = 0;
            btnDersEkle.Text = "DERS EKLE";
            btnDersEkle.UseVisualStyleBackColor = true;
            btnDersEkle.Click += btnDersEkle_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnDersSil);
            groupBox2.Controls.Add(btnDersGuncelle);
            groupBox2.Controls.Add(btnDersEkle);
            groupBox2.Location = new Point(222, 338);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(134, 187);
            groupBox2.TabIndex = 13;
            groupBox2.TabStop = false;
            groupBox2.Text = "Ders Eylemleri";
            // 
            // btnDersSil
            // 
            btnDersSil.ForeColor = Color.Red;
            btnDersSil.Location = new Point(6, 136);
            btnDersSil.Name = "btnDersSil";
            btnDersSil.Size = new Size(119, 41);
            btnDersSil.TabIndex = 2;
            btnDersSil.Text = "DERS SİL";
            btnDersSil.UseVisualStyleBackColor = true;
            btnDersSil.Click += btnDersSil_Click;
            // 
            // btnDersGuncelle
            // 
            btnDersGuncelle.Location = new Point(6, 78);
            btnDersGuncelle.Name = "btnDersGuncelle";
            btnDersGuncelle.Size = new Size(119, 41);
            btnDersGuncelle.TabIndex = 1;
            btnDersGuncelle.Text = "DERS GÜNCELLE";
            btnDersGuncelle.UseVisualStyleBackColor = true;
            btnDersGuncelle.Click += btnDersGuncelle_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnIstatistikGoster);
            groupBox3.Controls.Add(btnOrtalamaHesapla);
            groupBox3.Location = new Point(362, 338);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(187, 187);
            groupBox3.TabIndex = 14;
            groupBox3.TabStop = false;
            groupBox3.Text = "Fonksiyonlar";
            // 
            // btnIstatistikGoster
            // 
            btnIstatistikGoster.Location = new Point(6, 78);
            btnIstatistikGoster.Name = "btnIstatistikGoster";
            btnIstatistikGoster.Size = new Size(160, 41);
            btnIstatistikGoster.TabIndex = 1;
            btnIstatistikGoster.Text = "İSTATİSTİKLERİ GÖSTER";
            btnIstatistikGoster.UseVisualStyleBackColor = true;
            btnIstatistikGoster.Click += btnIstatistikGoster_Click;
            // 
            // btnOrtalamaHesapla
            // 
            btnOrtalamaHesapla.Location = new Point(6, 22);
            btnOrtalamaHesapla.Name = "btnOrtalamaHesapla";
            btnOrtalamaHesapla.Size = new Size(160, 41);
            btnOrtalamaHesapla.TabIndex = 0;
            btnOrtalamaHesapla.Text = "ORTALAMA HESAPLA";
            btnOrtalamaHesapla.UseVisualStyleBackColor = true;
            btnOrtalamaHesapla.Click += btnOrtalamaHesapla_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(559, 533);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dgvDersler);
            Name = "Form1";
            Text = "Dersler";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox txtDersId;
        private TextBox txtDersKredisi;
        private Label label2;
        private Label label3;
        private TextBox txtDersKodu;
        private Label label4;
        private TextBox txtDersAdi;
        private Label label5;
        private DataGridView dgvDersler;
        private GroupBox groupBox1;
        private Button btnDersEkle;
        private GroupBox groupBox2;
        private Button btnDersSil;
        private Button btnDersGuncelle;
        private GroupBox groupBox3;
        private Button btnIstatistikGoster;
        private Button btnOrtalamaHesapla;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private ComboBox cmbHarfNotu;
    }
}
