﻿
using System.Xml.Linq;

namespace Odev32
{
    public partial class Form1 : Form
    {
        UygulamaDbContext db = new UygulamaDbContext();
        public Form1()
        {
            InitializeComponent();
            DersleriGetir();
            cmbHarfNotu.SelectedIndex = 0;
        }

        private void DersleriGetir()
        {
            dgvDersler.AutoGenerateColumns = false;
            dgvDersler.DataSource = db.Dersler.ToList();
        }

        private void btnDersEkle_Click(object sender, EventArgs e)
        {
            string dersAdi = txtDersAdi.Text.Trim();
            string dersKodu = txtDersKodu.Text.Trim();
            string harfNotu = cmbHarfNotu.Text.Trim();
            int dersKredi = Convert.ToInt32(txtDersKredisi.Text.Trim());

            Ders ders = new Ders();
            ders.Ad = dersAdi;
            ders.Kod = dersKodu;
            ders.HarfNotu = harfNotu;
            ders.Kredi = dersKredi;

            db.Dersler.Add(ders);
            db.SaveChanges();

            DersleriGetir();

        }

        private void btnDersGuncelle_Click(object sender, EventArgs e)
        {
            int alinanId = Convert.ToInt32(txtDersId.Text.Trim());
            Ders guncellenecekDers = db.Dersler.FirstOrDefault(d => d.Id == alinanId)!;

            if (guncellenecekDers == null)
            {
                MessageBox.Show("Yazdığınız ID'ye ait bir ders bulunamadı.");
                return;
            }

            guncellenecekDers.Ad = txtDersAdi.Text.Trim();
            guncellenecekDers.Kod = txtDersKodu.Text.Trim();
            guncellenecekDers.HarfNotu = cmbHarfNotu.Text.Trim();
            guncellenecekDers.Kredi = Convert.ToInt32(txtDersKredisi.Text.Trim());

            db.SaveChanges();
            DersleriGetir();

        }

        private void btnDersSil_Click(object sender, EventArgs e)
        {

            DialogResult ds = MessageBox.Show("Silmek istediğinize emin misiniz?", "Silme Onayı", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (ds == DialogResult.Cancel)
                return;

            int alinanId = Convert.ToInt32(txtDersId.Text.Trim());
            Ders silinecekDers = db.Dersler.FirstOrDefault(d => d.Id == alinanId)!;

            db.Dersler.Remove(silinecekDers);
            db.SaveChanges();

            DersleriGetir();
        }

        private void dgvDersler_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDersler.SelectedRows.Count == 0) { return; }
            Ders SeciliSatir = (dgvDersler.SelectedRows[0].DataBoundItem as Ders)!;

            txtDersId.Text = SeciliSatir.Id.ToString();
            txtDersAdi.Text = SeciliSatir.Ad;
            txtDersKodu.Text = SeciliSatir.Kod;
            cmbHarfNotu.Text = SeciliSatir.HarfNotu;
            txtDersKredisi.Text = SeciliSatir.Kredi.ToString();
        }

        private void btnOrtalamaHesapla_Click(object sender, EventArgs e)
        {
            double toplam = 0;
            double toplamKredi = db.Dersler.Sum(ders => ders.Kredi);

            foreach (Ders ders in db.Dersler)
                toplam = toplam + (ders.Kredi * KatsayiHesapla(ders.HarfNotu));

            double ortalama = toplam / toplamKredi;
            MessageBox.Show("Genel Ortalama: " + ortalama);
        }

        private double KatsayiHesapla(string harf)
        {
            switch (harf)
            {
                case "A":
                    return 4;
                case "B":
                    return 3.5;
                case "C":
                    return 2;
                case "D":
                    return 1;
                case "F":
                    return 0;

            }
            return 0;
        }

        private void btnIstatistikGoster_Click(object sender, EventArgs e)
        {
            int basariliSayisi = 0;
            int basarisizSayisi = 0;
            int sinamaliSayisi = 0;
            int toplamDers = 0;

            foreach (Ders ders in db.Dersler)
            {
                if (ders.HarfNotu == "A" || ders.HarfNotu == "B" || ders.HarfNotu == "C")
                    basariliSayisi++;
                else if (ders.HarfNotu == "D")
                    sinamaliSayisi++;
                else if (ders.HarfNotu == "F")
                    basarisizSayisi++;

                toplamDers++;
            }

            string mesaj = $"{toplamDers} dersten:\n{basariliSayisi} tanesi başarılı\n{basarisizSayisi} tanesi başarısız\n{sinamaliSayisi} tanesi sınamalıdır";
            MessageBox.Show(mesaj);
        }
    }
}
