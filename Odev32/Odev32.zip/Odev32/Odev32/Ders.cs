﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev32
{
    public class Ders
    {
        public int Id { get; set; }
        public string Ad { get; set; } = string.Empty;
        public string Kod { get; set; } = string.Empty;
        public string HarfNotu { get; set; } = string.Empty;
        public double Kredi { get; set; }
    }
}
