USE NORTHWND;
GO
--UYGULAMA 1
SELECT * FROM Employees
WHERE Country IN ('UK' ,'Turkey');

--UYGULAMA 2
SELECT * FROM Employees
WHERE Region IS NULL;

--UYGULAMA 3
SELECT * FROM Employees
WHERE LastName IN ('Fuller','King');

--UYGULAMA 4
SELECT * FROM Products
WHERE (UnitPrice > 15 AND Discontinued = 0) OR (UnitsOnOrder < 70 AND ReorderLevel > 5);

--UYGULAMA 5
SELECT ProductName, CategoryID FROM Products
WHERE CategoryID IN (1,4,8);

--UYGULAMA 6
SELECT Address FROM Suppliers
WHERE Fax IS NULL OR City = N'New Orleans ';

--UYGULAMA 7
SELECT RegionID AS [B�lge No], RegionDescription AS [B�lge Tan�m�] FROM Region

--UYGULAMA 8
SELECT * FROM [Order Details]
WHERE Discount <> 0 OR Quantity BETWEEN 10 AND 40;

--UYGULAMA 9
SELECT DISTINCT(Title)[G�rev] FROM Employees
