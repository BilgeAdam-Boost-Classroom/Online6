USE NORTHWND

--1

SELECT * FROM Employees WHERE Country IN (N'UK',N'Turkey');

--2

SELECT * FROM Employees WHERE Region IS NULL;

--3

SELECT * FROM Employees WHERE LastName IN (N'FULLER' , N'KING');

--4

SELECT * FROM Products 
WHERE (UnitPrice>15 AND Discontinued=0) 
OR ( UnitsOnOrder<70 AND ReorderLevel>5 );

--5

SELECT ProductName , CategoryID FROM Products WHERE CategoryID IN (1.4 , 8); 

--6

SELECT Address FROM Suppliers WHERE Fax IS NULL OR City= N'NEW ORLEANS';

--7

SELECT RegionID BelgeNo , RegionDescription BolgeTanimi FROM Region;

--8

SELECT * FROM [Order Details] WHERE Discount<>0 OR Quantity  BETWEEN 10 AND 40;

--9

SELECT DISTINCT Title Gorev FROM Employees