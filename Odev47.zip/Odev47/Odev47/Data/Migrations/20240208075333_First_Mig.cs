﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev47.Data.Migrations
{
    /// <inheritdoc />
    public partial class First_Mig : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Lessons",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Credit = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Lessons", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Lessons",
                columns: new[] { "Id", "Code", "Credit", "Name" },
                values: new object[,]
                {
                    { 1, "MAT 111", 3, "MATEMATİK 1" },
                    { 2, "PHY 101", 4, "FİZİK 1" },
                    { 3, "CHM 201", 5, "KİMYA 2" },
                    { 4, "BIO 301", 4, "BİYOLOJİ 3" },
                    { 5, "CS 201", 4, "BİLGİSAYAR BİLİMLERİ 2" },
                    { 6, "ENG 101", 3, "İNGİLİZCE 1" },
                    { 7, "HIS 201", 3, "TARİH 2" },
                    { 8, "ECO 301", 4, "EKONOMİ 3" },
                    { 9, "PSY 101", 3, "PSİKOLOJİ 1" },
                    { 10, "ART 201", 3, "SANAT 2" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Lessons");
        }
    }
}
