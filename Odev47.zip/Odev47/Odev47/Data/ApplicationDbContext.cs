﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Odev47.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Lesson> Lessons { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Lesson>().HasData(
                   new Lesson() { Id = 1, Code = "MAT 111", Name = "MATEMATİK 1", Credit = 3 },
                   new Lesson() { Id = 2, Code = "PHY 101", Name = "FİZİK 1", Credit = 4 },
                   new Lesson() { Id = 3, Code = "CHM 201", Name = "KİMYA 2", Credit = 5 },
                   new Lesson() { Id = 4, Code = "BIO 301", Name = "BİYOLOJİ 3", Credit = 4 },
                   new Lesson() { Id = 5, Code = "CS 201", Name = "BİLGİSAYAR BİLİMLERİ 2", Credit = 4 },
                   new Lesson() { Id = 6, Code = "ENG 101", Name = "İNGİLİZCE 1", Credit = 3 },
                   new Lesson() { Id = 7, Code = "HIS 201", Name = "TARİH 2", Credit = 3 },
                   new Lesson() { Id = 8, Code = "ECO 301", Name = "EKONOMİ 3", Credit = 4 },
                   new Lesson() { Id = 9, Code = "PSY 101", Name = "PSİKOLOJİ 1", Credit = 3 },
                   new Lesson() { Id = 10, Code = "ART 201", Name = "SANAT 2", Credit = 3 }
               );
        }
    }
}
