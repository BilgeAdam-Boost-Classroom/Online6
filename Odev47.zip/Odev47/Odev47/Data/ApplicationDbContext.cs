﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Odev47.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Lesson> Lessons { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Lesson>().HasData(
                new Lesson() { Id = 1, Name = "Mathematics", Code = "MAT101", Credit = 5 },
                new Lesson() { Id = 2, Name = "Biology", Code = "BIO101", Credit = 3 },
                new Lesson() { Id = 3, Name = "Physics", Code = "PHY101", Credit = 4 },
                new Lesson() { Id = 4, Name = "History", Code = "HIS101", Credit = 2 }
                );
        }
    }
}
