﻿namespace Odev47.Data
{
    public class Lesson
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Code { get; set; } = null!;
        public int Credit { get; set; }
    }
}
