﻿using Microsoft.EntityFrameworkCore;

namespace Odev44Area.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {

        }

        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(
                    new Araba() { Id = 1, Marka = "Volkswagen", Model = "Golf", Yil = 2019, IkinciElMi = false },
                    new Araba() { Id = 2, Marka = "Toyota", Model = "Camry", Yil = 2021, IkinciElMi = true },
                    new Araba() { Id = 3, Marka = "Ford", Model = "Mustang", Yil = 2020, IkinciElMi = false },
                    new Araba() { Id = 4, Marka = "Renault", Model = "Clio", Yil = 2018, IkinciElMi = true },
                    new Araba() { Id = 5, Marka = "BMW", Model = "X5", Yil = 2022, IkinciElMi = false });
        }
    }
}
