﻿using Microsoft.EntityFrameworkCore;

namespace Odev44Area.Data
{
    public class UygulamaDbContext:DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options): base(options)
        {
            
        }
        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(
                new Araba() { Id = 1, Marka = "BMW", ModelYili=2018},
                new Araba() { Id = 2, Marka = "Honda", ModelYili=2010}
                );
        }
    }
}
