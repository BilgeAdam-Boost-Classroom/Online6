﻿namespace Odev44Area.Data
{
    public class Araba
    {
        public int Id { get; set; }

        public string Marka { get; set; }=null!;
        public int ModelYili { get; set; }
    }
}
