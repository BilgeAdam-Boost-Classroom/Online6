﻿USE NORTHWND;

-- SORU - 1)
SELECT * FROM Employees WHERE FirstName NOT LIKE '[A-I]%'

-- SORU -2) 
SELECT * FROM Employees WHERE FirstName NOT LIKE '_A%' AND FirstName NOT LIKE '_T%'

-- SORU -3) 
SELECT * FROM Employees WHERE FirstName LIKE 'LA%' OR FirstName LIKE 'LN%' OR FirstName LIKE 'AA%' OR FirstName LIKE 'AN%';

-- SORU -4)
SELECT FirstName FROM Employees WHERE FirstName LIKE '%[_]%'

-- SORU -5)
SELECT TOP 10 PERCENT CustomerID FROM Customers WHERE CustomerID LIKE '_A_T%' ORDER BY CustomerID DESC 

-- SORU -6)
SELECT FirstName, LastName, DATEPART(HOUR, BirthDate) AS Saat FROM Employees ORDER BY DATEPART(HOUR, BirthDate) DESC

-- SORU -7)
SELECT FirstName, LastName, DATEPART(MINUTE, BirthDate) AS Saat FROM Employees ORDER BY DATEPART(MINUTE, BirthDate) DESC

-- SORU -8)
SELECT DATEDIFF(day, '1997-12-17', '2023-11-06') AS GunFarki

-- SORU -9)
SELECT OrderDate, ShippedDate FROM Orders WHERE DATEPART(MONTH, OrderDate) = 7 OR DATEPART(DAY, ShippedDate) > 15

-- SORU -10)
USE master;
GO

DROP DATABASE IF EXISTS SatrancDb;

CREATE DATABASE SatrancDb;
GO

USE SatrancDb;
GO

CREATE TABLE Taslar
(
	ID INT PRIMARY KEY,
	Ad NVARCHAR(50) NOT NULL,
	Hareket NVARCHAR(MAX) NOT NULL,
	Renk BIT NOT NULL
);
GO

INSERT INTO Taslar(ID, Ad, Renk, Hareket)
VALUES
(1, N'KALE', 0, N'Dikey veya yatay yönde istediği sayıda hareket eder.'),
(2, N'AT', 1, N'L şeklinde hareket eder..'),
(3, N'VEZİR', 1, N'Her yönde istediği sayıda hareket eder.'),
(4, N'FİL', 0, N'Çapraz yönde istediği sayıda hareket eder.'),
(5, N'PİYON', 1, N'İleri yönde başlangıçta 2 daha sonra 1 kare hareket edebilir.'),
(6, N'ŞAH', 0, N'Her yönde sadece 1 kare ilerleyebilir.');
GO

SELECT ID, Ad, Hareket, IIF(Renk = 0,'Beyaz','Siyah') AS RENK FROM Taslar;
