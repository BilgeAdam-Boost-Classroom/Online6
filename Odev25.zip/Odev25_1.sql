CREATE DATABASE SatrancDb;
GO

USE SatrancDb;
GO

CREATE TABLE Taslar (
    Id INT PRIMARY KEY,
    Ad NVARCHAR(50) NOT NULL,
    Hareket NVARCHAR(MAX) NOT NULL,
    Renk BIT NOT NULL
);

INSERT INTO Taslar (Id, Ad, Hareket, Renk) VALUES
(1, 'Piyon', '�leri gitme', 1),
(2, 'Kale', '�leri veya yan gitme', 0),
(3, 'At', 'L �eklinde gitme', 1),
(4, 'Fil', '�apraz gitme', 0),
(5, 'Vezir', 'Her y�nde gitme', 1),
(6, '�ah', 'Her y�nde bir kare gitme', 0);
