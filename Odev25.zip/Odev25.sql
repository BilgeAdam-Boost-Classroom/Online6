--1

SELECT * FROM Employees WHERE FirstName NOT LIKE N'[A-I]%';

--2

SELECT * FROM Employees WHERE FirstName NOT LIKE N'_[AT]%';

--3

SELECT * FROM Employees 
WHERE FirstName LIKE N'LA%' OR
	  FirstName	LIKE N'LN%' OR
	  FirstName	LIKE N'AA%' OR
	  FirstName	LIKE N'AN%'; 

--4

SELECT FirstName FROM Employees WHERE CHARINDEX(N'_',FirstName)>0;

--5

SELECT TOP 10 PERCENT * FROM Customers
WHERE CustomerID LIKE N'_T_T%'
ORDER BY CustomerID DESC

--6

SELECT FirstName , LastName , DATEPART(HOUR ,BirthDate) Saat FROM Employees
ORDER BY DATEPART(HOUR ,BirthDate) DESC

--7

SELECT FirstName , LastName , DATEPART(MINUTE ,BirthDate) Dakika FROM Employees
ORDER BY DATEPART(MINUTE ,BirthDate) DESC

--8

PRINT DATEDIFF(DAY,'1990-06-30', GETDATE());

--9

SELECT OrderDate, ShippedDate FROM Orders
WHERE MONTH(OrderDate)=7 AND DAY(ShippedDate)>15;

--10

CREATE DATABASE SatrancDb;

USE SatrancDb;

CREATE TABLE Taslar
(
	ID INT IDENTITY(1,1) PRIMARY KEY,
	Ad NVARCHAR(50) NOT NULL,
	Hareket NVARCHAR(MAX) NOT NULL,
	Renk BIT NOT NULL
);

INSERT INTO Taslar(Ad,Hareket,Renk)
VALUES
(N'Piyon',N'Tek',N'0'),
(N'Kale',N'D�z',N'0'),
(N'At',N'L',N'1'),
(N'Fil',N'�apraz',N'0'),
(N'Vezir',N'D�z + �apraz',N'1'),
(N'�ah',N'Tek + D�z + �apraz',N'0');

SELECT * FROM Taslar;
