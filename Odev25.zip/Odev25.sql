--Employees tablosundan ad�n�n ilk harfi alfabetik olarak A ile I aras�nda olmayanlar� getiren bir SQL sorgusu
SELECT *
FROM Employees
WHERE LEFT(FirstName, 1) NOT BETWEEN 'A' AND 'I';

SELECT *
FROM Employees
WHERE FirstName LIKE '_[^AT]%'

SELECT *
FROM Employees
WHERE FirstName LIKE 'LA%' OR FirstName LIKE 'LN%' OR FirstName LIKE 'AA%' OR FirstName LIKE 'AN%';

SELECT FirstName
FROM Employees
WHERE FirstName LIKE '%_%' 

SELECT TOP 10 PERCENT CustomerID
FROM Customers
WHERE CustomerID LIKE '_A%T%'
ORDER BY CustomerID DESC;


SELECT FirstName, LastName, FORMAT(BirthDate, 'HH:mm') AS SaatAd�
FROM Employees
ORDER BY SaatAd� DESC;

SELECT FirstName, LastName, FORMAT(BirthDate, 'mm') AS DakikaAd�yla
FROM Employees
ORDER BY DakikaAd�yla DESC;

SELECT DATEDIFF(DAY, '1998-05-10', GETDATE()) AS GecenGunler;

SELECT OrderDate, ShippedDate
FROM Orders
WHERE UPPER(FORMAT(OrderDate, 'MMMM')) = 'JULY' OR DAY(ShippedDate) > 15;

SELECT OrderDate, ShippedDate
FROM Orders
WHERE MONTH(OrderDate) = 7 or DAY(ShippedDate) > 15

