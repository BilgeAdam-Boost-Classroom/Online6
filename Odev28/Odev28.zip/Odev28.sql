-- 1

select distinct ProductID, UnitPrice,
(select avg(UnitPrice) from [Order Details])'Ortalama'
from [Order Details]
group by ProductID, UnitPrice
having UnitPrice < (SELECT AVG(UnitPrice) FROM [Order Details])
order by UnitPrice desc

--2

select t.TerritoryDescription, r.RegionDescription from Region r
inner join Territories t
on r.RegionID = t.RegionID

--3

select * from Customers
where len(PostalCode) > 5

--4

select EmployeeID, FirstName, LastName from Employees
where EmployeeID = (select CategoryID from Categories where CategoryName = 'Seafood')


--5

select p.ProductName, c.CategoryName from Products p
inner join Categories c
on p.CategoryID = c.CategoryID
order by p.ProductName desc

--6
select p.ProductName,
(SELECT top 1 c.CategoryName 
        FROM Categories c
        WHERE p.CategoryID = c.CategoryID 
        ORDER BY p.ProductName DESC) AS CategoryName
from Products p
where p.CategoryID = (select c.CategoryID from Categories c
where p.CategoryID = c.CategoryID
)
order by p.ProductName desc


--7

select ProductName, UnitsInStock, UnitPrice from Products
where UnitsInStock > 50 and UnitPrice > 50
order by UnitsInStock

--8

select ProductName, UnitsInStock, UnitPrice from Products
where UnitsInStock in 
(select UnitsInStock from Products where UnitsInStock > 50)
and UnitPrice in 
(select UnitPrice from Products where UnitPrice > 50)
order by UnitsInStock


--9

select p.ProductName, c.CategoryName, s.CompanyName
from Products p
inner join Categories c
on p.CategoryID = c.CategoryID
inner join Suppliers s
on s.SupplierID = p.SupplierID