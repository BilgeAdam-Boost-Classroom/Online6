﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev20_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            Araba a1 = new Araba("A", "A1", "Siyah", 2009);
            Araba a2 = new Araba("B", "B1", "Siyah", 2018);
            Araba a3 = new Araba("C", "C1", "Siyah", 2000);
            Araba a4 = new Araba("D", "D1", "Siyah", 2012);

            List<Araba> arabalar = new List<Araba> { a1, a2, a3, a4 };

            listBox1.Items.Add(a1.Marka + "      " + a1.Model);
            listBox1.Items.Add(a2.Marka + "      " + a2.Model);
            listBox1.Items.Add(a3.Marka + "      " + a3.Model);
            listBox1.Items.Add(a4.Marka + "      " + a4.Model);

            if (listBox1.SelectedIndex == 0)
                label1.Text = "sdgs dfsf";
            if (listBox1.SelectedIndex == 1)
                label1.Text = a2.ToString();
            if (listBox1.SelectedIndex == 2)
                label1.Text = a3.ToString();
            if (listBox1.SelectedIndex == 3)
                label1.Text = a4.ToString();

           

        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Araba a1 = new Araba("A", "A1", "Siyah", 2009);
            Araba a2 = new Araba("B", "B1", "Siyah", 2018);
            Araba a3 = new Araba("C", "C1", "Siyah", 2000);
            Araba a4 = new Araba("D", "D1", "Siyah", 2012);

            if (listBox1.SelectedIndex == 0)
                label1.Text = a1.OzellikleriYaz();
            if (listBox1.SelectedIndex == 1)
                label1.Text = a2.OzellikleriYaz();
            if (listBox1.SelectedIndex == 2)
                label1.Text = a3.OzellikleriYaz();
            if (listBox1.SelectedIndex == 3)
                label1.Text = a4.OzellikleriYaz();

        }

        
    }
}
