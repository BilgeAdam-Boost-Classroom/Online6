﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev20_2
{
    internal class Araba
    {

        public Araba(string marka, string model, string renk, int uretimYili)
        {

            Marka = marka;
            Model = model;
            Renk = renk;
            UretimYili = uretimYili;


        }

        public string Marka {  get; set; }
        public string Model { get; set; }
        public string Renk { get; set; }
        public int UretimYili { get; set; }


        public string OzellikleriYaz()
        {
            return $"Marka: {Marka} Model: {Model} Renk: {Renk} Üretim Yılı: {UretimYili}".ToString(); 
        }

        public override string ToString()
        {
            return $"Marka: {Marka} Model: {Model} Renk: {Renk} Üretim Yılı: {UretimYili}";
        }

    }
}
