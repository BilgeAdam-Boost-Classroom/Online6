﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru01
{
    public class Araba : MotorluTasit
    {
        public string Marka { get; set; }
        public string Model { get; set; }

        public override void Git()
        {
            Console.WriteLine("Araba Gidiyor...");
        }
    }
}
