﻿using Soru01;

MotorluTasit motorluTasit = new MotorluTasit();
motorluTasit.Git();

Araba bmw = new Araba();
bmw.Git();

MotorluTasit volkswagen = new Araba();
volkswagen.Git();



Console.ReadLine();