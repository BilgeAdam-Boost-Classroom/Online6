﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru01
{
    public class MotorluTasit
    {
        public int SaseNo { get; set; }
        public int TekerlekSayisi { get; set; }

        public virtual void Git()
        {
            Console.WriteLine("Motorlu Taşıt Gidiyor...");
        }
    }
}
