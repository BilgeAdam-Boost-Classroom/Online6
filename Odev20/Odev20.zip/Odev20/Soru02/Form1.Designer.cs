﻿namespace Soru02
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstAraba = new ListBox();
            lblAraba = new Label();
            SuspendLayout();
            // 
            // lstAraba
            // 
            lstAraba.FormattingEnabled = true;
            lstAraba.ItemHeight = 15;
            lstAraba.Location = new Point(12, 12);
            lstAraba.Name = "lstAraba";
            lstAraba.Size = new Size(327, 184);
            lstAraba.TabIndex = 0;
            lstAraba.SelectedIndexChanged += lstAraba_SelectedIndexChanged;
            // 
            // lblAraba
            // 
            lblAraba.BorderStyle = BorderStyle.Fixed3D;
            lblAraba.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            lblAraba.Location = new Point(12, 216);
            lblAraba.Name = "lblAraba";
            lblAraba.Size = new Size(327, 234);
            lblAraba.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(351, 467);
            Controls.Add(lblAraba);
            Controls.Add(lstAraba);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Arabalar";
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstAraba;
        private Label lblAraba;
    }
}