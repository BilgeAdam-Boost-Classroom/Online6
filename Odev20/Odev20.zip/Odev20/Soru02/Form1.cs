namespace Soru02
{
    public partial class Form1 : Form
    {
        List<Araba> arabalar = new List<Araba>()
        {
            new Araba(){ Marka = "A", Model = "A1", Renk = "Siyah", UretimYili = "2010"},
            new Araba(){ Marka = "B", Model = "B1", Renk = "Siyah", UretimYili = "2020"},
            new Araba(){ Marka = "C", Model = "C1", Renk = "Mavi", UretimYili = "2016"},
            new Araba(){ Marka = "D", Model = "D1", Renk = "Metalik Gri", UretimYili = "2018"}
        };
        public Form1()
        {
            InitializeComponent();
            lstAraba.DataSource = arabalar;
        }

        private void lstAraba_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAraba.Text = arabalar[lstAraba.SelectedIndex].OzellikleriYaz();
        }
    }
}