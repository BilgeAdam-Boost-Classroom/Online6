﻿using Microsoft.AspNetCore.Mvc;
using Odev38Mvc.Models;

namespace Odev38Mvc.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult Liste()
        {
            List<UrunViewModel> urunler = new List<UrunViewModel>
            {
                new UrunViewModel(),
                new UrunViewModel(),
                new UrunViewModel(),
                new UrunViewModel(),
                new UrunViewModel()
            };

            return View(urunler);
        }
    }
}
