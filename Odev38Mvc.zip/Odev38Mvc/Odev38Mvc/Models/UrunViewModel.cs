﻿namespace Odev38Mvc.Models
{
    public class UrunViewModel
    {
        public int Numara { get; set; }

        public UrunViewModel()
        {
            Random random = new Random();
            Numara = random.Next(1, 101);
        }
    }
}
