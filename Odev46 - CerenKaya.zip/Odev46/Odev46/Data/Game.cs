﻿using Odev46.Enums;

namespace Odev46.Data
{
    public class Game
    {
        public int Id { get; set; }
        public string GameName { get; set; }
        public float Price { get; set; }
        public Platform Platform { get; set; }    
        public bool SinglePlatform { get; set; }

    }
}
