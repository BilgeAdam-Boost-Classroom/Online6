﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Odev46.Data;
using Odev46.Models;
using System.Net.Http;


namespace Odev46.Control
{
    public static class  GameControl 
    {      
        public static bool IsUnique(GameViewModel gameViewModel,ApplicationDbContext db)
        {
            var model = db.Games.Where(a => a.GameName == gameViewModel.GameName).ToList();

           if ( model.Any(a => a.SinglePlatform))
            {                
                return false;            
            }
            else if(model.Any(a => a.Platform == gameViewModel.Platform ))
            {          
                return false;
            }
           else if (!(gameViewModel.SinglePlatform) || model == null )
            { 
            return true;         
            }

            return false;
        }
    }
}
