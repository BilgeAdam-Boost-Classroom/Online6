﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev46.Control;
using Odev46.Data;
using Odev46.Models;

namespace Odev46.Controllers
{
    public class GamesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly Game _game;

        public GamesController(ApplicationDbContext context, Game game)
        {
            _context = context;
            _game= game;
        }

        // GET: Games
        public async Task<IActionResult> Index()
        {
          
            return View(await _context.Games.ToListAsync());
        }

        // GET: Games/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .FirstOrDefaultAsync(m => m.Id == id);
            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // GET: Games/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Games/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]   
        public async Task<IActionResult> Create([Bind("Id,GameName,Price,Platform,SinglePlatform")] GameViewModel gameViewModel)
        {
          
            if (ModelState.IsValid && GameControl.IsUnique(gameViewModel, _context))
            {
                _game.GameName = gameViewModel.GameName;
                _game.Price = gameViewModel.Price;
                _game.SinglePlatform=gameViewModel.SinglePlatform;
                _game.Platform = gameViewModel.Platform;
                
                _context.Add(_game);
                await _context.SaveChangesAsync();
          
                return RedirectToAction(nameof(Index), new { message = "Eklendi" });

            }
            else
            {
                ModelState.AddModelError("GameName", "Oyun daha önce eklendi.");
                return View(gameViewModel);
            }          
        }

        // GET: Games/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var game = await _context.Games.FindAsync(id);
            if (game == null)
            {
                return NotFound();
            }
            GameViewModel gameViewModel = new GameViewModel()
            {
                GameName = game.GameName,
                Price = game.Price,
                SinglePlatform = game.SinglePlatform,
                Platform = game.Platform


            };
            return View(gameViewModel);
        }

        // POST: Games/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,GameName,Price,Platform,SinglePlatform")] GameViewModel gameViewModel)
        {
              var updateGame = _context.Games.Find(id);

            if (ModelState.IsValid && GameControl.IsUnique(gameViewModel, _context))
            {        
                updateGame.GameName = gameViewModel.GameName;
                updateGame.Price = gameViewModel.Price;
                updateGame.SinglePlatform = gameViewModel.SinglePlatform;
                updateGame.Platform = gameViewModel.Platform;

                _context.Update(updateGame);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            else
            {
                ModelState.AddModelError("GameName", "Oyun daha önce eklendi.");
                return View(gameViewModel);
            }
        }

        // GET: Games/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .FirstOrDefaultAsync(m => m.Id == id);
            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // POST: Games/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var game = await _context.Games.FindAsync(id);
            if (game != null)
            {
                _context.Games.Remove(game);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GameExists(int id)
        {
            return _context.Games.Any(e => e.Id == id);
        }
    }
}
