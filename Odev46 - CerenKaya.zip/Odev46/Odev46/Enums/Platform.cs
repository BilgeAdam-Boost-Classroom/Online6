﻿namespace Odev46.Enums
{
    public enum Platform
    {
        PC,
        XBOX,
        PS5,
        PS4,
        SWITCH
    }
}
