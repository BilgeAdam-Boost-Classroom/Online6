﻿using Odev46.Enums;
using System.ComponentModel.DataAnnotations;



namespace Odev46.Models
{
    public class GameViewModel
    {
        private long _barcodeNumber {  get; set; }

        public GameViewModel()
        {
            BarcodeNumber = GenerateRandom13DigitNumber();          
            _barcodeNumber = BarcodeNumber;     

        }
      
        public string GameName { get; set; }

        [Required(ErrorMessage = "Fiyat giriniz")]
        public float Price { get; set; }
        [Required(ErrorMessage = "Platform seçiniz")]
        public Platform Platform { get; set; }
        public bool SinglePlatform { get; set; }
        public long BarcodeNumber { get; set; }
        protected long GenerateRandom13DigitNumber()
        {
            Random random = new Random();

            // 13 basamaklı sayıyı oluştur
            long min = (long)Math.Pow(10, 12);
            long max = (long)Math.Pow(10, 13) - 1;

            // Rastgele sayıyı oluştur
            byte[] buffer = new byte[8];
            random.NextBytes(buffer);
            long randomNumber = BitConverter.ToInt64(buffer, 0);

            // Elde edilen sayıyı belirtilen aralığa sığdır
            return (long)(Math.Abs(randomNumber % (max - min + 1)) + min);
        }
    }
}
