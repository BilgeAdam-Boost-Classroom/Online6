﻿using System;
using System.ComponentModel;

namespace Odev22
{
    internal class Program
    {
        public delegate double Temsilci(List<double> sayilar);
        static List<double> sayilar = new List<double>();
        static void Main(string[] args)
        {
            Console.WriteLine("Kaç Adet Sayı İle İşlem Tapacağınızı Giriniz: ");
            int işlemeGireceklerAdet = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < işlemeGireceklerAdet; i++)
            {
                Console.Write("İşlem yapmak istediğiniz sayıyı giriniz: ");
                double parametreSayi = Convert.ToDouble(Console.ReadLine());
                sayilar.Add(parametreSayi);
            }

            double toplam = Islem(Topla, sayilar);
            double fark = Islem(Çikar, sayilar);
            double carpim = Islem(Çarp, sayilar);

            Console.WriteLine("Toplam : " + toplam);
            Console.WriteLine("Fark : " + fark);
            Console.WriteLine("Çarpım : " + carpim);
            Console.ReadKey();
        }
        public static double Topla(List<double> sayilar)
        {
            double toplam = 0;
            foreach (double sayi in sayilar)
            {
                toplam += sayi;
            }
            return toplam;
        }
        public static double Çikar(List<double> sayilar)
        {
            double fark = sayilar[0];
            for (int i = 1; i < sayilar.Count; i++)
            {
                fark -= sayilar[i];
            }
            return fark;
        }
        public static double Çarp(List<double> sayilar)
        {
            double çarpim = 1;
            foreach (double sayi in sayilar)
            {
                çarpim *= sayi;
            }
            return çarpim;
        }
        public static double Islem(Temsilci temsilci, List<double> sayilar)
        {
            return (temsilci(sayilar));
        }
    }
}


