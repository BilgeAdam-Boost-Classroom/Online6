﻿internal class Program
{
    public delegate int Islemler(params int[] x);
    private static void Main(string[] args)
    {

        Console.WriteLine("Toplam: " + Islem(Topla, 1, 2, 3, 4, 5, 6));
        Console.WriteLine("Toplam: " + Islem(Cikar, 1, 2, 3, 4, 5, 6));
        Console.WriteLine("Toplam: " + Islem(Carp, 1, 2, 3, 4, 5, 6));

        Console.ReadKey();
    }


    static int Islem(Islemler metot, params int[] a)
    {
        return metot(a);
    }

    static int Topla(params int[] a)
    {
        return a.Sum();
    }
    static int Cikar(params int[] a)
    {
        return 2 * a[0] - a.Sum();
    }
    static int Carp(params int[] a)
    {
        for (int i = 1; i < a.Length; i++)
            a[0] *= a[i];

        return a[0];
    }

}