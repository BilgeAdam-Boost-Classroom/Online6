﻿using System;

namespace Odev22
{
    public class Program
    {
        public delegate int MatematikselIslem(params int[] sayilar);

        static int Topla(params int[] sayilar)
        {
            int toplam = 0;
            foreach (int sayi in sayilar)
            {
                toplam += sayi;
            }
            return toplam;
        }

        static int Fark(params int[] sayilar)
        {
            int fark = sayilar[0];
            for (int i = 1; i < sayilar.Length; i++)
            {
                fark -= sayilar[i];
            }
            return fark;
        }

        static int Carp(params int[] sayilar)
        {
            int carpim = 1;
            foreach (int sayi in sayilar)
            {
                carpim *= sayi;
            }
            return carpim;
        }

        static int Islem(MatematikselIslem matematikselIslem, params int[] sayilar)
        {
            return matematikselIslem(sayilar);
        }

        static void Main(string[] args)
        {

            MatematikselIslem topla = Topla;
            MatematikselIslem cikar = Fark;
            MatematikselIslem carp = Carp;

            int toplam = Islem(topla, 1, 2, 3, 4, 5); 
            int fark = Islem(cikar, 1, 2, 3, 4, 5); 
            int carpim = Islem(carp, 1, 2, 3, 4, 5); 

            Console.WriteLine("Toplam: " + toplam);
            Console.WriteLine("Fark: " + fark);
            Console.WriteLine("Çarpım: " + carpim);
            
            Console.ReadKey(); 
        }
    }
}