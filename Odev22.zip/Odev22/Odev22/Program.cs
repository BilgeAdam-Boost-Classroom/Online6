﻿namespace Odev22
{
    internal class Program
    {
        public delegate int Temsilci(List<int> sayilarim);  // delege tanımladık

        static void Main(string[] args)
        {
            #region kullanıcıdan sayı alma
            Console.WriteLine("kaç adet sayı gireceğinizi yazınız: ");
            int sayiAdedi = Convert.ToInt32(Console.ReadLine());

            List<int> list = new List<int>();

            for (int i = 1; i <= sayiAdedi; i++)
            {
                Console.WriteLine($"{i}. sayınızı giriniz:");
                int x = Convert.ToInt32(Console.ReadLine());
                list.Add(x);
            }
            #endregion

            #region delegeden yararlanarak metod içinde metod kullanımı

            //Console.WriteLine("********* Islem metoduna sırayla yolladığımız metodların sonuçları (Toplam,Fark,Carpim) **********");
            //Console.WriteLine("girilen sayıların sırayla toplamı,farkı ve çarpımı:");
            //Console.WriteLine("TOPLAM = " + Islem(Toplam, list));
            //Console.WriteLine("FARK = " + Islem(Fark, list));
            //Console.WriteLine("ÇARPIM = " + Islem(Carpim, list));
            #endregion

            #region delege referans vererek metod kullanma

            Console.WriteLine("*****************************");

            Temsilci benTemsilciyim = Toplam;
            benTemsilciyim += Fark ;
            benTemsilciyim += Carpim;
            Console.WriteLine("hangisi çalışır? = " + benTemsilciyim(list)); // carpma calısır

            //benTemsilciyim(list);
            //foreach (var item in benTemsilciyim.GetInvocationList())
            //{
            //    Console.WriteLine("metod adı: " + item.Method.Name);
            //    Console.WriteLine("methodun dönüş tipi: " + item.Method.ReturnType);
            //    Console.WriteLine("şu anda çalıştırılan metodun sonucu: " + item.DynamicInvoke(list));
            //    Console.WriteLine("*****************************");
            //}
            #endregion

            Console.ReadLine();
        }

        #region metodlarımız
        static int Toplam(List<int> sayilarim)  //metodlarımızı yazdık
        {
            Console.WriteLine("toplam çalısıyor");
            int toplam = 0;

            foreach (int x in sayilarim)
                toplam += x;

            return toplam;
        }
        static int Fark(List<int> sayilarim)
        {
            Console.WriteLine("cıkarma çalısıyor");

            int fark = sayilarim[0];
            for (int i = 1; i < sayilarim.Count; i++)
            {
                fark -= sayilarim[i];
            }
            return fark;
        }
        static int Carpim(List<int> sayilarim)
        {
            Console.WriteLine("carpım çalısıyor");

            int carpim = 1;
            foreach (int x in sayilarim)
            {
                carpim *= x;
            }
            return carpim;
        }
        static int Islem(Temsilci temsilci, List<int> sayilarim)
        {
            return temsilci(sayilarim);
        }
        #endregion
    }
}