﻿using Microsoft.AspNetCore.Mvc;
using Odev43.Attribute;
using System.ComponentModel.DataAnnotations;

namespace Odev43.Models
{
	public class Email
	{
		[BilgeAdam]
		[EmailAddress(ErrorMessage = "Geçerli bir mail adresi girin.")]
		[Required(ErrorMessage ="Mail adresi giriniz.")]
		public string Mail { get; set; } = null!;
	}
}
