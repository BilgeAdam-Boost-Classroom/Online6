﻿using Odev43.Attributes;
using System.ComponentModel.DataAnnotations;

namespace Odev43.Models
{
    public class KullaniciViewModel
    {
        [Required(ErrorMessage = "E-mail adresinizi girmediniz.")]
        [EmailAddress(ErrorMessage = "Hatalı bir e-mail adresi girdiniz.")]
        [BilgeadamMail]
        public string Email { get; set; } = null!;

        [Required(ErrorMessage = "Şifre alanı zorunludur")]
        public string Sifre { get; set; } = null!;
    }
}
