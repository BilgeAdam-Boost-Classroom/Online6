﻿using Odev43.Attributes;
using System.ComponentModel.DataAnnotations;

namespace CustomValidationOrnek.Models
{
    public class Bilgi
    {
        [Required(ErrorMessage = "Email adresi girmediniz.")]
        [EmailAddress(ErrorMessage = "Hatali bir mail adresi girdiniz.")]
        [BilgeAdam(ErrorMessage = "Sadece @bilgeadam.com ile biten e-posta adresleri kabul edilir.")]
        public string Eposta { get; set; } = null!;
    }
}
