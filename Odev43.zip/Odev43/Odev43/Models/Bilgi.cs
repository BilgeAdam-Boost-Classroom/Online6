﻿using Odev43.Attributes;
using System.ComponentModel.DataAnnotations;

namespace Odev43.Models
{
    public class Bilgi
    {
        [Required(ErrorMessage = "Bu alan zorunludur.")]
        [EmailAddress(ErrorMessage = "Geçerli bir e-posta adresi giriniz.")]
        [GecerliEmailSaglayici("@bilgeadam.com")]
        public string EmailAdresi { get; set; } = null!;
    }
}
