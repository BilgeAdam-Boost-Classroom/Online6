﻿using System.ComponentModel.DataAnnotations;

namespace Odev43.Attribute
{
	public class BilgeAdamAttribute:ValidationAttribute
	{
		public BilgeAdamAttribute() { ErrorMessage = "BilgeAdam sağlayıcısına ait bir mail adresi girin."; }

		public override bool IsValid(object? value)
		{
			if (value == null||!value.ToString()!.Contains("@"))
				return true;

			return value.ToString()!.EndsWith("@bilgeadam.com");
		}
	}
}
