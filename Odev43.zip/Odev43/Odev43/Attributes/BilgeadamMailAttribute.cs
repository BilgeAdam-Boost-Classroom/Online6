﻿using System.ComponentModel.DataAnnotations;

namespace Odev43.Attributes
{
    public class BilgeadamMailAttribute : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            if (value == null) return false;

            string email = (string)value;

            if (!email.EndsWith("@bilgeadam.com"))
            {
                ErrorMessage = "Girdiğiniz E-mail uygun değil";
                return false;
            }
            return true;
        }
    }
}
