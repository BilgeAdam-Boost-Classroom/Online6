﻿using System.ComponentModel.DataAnnotations;

namespace Odev43.Attributes
{
    public class GecerliEmailSaglayiciAttribute : ValidationAttribute
    {
        private readonly string[] _gecerliMailler;

        public GecerliEmailSaglayiciAttribute(params string[] gecerliMailler)
        {
            _gecerliMailler = gecerliMailler;
        }
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value == null)
                return ValidationResult.Success;

            if (value is string mail)
            {
                mail = mail.Trim();
                int index = mail.IndexOf("@");

                if (index == -1)
                {
                    return new ValidationResult("Geçerli bir e-posta adresi giriniz.");
                }

                string mailUzantisi = mail.Substring(index);

                if (!_gecerliMailler.Contains(mailUzantisi))
                {
                    return new ValidationResult("Girilen mail adresi geçerli değildir. Adresin @bilgeadam.com uzantısına sahip olması gerekmektedir.");
                }
            }

            return ValidationResult.Success;
        }
    }
}
