﻿using System.ComponentModel.DataAnnotations;

namespace Odev43.Attributes
{
    public class BilgeAdam : ValidationAttribute
    {
        public BilgeAdam()
        {
            ErrorMessage = "Farkli uzantili mail adresi girdiniz!"; // default mesaj
        }

        public override bool IsValid(object value)
        {
            if (value == null)
                return false;

            string email = value.ToString();

            if (email.EndsWith("@bilgeadam.com"))
            {
                return true;
            }

            return false;
        }
    }
}
