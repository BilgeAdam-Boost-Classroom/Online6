﻿using CustomValidationOrnek.Models;
using Microsoft.AspNetCore.Mvc;

namespace Odev43.Controllers
{
    public class KayitController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Index(Bilgi bilgi)
        {
            if (ModelState.IsValid)
            {
                //model gecerli ise islem yap
                return RedirectToAction("Index", new { islem = "basarili" });
            }
            return View();
        }
    }
}
