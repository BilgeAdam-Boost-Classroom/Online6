﻿using Microsoft.AspNetCore.Mvc;
using Odev43.Models;
using System.Reflection;

namespace Odev43.Controllers
{
    public class KayitController : Controller
    {
        public IActionResult Kayit()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Kayit(Bilgi bilgi)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Index","Home", new { kayit = "başarılı" });
            }

            return View(bilgi);
        }
    }
}
