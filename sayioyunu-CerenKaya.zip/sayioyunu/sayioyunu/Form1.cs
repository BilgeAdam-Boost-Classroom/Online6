namespace sayioyunu
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int uretilenSayi, tahminEdilen;

        public Form1()
        {
            InitializeComponent();
            btnTahmin.Enabled = false;
            txtTahmin.Enabled = false;
            progressBar1.Maximum = 60;

        }

        private void btnBaslat_Click(object sender, EventArgs e)
        {
            btnBaslat.Enabled = false;
            txtTahmin.Enabled = true;
            oyunTimer.Start();
            uretilenSayi = rnd.Next(1, 101);

            progressBar1.Value = progressBar1.Maximum;

        }

        private void txtTahmin_TextChanged(object sender, EventArgs e)
        {
            if (txtTahmin.Text == "" || !int.TryParse(txtTahmin.Text, out int anlikSayi)
                || (txtTahmin.Text.Contains(" ") && btnTahmin.Enabled))
                btnTahmin.Enabled = false;


            else if (!btnTahmin.Enabled && !txtTahmin.Text.Contains(" "))
                btnTahmin.Enabled = true;
        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            tahminEdilen = Convert.ToInt32(txtTahmin.Text);

            if (tahminEdilen < uretilenSayi)
                lblMesaj.Text = "daha b�y�k bir say� giriniz.";
            else if (tahminEdilen > uretilenSayi)
                lblMesaj.Text = "daha k���k bir say� giriniz.";
            else
            {

                lblMesaj.Text = "Kazand�n�z.";
                oyunTimer.Stop();
                btnBaslat.Enabled = true;
                btnTahmin.Enabled = false;
                txtTahmin.Clear();

            }
        }

        private void oyunTimer_Tick(object sender, EventArgs e)
        {
            progressBar1.Value--;
            btnTahmin.Text = $"Tahmin Et ({progressBar1.Value})";
            if (progressBar1.Value == 0)
            {
                oyunTimer.Stop();
                btnBaslat.Enabled = true;
                { lblMesaj.Text = "Kaybettiniz.."; }
            }

            if (progressBar1.Value >= 30 && progressBar1.Value >= 50)
            {
                lblBilgi.Text = "hen�z zaman var..";
            }
            else if (progressBar1.Value < 30 && progressBar1.Value >= 20)
                lblBilgi.Text = "s�re azal�yor..";

            else if (progressBar1.Value < 20)
                lblBilgi.Text = "s�re �ok az kald�.";
        }

        private void lblBilgi_Click(object sender, EventArgs e)
        {

        }
    }
}
