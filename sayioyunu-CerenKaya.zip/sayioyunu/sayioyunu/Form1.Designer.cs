﻿namespace sayioyunu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnBaslat = new Button();
            label1 = new Label();
            txtTahmin = new TextBox();
            btnTahmin = new Button();
            lblBilgi = new Label();
            progressBar1 = new ProgressBar();
            lblMesaj = new Label();
            oyunTimer = new System.Windows.Forms.Timer(components);
            lblSure = new Label();
            SuspendLayout();
            // 
            // btnBaslat
            // 
            btnBaslat.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnBaslat.Location = new Point(12, 22);
            btnBaslat.Name = "btnBaslat";
            btnBaslat.Size = new Size(353, 39);
            btnBaslat.TabIndex = 0;
            btnBaslat.Text = "Oyunu Başlat";
            btnBaslat.UseVisualStyleBackColor = true;
            btnBaslat.Click += btnBaslat_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 88);
            label1.Name = "label1";
            label1.Size = new Size(196, 15);
            label1.TabIndex = 1;
            label1.Text = "[1-100] aralıığında bir değer giriniz : ";
            // 
            // txtTahmin
            // 
            txtTahmin.Location = new Point(234, 80);
            txtTahmin.Name = "txtTahmin";
            txtTahmin.Size = new Size(131, 23);
            txtTahmin.TabIndex = 2;
            txtTahmin.TextChanged += txtTahmin_TextChanged;
            // 
            // btnTahmin
            // 
            btnTahmin.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnTahmin.Location = new Point(12, 130);
            btnTahmin.Name = "btnTahmin";
            btnTahmin.Size = new Size(353, 42);
            btnTahmin.TabIndex = 3;
            btnTahmin.Text = "Tahmin Et";
            btnTahmin.UseVisualStyleBackColor = true;
            btnTahmin.Click += btnTahmin_Click;
            // 
            // lblBilgi
            // 
            lblBilgi.BackColor = SystemColors.Menu;
            lblBilgi.BorderStyle = BorderStyle.FixedSingle;
            lblBilgi.Location = new Point(12, 192);
            lblBilgi.Name = "lblBilgi";
            lblBilgi.Size = new Size(353, 40);
            lblBilgi.TabIndex = 4;
            lblBilgi.Click += lblBilgi_Click;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(12, 245);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(353, 23);
            progressBar1.TabIndex = 5;
            // 
            // lblMesaj
            // 
            lblMesaj.BackColor = SystemColors.Menu;
            lblMesaj.BorderStyle = BorderStyle.FixedSingle;
            lblMesaj.Location = new Point(12, 284);
            lblMesaj.Name = "lblMesaj";
            lblMesaj.Size = new Size(353, 56);
            lblMesaj.TabIndex = 6;
            // 
            // oyunTimer
            // 
            oyunTimer.Interval = 1000;
            oyunTimer.Tick += oyunTimer_Tick;
            // 
            // lblSure
            // 
            lblSure.AutoSize = true;
            lblSure.Location = new Point(234, 144);
            lblSure.Name = "lblSure";
            lblSure.Size = new Size(0, 15);
            lblSure.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(382, 358);
            Controls.Add(lblSure);
            Controls.Add(lblMesaj);
            Controls.Add(progressBar1);
            Controls.Add(lblBilgi);
            Controls.Add(btnTahmin);
            Controls.Add(txtTahmin);
            Controls.Add(label1);
            Controls.Add(btnBaslat);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnBaslat;
        private Label label1;
        private TextBox txtTahmin;
        private Button btnTahmin;
        private Label lblBilgi;
        private ProgressBar progressBar1;
        private Label lblMesaj;
        private System.Windows.Forms.Timer oyunTimer;
        private Label lblSure;
    }
}