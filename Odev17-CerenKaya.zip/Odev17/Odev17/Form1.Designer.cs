﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtYaz = new TextBox();
            btnEkle = new Button();
            cmbEkle = new ComboBox();
            lstEkle = new ListBox();
            btnHicBirSeySecme = new Button();
            SuspendLayout();
            // 
            // txtYaz
            // 
            txtYaz.Location = new Point(12, 12);
            txtYaz.Name = "txtYaz";
            txtYaz.Size = new Size(252, 23);
            txtYaz.TabIndex = 0;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(270, 12);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(90, 23);
            btnEkle.TabIndex = 1;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // cmbEkle
            // 
            cmbEkle.FormattingEnabled = true;
            cmbEkle.Location = new Point(12, 54);
            cmbEkle.Name = "cmbEkle";
            cmbEkle.Size = new Size(348, 23);
            cmbEkle.TabIndex = 2;
            cmbEkle.SelectedIndexChanged += cmbEkle_SelectedIndexChanged;
            // 
            // lstEkle
            // 
            lstEkle.FormattingEnabled = true;
            lstEkle.ItemHeight = 15;
            lstEkle.Location = new Point(12, 95);
            lstEkle.Name = "lstEkle";
            lstEkle.Size = new Size(348, 289);
            lstEkle.TabIndex = 3;

            // 
            // btnHicBirSeySecme
            // 
            btnHicBirSeySecme.Location = new Point(12, 390);
            btnHicBirSeySecme.Name = "btnHicBirSeySecme";
            btnHicBirSeySecme.Size = new Size(348, 43);
            btnHicBirSeySecme.TabIndex = 4;
            btnHicBirSeySecme.Text = "Hiçbir Şey Seçme";
            btnHicBirSeySecme.UseVisualStyleBackColor = true;
            btnHicBirSeySecme.Click += btnHicBirSeySecme_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(372, 450);
            Controls.Add(btnHicBirSeySecme);
            Controls.Add(lstEkle);
            Controls.Add(cmbEkle);
            Controls.Add(btnEkle);
            Controls.Add(txtYaz);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtYaz;
        private Button btnEkle;
        private ComboBox cmbEkle;
        private ListBox lstEkle;
        private Button btnHicBirSeySecme;
    }
}