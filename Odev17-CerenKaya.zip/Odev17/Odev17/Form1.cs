using System.Diagnostics.Metrics;

namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            cmbEkle.Items.Add("Se�iniz");
            cmbEkle.SelectedIndex = 0;
        }
        private void btnEkle_Click(object sender, EventArgs e)
        {
            string metin = txtYaz.Text;
            if (!string.IsNullOrWhiteSpace(metin))
            {
                if (!(cmbEkle.Items.Contains(metin.ToLower())))
                {
                    cmbEkle.Items.Add(metin);
                    lstEkle.Items.Add(metin);
                    txtYaz.Clear();
                }
                else MessageBox.Show("ayn� dersi ekleyemezsiniz.");
            }


            else
            {
                MessageBox.Show("L�tfen bir metin girin.");
            }
        }

        private void btnHicBirSeySecme_Click(object sender, EventArgs e)
        {
            cmbEkle.SelectedIndex = 0;
            lstEkle.SelectedIndex = -1;
        }

        private void cmbEkle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbEkle.SelectedIndex > 0) { 
            string? metin = cmbEkle.SelectedItem.ToString();
            lstEkle.SelectedIndex = lstEkle.Items.IndexOf(metin);
            MessageBox.Show(" se�ti�iniz ders " + metin);}
            
        }


    }
}

