using Microsoft.EntityFrameworkCore;
using Odev48_API.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// CORS AllowAnyOrigin
builder.Services.AddCors(s => s.AddDefaultPolicy(
               p => p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

// In-memory database
builder.Services.AddDbContext<GaleriContext>(builder => builder.UseInMemoryDatabase("ResimGalerisi"));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
// cors kullan
app.UseCors();

app.UseAuthorization();

app.MapControllers();

// Veritaban�n� in-memory database olarak olu�tur
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<GaleriContext>();
    db.Database.EnsureCreated();
}

app.Run();
