﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Odev48_API.Data;

namespace Odev48_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GaleriController : ControllerBase
    {
        private readonly GaleriContext _galeri;

        public GaleriController(GaleriContext galeri)
        {
            _galeri = galeri;
        }

        [HttpGet("TablolariGetir")]
        public IActionResult TablolariGetir()
        {
            return Ok(_galeri.Tablolar.OrderBy(resim => resim.Id).ToList());
        }
    }
}
