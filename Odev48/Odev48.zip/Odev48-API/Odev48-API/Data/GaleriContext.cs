﻿using Microsoft.EntityFrameworkCore;

namespace Odev48_API.Data
{
    public class GaleriContext : DbContext
    {
        public GaleriContext(DbContextOptions<GaleriContext> options) : base(options)
        {

        }

        public DbSet<Tablo> Tablolar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tablo>().HasData(
                new Tablo { Id = 1, Ressam = "Leonardo da Vinci", YapilmaTarihi = new DateOnly(1503, 01, 01) },
                new Tablo { Id = 2, Ressam = "Vincent van Gogh", YapilmaTarihi = new DateOnly(1889, 05, 01) },
                new Tablo { Id = 3, Ressam = "Pablo Picasso", YapilmaTarihi = new DateOnly(1907, 05, 01) },
                new Tablo { Id = 4, Ressam = "Michelangelo Buonarroti", YapilmaTarihi = new DateOnly(1508, 01, 01) },
                new Tablo { Id = 5, Ressam = "Rembrandt van Rijn", YapilmaTarihi = new DateOnly(1665, 01, 01) }
            );
        }
    }
}
