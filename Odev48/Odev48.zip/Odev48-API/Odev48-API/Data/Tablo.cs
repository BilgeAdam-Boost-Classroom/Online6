﻿namespace Odev48_API.Data
{
    public class Tablo
    {
        public int Id { get; set; }
        public string Ressam { get; set; } = string.Empty;
        public DateOnly YapilmaTarihi { get; set; }
    }

}
