﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Odev48;

    public class TabloDbContext : DbContext
    {
        public TabloDbContext (DbContextOptions<TabloDbContext> options)
            : base(options)
        {
        }

        public DbSet<Odev48.Tablo> Tablo { get; set; } = default!;
    }
