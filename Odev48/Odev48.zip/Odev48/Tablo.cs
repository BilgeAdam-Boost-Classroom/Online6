﻿namespace Odev48
{
    public class Tablo
    {
        public int Id { get; set; }

        public string Ressam { get; set; }

        public DateTime ResminYapılmaTarihi { get; set; }
    }
}
