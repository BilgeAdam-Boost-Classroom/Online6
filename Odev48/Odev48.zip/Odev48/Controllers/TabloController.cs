﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev48;

namespace Odev48.Controllers
{
    public class TabloController : Controller
    {
        private readonly TabloDbContext _context;
        private readonly HttpClient _httpClient;

        public TabloController(TabloDbContext context, HttpClient httpClient)
        {
            _context = context;
            _httpClient = httpClient;
        }

        // GET: Tablo
        public async Task<IActionResult> Index()
        {
            return View(await _httpClient.GetFromJsonAsync<List<Tablo>>("https://localhost:7038/api/Tablo"));
        }

        // GET: Tablo/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7038/api/Tablo/" + id);
            if (tablo == null)
            {
                return NotFound();
            }

            return View(tablo);
        }

        // GET: Tablo/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tablo/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Ressam,ResminYapılmaTarihi")] Tablo tablo)
        {
            if (ModelState.IsValid)
            {
                await _httpClient.PostAsJsonAsync("https://localhost:7038/api/Tablo", tablo);
                return RedirectToAction(nameof(Index));
            }
            return View(tablo);
        }

        // GET: Tablo/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7038/api/Tablo/" + id);

            if (tablo == null)
            {
                return NotFound();
            }
            return View(tablo);
        }

        // POST: Tablo/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Ressam,ResminYapılmaTarihi")] Tablo tablo)
        {
            if (id != tablo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _httpClient.PutAsJsonAsync<Tablo>("https://localhost:7038/api/Tablo/" + id, tablo);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TabloExists(tablo.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tablo);
        }

        // GET: Tablo/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7038/api/Tablo/" + id);
            if (tablo == null)
            {
                return NotFound();
            }

            return View(tablo);
        }

        // POST: Tablo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7038/api/Tablo/" + id);

            if (tablo != null)
            {
                await _httpClient.DeleteAsync("https://localhost:7038/api/Tablo/" + id);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TabloExists(int id)
        {
            return _context.Tablo.Any(e => e.Id == id);
        }
    }
}
