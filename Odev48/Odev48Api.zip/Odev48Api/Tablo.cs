﻿namespace Odev48Api
{
    public class Tablo
    {
        public int Id { get; set; }

        public string Ressam { get; set; }

        public DateTime ResminYapılmaTarihi { get; set; }
    }
}
