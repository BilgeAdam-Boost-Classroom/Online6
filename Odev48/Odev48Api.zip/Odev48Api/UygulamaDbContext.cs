﻿using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace Odev48Api
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base (options)
        {

        }

        public DbSet<Tablo> Tablolar { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Tablo>().HasData(
                new Tablo() { Id = 1, Ressam = "Vincent van Gogh", ResminYapılmaTarihi = new DateTime(1889, 5, 8) },
                new Tablo() { Id = 2, Ressam = "Leonardo da Vinci", ResminYapılmaTarihi = new DateTime(1495, 8, 15) },
                new Tablo() { Id = 3, Ressam = "Pablo Picasso", ResminYapılmaTarihi = new DateTime(1907, 6, 4) },
                new Tablo() { Id = 4, Ressam = "Claude Monet", ResminYapılmaTarihi = new DateTime(1872, 3, 14) },
                new Tablo() { Id = 5, Ressam = "Frida Kahlo", ResminYapılmaTarihi = new DateTime(1939, 7, 25) },
                new Tablo() { Id = 6, Ressam = "Rembrandt", ResminYapılmaTarihi = new DateTime(1642, 6, 15) },
                new Tablo() { Id = 7, Ressam = "Georgia O'Keeffe", ResminYapılmaTarihi = new DateTime(1928, 9, 1) },
                new Tablo() { Id = 8, Ressam = "Salvador Dalí", ResminYapılmaTarihi = new DateTime(1931, 11, 18) },
                new Tablo() { Id = 9, Ressam = "Edvard Munch", ResminYapılmaTarihi = new DateTime(1893, 12, 2) },
                new Tablo() { Id = 10, Ressam = "Henri Matisse", ResminYapılmaTarihi = new DateTime(1905, 4, 20) }
            );



        }
    }
}
