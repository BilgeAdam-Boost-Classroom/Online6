﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Odev48Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TabloController : ControllerBase
    {
        private readonly UygulamaDbContext _db;

        public TabloController(UygulamaDbContext db)
        {
            _db = db;
        }


        [HttpGet]
        public IActionResult Get()
        {
            var Tablolar = _db.Tablolar.ToList();

            return Ok(Tablolar);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var araba = _db.Tablolar.FirstOrDefault(a => a.Id == id);

            if (araba == null)
            {
                return NotFound(); // 404 Not Found döner
            }

            return Ok(araba);
        }

        [HttpPost]
        public IActionResult Post(Tablo tablo)
        {
            if (tablo == null)
            {
                return BadRequest("Araba bilgileri boş olamaz.");
            }

            _db.Tablolar.Add(tablo);
            _db.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = tablo.Id }, tablo);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, Tablo tablo)
        {
            if (tablo == null || id != tablo.Id)
            {
                return BadRequest("Geçersiz istek.");
            }

            if (ModelState.IsValid)
            {
                _db.Update(tablo);
                _db.SaveChanges();
                return NoContent();
            }

            return BadRequest(ModelState);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var araba = _db.Tablolar.Find(id);

            if (araba == null)
            {
                return NotFound();
            }

            _db.Tablolar.Remove(araba);
            _db.SaveChanges();

            return NoContent();
        }
    }
}
