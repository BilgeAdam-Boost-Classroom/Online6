﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev48Api.Migrations
{
    /// <inheritdoc />
    public partial class ilk : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Tablolar",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ressam = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResminYapılmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tablolar", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Tablolar",
                columns: new[] { "Id", "ResminYapılmaTarihi", "Ressam" },
                values: new object[,]
                {
                    { 1, new DateTime(1889, 5, 8, 0, 0, 0, 0, DateTimeKind.Unspecified), "Vincent van Gogh" },
                    { 2, new DateTime(1495, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Leonardo da Vinci" },
                    { 3, new DateTime(1907, 6, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), "Pablo Picasso" },
                    { 4, new DateTime(1872, 3, 14, 0, 0, 0, 0, DateTimeKind.Unspecified), "Claude Monet" },
                    { 5, new DateTime(1939, 7, 25, 0, 0, 0, 0, DateTimeKind.Unspecified), "Frida Kahlo" },
                    { 6, new DateTime(1642, 6, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Rembrandt" },
                    { 7, new DateTime(1928, 9, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Georgia O'Keeffe" },
                    { 8, new DateTime(1931, 11, 18, 0, 0, 0, 0, DateTimeKind.Unspecified), "Salvador Dalí" },
                    { 9, new DateTime(1893, 12, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "Edvard Munch" },
                    { 10, new DateTime(1905, 4, 20, 0, 0, 0, 0, DateTimeKind.Unspecified), "Henri Matisse" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tablolar");
        }
    }
}
