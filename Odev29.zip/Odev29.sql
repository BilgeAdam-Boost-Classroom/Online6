﻿-- SORU 1-)
-- AyHesapla adında, aldığı DATETIME cinsinden değerin üzerinden kaç ay geçtiğinihesaplayan ve 
-- bu değeri geri döndüren bir fonksiyonoluşturunuz. Ardından, Employees tablosundaki her bir çalışan için 
-- işe başlama tarihinden bu yana kaç ay geçtiğini, bu fonksiyonukullanarak listeleyiniz.
GO
CREATE FUNCTION AyHesapla (@Tarih DATETIME)
RETURNS INT
AS
BEGIN 
   DECLARE @KacAy INT
   SET @KacAy = DATEDIFF(MONTH, @Tarih, GETDATE())
RETURN @KacAy
END
GO

SELECT
    E.EmployeeID, 
	CONCAT (E.FirstName, N' ' ,E.LastName) [Tam Ad], 
	dbo.AyHesapla(E.HireDate)[Kaç Aydır Çalışıyor]
FROM Employees [E]

-- SORU 2-)
-- İki tarih arasındaki farkı alan ve bu farkı gün olarakdöndüren bir fonksiyonyazınız. 
-- Daha sonra orderstablosundaki her satır içinOrderDateile ShippedDatearasındaki gün sayısını, 
-- bu fonksiyonukullanarak listeleyiniz.
GO
CREATE FUNCTION TarihlerFarki (@Tarih1 DATE, @Tarih2 DATE)
RETURNS INT
AS
BEGIN
   DECLARE @GunSayisi INT;
   SET @GunSayisi = DATEDIFF(DAY, @Tarih1, @Tarih2);
RETURN @GunSayisi;
END
GO

SELECT 
   O.OrderID, 
   O.OrderDate, 
   O.ShippedDate,  
   dbo.TarihlerFarki(O.OrderDate, O.ShippedDate) [Gün Farkı]
FROM Orders [O]

-- SORU 3-)
-- Employees tablosundan firstname’leri, dışarıdan gönderilen harf ile başlayanları tablo olarak döndüren 
-- fonksiyon yazınız.
-- Ardından bu fonksiyonu kullanarak A ile başlayanları listeleyiniz.
GO
ALTER FUNCTION  BasHarfeGoreFiltrele(@Harf NVARCHAR(1), @TabloAdi NVARCHAR(10))
RETURNS TABLE
AS
RETURN 
( 
   SELECT 
      E.FirstName,
	  E.LastName
   FROM Employees [E]
   WHERE FirstName LIKE  @Harf + N'%'
)
GO
  
SELECT * FROM BasHarfeGoreFiltrele(N'A' , N'Employees')

-- SORU 4-)
-- Order details tablosundaki unitprice’ların kırpılmış ortalamasını hesaplayan stored procedure yazınız. 
-- (Kırpılmış ortalama: En küçük ve en büyük değerlerdahil edilmeden hesaplanan aritmetik ortalamadır. 
-- Bölerken,(terim sayısı-2) ’ye bölünmelidir.)
GO
ALTER PROC spKirpilmisOrtalamaHesapla
AS
   DECLARE @GeciciTablo TABLE 
    (
        OrderID INT,
        UnitPrice MONEY,
        KirpilmisOrtalama MONEY
    );

   DECLARE @KirpilmisOrtalama MONEY;

   SELECT @KirpilmisOrtalama = (SUM(OD.UnitPrice) - MAX(OD.UnitPrice) - MIN(OD.UnitPrice))/ (COUNT(OD.UnitPrice) -2)
   FROM [Order Details] [OD]

   INSERT INTO  @GeciciTablo 
   SELECT OD.OrderID, OD.UnitPrice, @KirpilmisOrtalama
   FROM [Order Details] OD;

    SELECT * FROM @GeciciTablo 
GO

   
EXEC spKirpilmisOrtalamaHesapla;
   






























-- STORED PROCEDURE - FUNCTION ARASINDAKİ FARKLAR
-- Fonksiyonlar her zaman geriye bir değer döndürürler (Sayı, String, Tablo, Vs.) Stored Prosedurler ise geriye bir değer döndürebilir ya da döndürmeyebilirler.
-- Fonksiyonlarda sadece giriş parametreleri vardır fakat Stored Prosedurler ise
-- Fonkisyonlar sistem tanımlı ya da kullanıcı tanımlı olabilir