--1

GO
CREATE FUNCTION AyHesapla(@deger DATETIME)
RETURNS INT
AS
	BEGIN
		RETURN DATEDIFF(MONTH,@Deger,GETDATE())
	END
GO

SELECT FirstName,LastName, dbo.AyHesapla(BirthDate) FROM Employees

--2

GO
CREATE FUNCTION GunFark(@Ilk DATETIME,@Son DATETIME)
RETURNS INT
AS
	BEGIN
		RETURN DATEDIFF(DAY, @Ilk, @Son)
	END
GO

SELECT OrderID ,OrderDate, ShippedDate, dbo.GunFark(OrderDate,ShippedDate) FROM Orders

--3

GO
CREATE FUNCTION HarfleBaslayanlar(@deger NVARCHAR(1))
RETURNS TABLE
AS
	RETURN SELECT * FROM Employees
			WHERE LEFT(FirstName , 1) = @deger
GO

SELECT * FROM dbo.HarfleBaslayanlar(N'A')

--4

GO
CREATE PROC KirpilmisOrtalama
AS
	SELECT (SUM(UnitPrice)-MAX(UnitPrice)-MIN(UnitPrice))/(COUNT(UnitPrice) - 2)
	FROM [Order Details]
GO

KirpilmisOrtalama