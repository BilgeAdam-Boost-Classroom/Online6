﻿--1)AyHesapla adında, aldığı DATETIME cinsinden değerin üzerinden kaç ay geçtiğinihesaplayan
--ve bu değeri geri döndüren bir fonksiyonoluşturunuz. Ardından, 
--Employees tablosundaki her bir çalışan için işe başlama tarihinden bu yana kaç ay geçtiğini, bu fonksiyonukullanarak listeleyiniz.

CREATE FUNCTION AyHesapla (@date DATETIME)
RETURNS INT
AS
BEGIN
    DECLARE @gecenAy INT
    SELECT @gecenAy = DATEDIFF(MONTH, @date, GETDATE())
    RETURN @gecenAy
END

SELECT FirstName, LastName, HireDate, dbo.AyHesapla(HireDate) AS [KAÇ AY GEÇTİ]
FROM Employees

--İki tarih arasındaki farkı alan ve bu farkı gün olarakdöndüren bir fonksiyonyazınız. Daha sonra orderstablosundaki her satır içinOrderDateile ShippedDatearasındaki gün sayısını,
--bu fonksiyonukullanarak listeleyiniz.
CREATE FUNCTION TarihFarkı (@date1 DATETIME, @date2 DATETIME)
RETURNS INT
AS
BEGIN
	DECLARE @sonuc INT
	SET @sonuc = ABS(DATEDIFF(DAY, @date1, @date2))
	RETURN @sonuc
END

SELECT OrderID, OrderDate, ShippedDate, dbo.TarihFarkı(OrderDate, ShippedDate)[GÜN FARKI] FROM Orders 


--
-- Harfle başlayan isimleri tablo olarak döndüren fonksiyon
ALTER FUNCTION HarfileBaslayanlar (@harf nvarchar(1))
RETURNS TABLE
AS
RETURN
    SELECT *
    FROM Employees
    WHERE FirstName LIKE @harf + '%';


SELECT FirstName FROM dbo.HarfileBaslayanlar('j')

--Order details tablosundaki unitprice’ların kırpılmış ortalamasını hesaplayan stored procedure yazınız. (Kırpılmış ortalama: En küçük ve en büyük değerlerdahil edilmeden
--hesaplanan aritmetik ortalamadır. Bölerken,(terim sayısı-2) ’ye bölünmelidir.)
CREATE PROCEDURE UnitPriceKirpilmisOrt
	@KirpilmisOrt DECIMAL OUT
AS
BEGIN
	SELECT @KirpilmisOrt = (SUM(UnitPrice) - (MAX(UnitPrice) + MIN(UnitPrice))) / (COUNT(*) - 2)  
	FROM [Order Details]
END
	
DECLARE @kirpilmisOrt DECIMAL
EXEC UnitPriceKirpilmisOrt @KirpilmisOrt OUT
PRINT @KirpilmisOrt