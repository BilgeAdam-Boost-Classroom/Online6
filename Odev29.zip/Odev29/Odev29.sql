﻿-- SORU 1) AyHesapla adında, aldığı DATETIME cinsinden değerin üzerinden kaç ay geçtiğini hesaplayan ve bu 
--değeri geri döndüren bir fonksiyon oluşturunuz. Ardından, Employees tablosundaki her bir çalışan için işe 
--başlama tarihinden bu yana kaç ay geçtiğini, bu fonksiyonu kullanarak listeleyiniz.

GO

CREATE FUNCTION AyHesapla(@Tarih DATETIME)
	RETURNS INT
AS
	BEGIN
		RETURN DATEDIFF(MONTH, @Tarih, GETDATE())
	END

GO

SELECT FirstName, LastName, dbo.AyHesapla(HireDate) [Çalıştığı Ay Sayısı] FROM Employees

-- SORU 2) İki tarih arasındaki farkı alan ve bu farkı gün olarakdöndüren bir fonksiyon yazınız. 
-- Daha sonra orderstablosundaki her satır içinOrderDateile ShippedDatearasındaki gün sayısını, bu fonksiyonu kullanarak listeleyiniz.

GO

CREATE FUNCTION GunHesapla(@IlkTarih DATETIME, @IkinciTarih DATETIME)
	RETURNS INT
AS
BEGIN
	IF @IkinciTarih > @IlkTarih
		RETURN DATEDIFF(DAY, @IlkTarih, @IkinciTarih)
	RETURN DATEDIFF(DAY, @IkinciTarih, @IlkTarih)
END

GO

SELECT 
	FORMAT(OrderDate, 'dd/MM/yyyy', 'TR') [Sipariş Tarihi],
	FORMAT(ShippedDate, 'dd/MM/yyyy', 'TR') [Kargo Tarihi], 
	dbo.GunHesapla(OrderDate, ShippedDate) [Gün Farkı] 
FROM Orders

-- SORU 3) Employees tablosundan firstname’leri, dışarıdan gönderilen harf ile başlayanları tablo olarak döndüren fonksiyon yazınız.
-- Ardından bu fonksiyonu kullanarak A ile başlayanları listeleyiniz.

GO

CREATE FUNCTION BasHarfIleAdlar(@Harf NVARCHAR(1))
	RETURNS TABLE
AS
	RETURN 
	(
		SELECT * FROM Employees WHERE LEFT(FirstName, 1) = @Harf
	);
GO

SELECT * FROM BasHarfIleAdlar('A')

-- SORU 4) Order details tablosundaki unitprice’ların kırpılmış ortalamasını hesaplayan stored procedure yazınız. 
-- (Kırpılmış ortalama: En küçük ve en büyük değerlerdahil edilmeden hesaplanan aritmetik ortalamadır. 
--Bölerken,(terim sayısı-2) ’ye bölünmelidir.)

GO

CREATE PROC KirpilmisOrt
AS
	SELECT (SUM(UnitPrice) - MAX(UnitPrice) - MIN(UnitPrice)) / (COUNT(UnitPrice) - 2) [Kırpılmış Ortalama] FROM [Order Details]
GO

EXEC KirpilmisOrt