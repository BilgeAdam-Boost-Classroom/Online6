using ODEV31.Models;

namespace ODEV31
{
    public partial class Form1 : Form
    {
        NorthwndContext db = new NorthwndContext();
        public Form1()
        {
            InitializeComponent();
            GetData();
        }

        private void GetData()
        {
            dgvTerritories.DataSource = db.Territories.ToList();
        }

        private void btnAddTerritory_Click(object sender, EventArgs e)
        {
            Territory territory = new Territory();

            string terId = txtTerId.Text.Trim();
            string terDesc = txtTerDesc.Text.Trim();
            int regID = Convert.ToInt32(txtRegId.Text);

            territory.TerritoryId = terId;
            territory.TerritoryDescription = terDesc;
            territory.RegionId = regID;

            db.Territories.Add(territory);

            db.SaveChanges();

            GetData();
        }

        private void btnDeleteTerritory_Click(object sender, EventArgs e)
        {
            string delTerId = txtDelTerId.Text.Trim();

            var getTerritory = db.Territories.FirstOrDefault(ter => ter.TerritoryId == delTerId);
            if (getTerritory == null) return;

            db.Territories.Remove(getTerritory);
            db.SaveChanges(); 
            GetData();
        }

        private void btnUpdateTerritory_Click(object sender, EventArgs e)
        {
            string uptTerId = txtUptTerId.Text.Trim();

            var getTerritory = db.Territories.FirstOrDefault(ter => ter.TerritoryId == uptTerId);
            if (getTerritory == null) return;

            getTerritory.TerritoryId = txtTerId.Text;
            getTerritory.TerritoryDescription = txtTerDesc.Text;
            getTerritory.RegionId = Convert.ToInt32(txtRegId.Text);

            db.SaveChanges();
            GetData();
        }

        private void dgvTerritories_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvTerritories.SelectedRows.Count == 0) return;

            Territory selectedTerritory = (Territory)dgvTerritories.SelectedRows[0].DataBoundItem;

            txtTerId.Text = selectedTerritory.TerritoryId.Trim();
            txtUptTerId.Text = selectedTerritory.TerritoryId.Trim();
            txtDelTerId.Text = selectedTerritory.TerritoryId.Trim();

            txtTerDesc.Text = selectedTerritory.TerritoryDescription.Trim();
            txtRegId.Text = selectedTerritory.RegionId.ToString().Trim();

        }
    }
}
