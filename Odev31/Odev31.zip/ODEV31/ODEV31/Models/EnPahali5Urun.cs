﻿using System;
using System.Collections.Generic;

namespace ODEV31.Models;

public partial class EnPahali5Urun
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public string CompanyName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }
}
