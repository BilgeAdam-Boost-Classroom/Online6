﻿namespace ODEV31
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvTerritories = new DataGridView();
            groupBox1 = new GroupBox();
            btnAddTerritory = new Button();
            txtRegId = new TextBox();
            txtTerId = new TextBox();
            label3 = new Label();
            label1 = new Label();
            txtTerDesc = new TextBox();
            label2 = new Label();
            groupBox2 = new GroupBox();
            btnDeleteTerritory = new Button();
            txtDelTerId = new TextBox();
            label4 = new Label();
            groupBox3 = new GroupBox();
            btnUpdateTerritory = new Button();
            txtUptTerId = new TextBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvTerritories).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // dgvTerritories
            // 
            dgvTerritories.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvTerritories.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvTerritories.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTerritories.Location = new Point(12, 12);
            dgvTerritories.Name = "dgvTerritories";
            dgvTerritories.Size = new Size(524, 363);
            dgvTerritories.TabIndex = 0;
            dgvTerritories.SelectionChanged += dgvTerritories_SelectionChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnAddTerritory);
            groupBox1.Controls.Add(txtRegId);
            groupBox1.Controls.Add(txtTerId);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtTerDesc);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(542, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(253, 161);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Add Territory";
            // 
            // btnAddTerritory
            // 
            btnAddTerritory.Location = new Point(14, 109);
            btnAddTerritory.Name = "btnAddTerritory";
            btnAddTerritory.Size = new Size(233, 40);
            btnAddTerritory.TabIndex = 2;
            btnAddTerritory.Text = "Add Territory";
            btnAddTerritory.UseVisualStyleBackColor = true;
            btnAddTerritory.Click += btnAddTerritory_Click;
            // 
            // txtRegId
            // 
            txtRegId.Location = new Point(101, 80);
            txtRegId.Name = "txtRegId";
            txtRegId.Size = new Size(146, 23);
            txtRegId.TabIndex = 7;
            // 
            // txtTerId
            // 
            txtTerId.Location = new Point(101, 22);
            txtTerId.Name = "txtTerId";
            txtTerId.Size = new Size(146, 23);
            txtTerId.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 83);
            label3.Name = "label3";
            label3.Size = new Size(61, 15);
            label3.TabIndex = 6;
            label3.Text = "Region ID:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 25);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 2;
            label1.Text = "Territory ID:";
            // 
            // txtTerDesc
            // 
            txtTerDesc.Location = new Point(101, 51);
            txtTerDesc.Name = "txtTerDesc";
            txtTerDesc.Size = new Size(146, 23);
            txtTerDesc.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 54);
            label2.Name = "label2";
            label2.Size = new Size(81, 15);
            label2.TabIndex = 4;
            label2.Text = "Territory Desc:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnDeleteTerritory);
            groupBox2.Controls.Add(txtDelTerId);
            groupBox2.Controls.Add(label4);
            groupBox2.Location = new Point(542, 169);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(253, 100);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Delete Territory";
            // 
            // btnDeleteTerritory
            // 
            btnDeleteTerritory.ForeColor = Color.Red;
            btnDeleteTerritory.Location = new Point(14, 54);
            btnDeleteTerritory.Name = "btnDeleteTerritory";
            btnDeleteTerritory.Size = new Size(233, 40);
            btnDeleteTerritory.TabIndex = 8;
            btnDeleteTerritory.Text = "Delete Territory";
            btnDeleteTerritory.UseVisualStyleBackColor = true;
            btnDeleteTerritory.Click += btnDeleteTerritory_Click;
            // 
            // txtDelTerId
            // 
            txtDelTerId.Location = new Point(101, 22);
            txtDelTerId.Name = "txtDelTerId";
            txtDelTerId.Size = new Size(146, 23);
            txtDelTerId.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(28, 25);
            label4.Name = "label4";
            label4.Size = new Size(67, 15);
            label4.TabIndex = 8;
            label4.Text = "Territory ID:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnUpdateTerritory);
            groupBox3.Controls.Add(txtUptTerId);
            groupBox3.Controls.Add(label5);
            groupBox3.Location = new Point(542, 275);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(253, 100);
            groupBox3.TabIndex = 10;
            groupBox3.TabStop = false;
            groupBox3.Text = "Update Territory";
            // 
            // btnUpdateTerritory
            // 
            btnUpdateTerritory.ForeColor = SystemColors.ControlText;
            btnUpdateTerritory.Location = new Point(14, 54);
            btnUpdateTerritory.Name = "btnUpdateTerritory";
            btnUpdateTerritory.Size = new Size(233, 40);
            btnUpdateTerritory.TabIndex = 8;
            btnUpdateTerritory.Text = "Update Territory";
            btnUpdateTerritory.UseVisualStyleBackColor = true;
            btnUpdateTerritory.Click += btnUpdateTerritory_Click;
            // 
            // txtUptTerId
            // 
            txtUptTerId.Location = new Point(101, 22);
            txtUptTerId.Name = "txtUptTerId";
            txtUptTerId.Size = new Size(146, 23);
            txtUptTerId.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(28, 25);
            label5.Name = "label5";
            label5.Size = new Size(67, 15);
            label5.TabIndex = 8;
            label5.Text = "Territory ID:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(806, 384);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dgvTerritories);
            Name = "Form1";
            Text = "Territorries";
            ((System.ComponentModel.ISupportInitialize)dgvTerritories).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvTerritories;
        private GroupBox groupBox1;
        private Label label1;
        private TextBox txtTerId;
        private TextBox txtTerDesc;
        private Label label2;
        private TextBox txtRegId;
        private Label label3;
        private Button btnAddTerritory;
        private GroupBox groupBox2;
        private Button btnDeleteTerritory;
        private TextBox txtDelTerId;
        private Label label4;
        private GroupBox groupBox3;
        private Button btnUpdateTerritory;
        private TextBox txtUptTerId;
        private Label label5;
    }
}
