﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev45.Data;
using Odev45.Models;

namespace Odev45.Controllers
{
    public class HayvanController : Controller
    {
        private readonly UygulamaDbContext _context;
        private readonly IWebHostEnvironment _env;

        public HayvanController(UygulamaDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET: Hayvan
        public IActionResult Index()
        {
            return View();
        }

        // GET: Hayvan/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvan
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        // GET: Hayvan/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Hayvan/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Ad,ResimAdi,Resim")] HayvanViewModel vm)
        {
            if (ModelState.IsValid)
            {
                Hayvan hayvan = new Hayvan();
                string uzanti = Path.GetExtension(vm.Resim.FileName);
                string yeniDosya = Guid.NewGuid() + uzanti;
                string yol = Path.Combine(_env.WebRootPath, "img", "upload", yeniDosya);
                using (var fs = new FileStream(yol, FileMode.CreateNew))
                {
                    vm.Resim.CopyTo(fs);
                }
                hayvan.Ad = vm.Ad;
                hayvan.ResimAdi = yeniDosya;
                _context.Add(hayvan);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(vm);
        }

        // GET: Hayvan/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvan.FindAsync(id);
            if (hayvan == null)
            {
                return NotFound();
            }
            HayvanDuzenleViewModel vm = new HayvanDuzenleViewModel() { Id = hayvan.Id, Ad = hayvan.Ad, ResimAdi = hayvan.ResimAdi };
            return View(vm);
        }

        // POST: Hayvan/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Ad,ResimAdi,Resim")] HayvanDuzenleViewModel vm)
        {
            if (id != vm.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                Hayvan hayvan = _context.Hayvan.Find(vm.Id);
                try
                {
                    if (hayvan == null) { return NotFound(); }

                    if (vm.Resim != null)
                    {
                        System.IO.File.Delete(Path.Combine(_env.WebRootPath, "img", "upload", hayvan.ResimAdi));
                        string uzanti = Path.GetExtension(vm.Resim.FileName);
                        string yeniDosya = Guid.NewGuid() + uzanti;
                        string yol = Path.Combine(_env.WebRootPath, "img", "upload", yeniDosya);
                        using (var fs = new FileStream(yol, FileMode.CreateNew))
                        {
                            vm.Resim.CopyTo(fs);
                        }
                        hayvan.ResimAdi = yeniDosya;
                    }
                    hayvan.Ad = vm.Ad;
                    _context.Update(hayvan);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HayvanExists(hayvan.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(vm);
        }

        // GET: Hayvan/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvan
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        // POST: Hayvan/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var hayvan = await _context.Hayvan.FindAsync(id);
            if (hayvan != null)
            {
                System.IO.File.Delete(Path.Combine(_env.WebRootPath, "img", "upload", hayvan.ResimAdi));
                _context.Hayvan.Remove(hayvan);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HayvanExists(int id)
        {
            return _context.Hayvan.Any(e => e.Id == id);
        }
    }
}
