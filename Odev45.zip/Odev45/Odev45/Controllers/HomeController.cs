﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev45.Data;

namespace Odev45.Controllers
{
    public class HomeController : Controller
    {
        private readonly UygulamaDbContext _context;
        private readonly IWebHostEnvironment _env;

        public HomeController(UygulamaDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET: Home
        public async Task<IActionResult> Index()
        {
            return View(await _context.Hayvanlar.ToListAsync());
        }

        // GET: Home/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvanlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        // GET: Home/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Home/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(IFormFile img, Hayvan hayvan)
        {
            if (img == null)
                return NotFound();

            string ext = Path.GetExtension(img.FileName);
            string yeniResim = Guid.NewGuid() + ext;
            string yol = Path.Combine(_env.WebRootPath, "img", yeniResim);

            using (var fs = new FileStream(yol, FileMode.CreateNew))
            {
                img.CopyTo(fs);
            }

            hayvan.ResimIsmi = yeniResim;

            if (ModelState.IsValid)
            {
                _context.Add(hayvan);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(hayvan);
        }

        // GET: Home/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvanlar.FindAsync(id);
            if (hayvan == null)
            {
                return NotFound();
            }
            return View(hayvan);
        }

        // POST: Home/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(IFormFile? img, int id, Hayvan hayvan)
        {
            if (id != hayvan.Id)
            {
                return NotFound();
            }

            if (img != null)
            {
                string eskiResim = Path.Combine(_env.WebRootPath, "img", hayvan.ResimIsmi);
                System.IO.File.Delete(eskiResim);

                string ext = Path.GetExtension(img.FileName);
                string yeniResim = Guid.NewGuid() + ext;
                string yol = Path.Combine(_env.WebRootPath, "img", yeniResim);

                using (var fs = new FileStream(yol, FileMode.CreateNew))
                {
                    img.CopyTo(fs);
                }

                hayvan.ResimIsmi = yeniResim;

            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(hayvan);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HayvanExists(hayvan.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(hayvan);
        }

        // GET: Home/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvanlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        // POST: Home/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var hayvan = await _context.Hayvanlar.FindAsync(id);
            if (hayvan != null)
            {
                _context.Hayvanlar.Remove(hayvan);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HayvanExists(int id)
        {
            return _context.Hayvanlar.Any(e => e.Id == id);
        }
    }
}
