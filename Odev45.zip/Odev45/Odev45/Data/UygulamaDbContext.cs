﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Odev45.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext (DbContextOptions<UygulamaDbContext> options) : base(options)
        {
        }

        public DbSet<Hayvan> Hayvan { get; set; }

    }
}
