﻿using Microsoft.EntityFrameworkCore;
using System;

namespace Odev45.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {
        }

        public DbSet<Hayvan> Hayvanlar { get; set; }

        
    }
}
