﻿using Microsoft.EntityFrameworkCore;

namespace Odev45.Data
{
    public class UygulamaDbContext:DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {

        }

        public DbSet<Hayvan> Hayvanlar {  get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Hayvan>().HasData(
                new Hayvan() { Id=1,Ad="Kuş",ResimIsmi="kus.jpg"},
                new Hayvan() { Id=2,Ad="At",ResimIsmi="at.jpg"},
                new Hayvan() { Id=3,Ad="Kaplan",ResimIsmi="kaplan.jpg"}
                );
        }
    }
}
