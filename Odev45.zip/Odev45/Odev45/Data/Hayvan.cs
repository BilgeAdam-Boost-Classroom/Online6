﻿namespace Odev45.Data
{
    public class Hayvan
    {
        public int Id { get; set; }

        public string Ad { get; set; } = null!;

        public string ResimAdi { get; set; } = null!;
    }
}
