﻿namespace Odev45.Models
{
    public class HayvanDuzenleViewModel
    {

        public int Id { get; set; }

        public string Ad { get; set; } = null!;

        public IFormFile? Resim { get; set; }

        public string? ResimAdi { get; set; } = null!;
    }
}
