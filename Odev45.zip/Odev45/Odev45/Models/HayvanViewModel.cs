﻿namespace Odev45.Models
{
    public class HayvanViewModel
    {
        public string Ad { get; set; } = null!;

        public IFormFile Resim { get; set; } = null!;
    }
}
