﻿using Microsoft.AspNetCore.Mvc;
using Odev45.Data;

namespace Odev45.Components
{
    public class ListeleViewComponent:ViewComponent
    {
        public IViewComponentResult Invoke(IEnumerable<Hayvan> liste)
        {
           return View(liste);
        }
    }
}
