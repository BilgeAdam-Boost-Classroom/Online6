﻿using Microsoft.AspNetCore.Mvc;
using Odev45.Data;

namespace Odev45.Components
{
    public class HayvanViewComponent : ViewComponent
    {
        private readonly UygulamaDbContext _db;

        public HayvanViewComponent(UygulamaDbContext db)
        {
            _db = db;
        }

        public IViewComponentResult Invoke()
        {
            return View(_db.Hayvan.ToList());
        }
    }
}
