﻿-- 1-)
SELECT ProductID, MAX(UnitPrice) FROM [Order Details] 
WHERE UnitPrice < (SELECT AVG(UnitPrice) FROM [Order Details] )
GROUP BY ProductID
ORDER BY MAX(UnitPrice)DESC


-- 2-)
SELECT RegionDescription, STRING_AGG(TerritoryDescription, N',')[TerritoryDescription]
FROM Region[R] 
INNER JOIN Territories[T] ON R.RegionID = T.RegionID
GROUP BY RegionDescription;


-- 3-)
SELECT C.CustomerID, C.CompanyName, C.ContactName, C.PostalCode 
FROM Customers[C]
WHERE LEN(C.PostalCode) > 5

-- 4-) 
SELECT E.EmployeeID, E.FirstName, E.LastName 
FROM Employees [E]
WHERE E.EmployeeID =
(  
   SELECT C.CategoryID 
   FROM Categories [C] 
   WHERE C.CategoryName = N'seafood'
)

-- 5-)
SELECT P.ProductName, C.CategoryName 
FROM Products[P] 
INNER JOIN Categories[C] ON P.CategoryID = C.CategoryID
ORDER BY P.ProductName DESC;

-- 6-)
SELECT P.ProductName 
FROM Products[P] 
WHERE P.CategoryID = (SELECT C.CategoryId FROM Categories[C] WHERE P.CategoryID = C.CategoryID)
ORDER BY P.ProductName DESC;


SELECT C.CategoryName
FROM Categories [C]
INNER JOIN 
(
    SELECT ProductName, CategoryID
    FROM Products
) [T] ON C.CategoryID = T.CategoryID
ORDER BY T.ProductName DESC;

-- 7-)
SELECT P.ProductName, P.UnitsInStock, P.UnitPrice
FROM Products[P]
WHERE P.UnitPrice > 50 AND P.UnitsInStock > 50
ORDER BY P.UnitsInStock ASC;

-- 8-)
SELECT ProductName, UnitsInStock, UnitPrice
FROM Products
WHERE 
UnitPrice IN
(
    SELECT UnitPrice
    FROM Products
    WHERE UnitPrice > 50 
)
AND
UnitsInStock IN
(
    SELECT UnitsInStock
    FROM Products
    WHERE UnitsInStock > 50 
)
ORDER BY UnitsInStock ASC;

-- 9-)
SELECT P.ProductName, C.CategoryName, S.CompanyName 
FROM Products [P] 
INNER JOIN Categories [C] ON P.CategoryID = C.CategoryID
INNER JOIN Suppliers [S] ON S.SupplierID = P.SupplierID