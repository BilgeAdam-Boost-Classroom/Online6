-- 1.) Order Details tablosundan UnitPrice'�, ortalama unitprice'dan k���k olanlar�n productid ve unitprice kolonlar�nn�, 
--unitprice'a g�re azalan s�rada ve productid'leri tekrarlamayacak �ekilde getiren sorguyu yaz�n�z.(subquery kullanarak)
SELECT DISTINCT ProductID, UnitPrice FROM [Order Details] WHERE UnitPrice < (SELECT AVG(UnitPrice) FROM [Order Details])
ORDER BY UnitPrice DESC, ProductID;

--2.)Region tablosu ile Territories tablosunu inner join yaparak, territorydescription ve regiondescription kolonlar�n� getiren sorguyu yaz
SELECT Territories.TerritoryDescription, Region.RegionDescription FROM Territories
INNER JOIN Region ON Territories.RegionID = Region.RegionID;

--3.)Customers tablosundan postalcode de�erinin uzunlugu 5 karakterden fazla olanlar� getiren sorguyu yaz
SELECT * FROM Customers WHERE LEN(PostalCode) > 5;

--4.)Employees tablosundan employeeid'si; categories tablosundaki categoryname'i, seafood olan�n categoryid'sine e�it olan�n; 
--employeeid, firstname, lastname bilgilerini getiren sorguyu yaz.(subquery kullanarak)
SELECT E.EmployeeID, E.FirstName, E.LastName FROM Employees E
JOIN Categories C ON E.EmployeeID = C.CategoryID WHERE C.CategoryName = 'Seafood';

--5.)Product tablosu ile categories tablosunu inner join yaparak productname ve categoryname kolonlar�n� productname'e g�re 
--azalan s�rada getiren sorguyu yaz
SELECT Products.ProductName, Categories.CategoryName
FROM Products
INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID
ORDER BY Products.ProductName DESC;

--6.)5.sorunun sonucunu subquery kullanarak bul
SELECT ProductName, (SELECT CategoryName FROM Categories WHERE CategoryID = Products.CategoryID) AS CategoryName FROM Products
ORDER BY ProductName DESC;

--7.)Products tablosundan unitsinstock de�eri ve unitprice de�eri 50'den b�y�k olanlar�n productname, unitsinstock ve unitprice kolonlar�n�
--unitsinstock de�erine g�re artan s�rada getiren sorguyu yaz
SELECT ProductName, UnitsInStock, UnitPrice FROM Products WHERE UnitsInStock > 50 AND UnitPrice > 50
ORDER BY UnitsInStock ASC;

--8.)7.sorunun sonucunu subquery kullanarak bul
SELECT ProductName, UnitsInStock, UnitPrice FROM Products WHERE UnitsInStock > 50 AND UnitPrice > 50 AND 
UnitsInStock = (
    SELECT MAX(UnitsInStock)
    FROM Products
    WHERE UnitsInStock > 50 AND UnitPrice > 50
);

--9.)Products, categories ve suppliers tablolar�n� inner join yaparak, product tablosundaki productname, categories tablosundaki categoryname
--ve suppliers tablosundaki companyname kolonlar�n� getiriniz
SELECT P.ProductName, C.CategoryName, S.CompanyName FROM Products P
INNER JOIN Categories C ON P.CategoryID = C.CategoryID
INNER JOIN Suppliers S ON P.SupplierID = S.SupplierID;