﻿--Order details tablosundan unitprice ı ortalama unitprice'dan küçük olanlann productid ve unitprice kolonlarını,
--unitprice'a göre azalan sırada productid'leri tekrarlamayacak
SELECT DISTINCT ProductID, UnitPrice
FROM [Order Details]
WHERE UnitPrice < (SELECT AVG(UnitPrice) FROM [Order Details])
ORDER BY UnitPrice DESC

--Region tablosu ile territories tablosunu inner join yaparak, territorydescription ve regiondescription kolonlann, getiren sorguyu yazınız.
SELECT Territories.TerritoryDescription, Region.RegionDescription
FROM Territories
INNER JOIN Region ON Territories.RegionID = Region.RegionID

--Customers tablosundan postalcode degerinin uzunluğu 5 karakterden fazla olanları getiren sorguyu YAZINIZ
SELECT *
FROM Customers c
WHERE LEN(c.PostalCode) > 5

--Employees tablosundan employeeid'si; categories tablosundaki categoryname'i seafood olanın categoryid'sine eşit olanın; employeeid.,  fìrstname, lastname bilgilerini getiren sorgu
SELECT *
FROM Employees e
WHERE e.EmployeeID = (SELECT Categories.CategoryID FROM Categories WHERE Categories.CategoryName = 'seafood' )

--Product tablosu ile Categories tablosunu inner join İLE birleştirerek productname ve categoryname sütunlarını, productname'e göre azalan sırayla 
SELECT Products.ProductName, Categories.CategoryName
FROM Products
INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID
ORDER BY Products.ProductName DESC

--5. soru subquery
SELECT 
	ProductName,
	(SELECT c.CategoryName FROM Categories c WHERE c.CategoryID = P.CategoryID) [CategoryName]
FROM Products P
ORDER BY ProductName DESC;

--Products tablosundan unitsinstock değeri ve unitprice değeri 50'den büyük olanlanların productname,unitsinstock ve unitprice kolonlarını unitsinstock degerine göre artan sırada getiren sorgu
SELECT 
    ProductName,
    UnitsInStock,
    UnitPrice
FROM Products
WHERE UnitsInStock > 50 AND UnitPrice > 50
ORDER BY UnitsInStock ASC;

--subquery
SELECT 
    ProductName,
    UnitsInStock,
    UnitPrice
FROM Products
WHERE UnitsInStock IN (SELECT UnitsInStock, UnitPrice FROM Products p WHERE UnitsInStock > 50 AND UnitPrice > 50)

--
SELECT 
    P.ProductName,
    C.CategoryName,
    S.CompanyName
FROM 
    Products P
INNER JOIN 
    Categories C ON P.CategoryID = C.CategoryID
INNER JOIN 
    Suppliers S ON P.SupplierID = S.SupplierID;


