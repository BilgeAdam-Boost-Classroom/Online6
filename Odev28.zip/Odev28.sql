--1

SELECT ProductID,UnitPrice
FROM [Order Details]
WHERE UnitPrice <(SELECT AVG(UnitPrice) FROM [Order Details])
ORDER BY UnitPrice DESC

--2

SELECT TerritoryDescription,RegionDescription
FROM Region
JOIN Territories ON Territories.RegionID=Region.RegionID

--3

SELECT * FROM Customers 
WHERE LEN(PostalCode)>5

--4

SELECT EmployeeID, FirstName,LastName FROM Employees
WHERE EmployeeID IN (SELECT CategoryID FROM Categories
							WHERE CategoryName=N'SEAFOOD')

--5

SELECT ProductName, CategoryName FROM Products
JOIN Categories ON Categories.CategoryID=Products.CategoryID
ORDER BY ProductName DESC

--6

SELECT 
	ProductName, 
	(SELECT CategoryName FROM Categories 
		WHERE CategoryID=Products.CategoryID) CategoryName
FROM Products 
ORDER BY ProductName DESC

--7

SELECT ProductName,UnitsInStock,UnitPrice
FROM Products
WHERE UnitsInStock>50 AND UnitPrice>50
ORDER BY UnitPrice 

--8

SELECT ProductName,UnitsInStock,UnitPrice
FROM Products p
WHERE EXISTS (SELECT* FROM Products 
				WHERE UnitsInStock>50 AND UnitPrice>50 
						AND ProductID=P.ProductID)
ORDER BY UnitPrice 

--9

SELECT ProductName, CategoryName,CompanyName
FROM Products
JOIN Categories ON Categories.CategoryID=Products.ProductID
JOIN Suppliers ON Suppliers.SupplierID=Products.SupplierID
