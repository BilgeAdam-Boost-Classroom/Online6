USE NORTHWND;

-- SORU 1)
SELECT DISTINCT ProductID, UnitPrice FROM [Order Details]
WHERE UnitPrice > (SELECT AVG(UnitPrice) FROM [Order Details])
ORDER BY UnitPrice DESC

-- ALTERNAT�F
SELECT ProductID, UnitPrice FROM [Order Details]
GROUP BY ProductID, UnitPrice
HAVING UnitPrice > (SELECT AVG(UnitPrice) FROM [Order Details])
ORDER BY UnitPrice DESC

-- SORU 2)
SELECT TerritoryDescription, RegionDescription FROM Region r
JOIN Territories t ON r.RegionID = t.RegionID

-- SORU 3)
SELECT PostalCode FROM Customers WHERE LEN(PostalCode) > 5

-- SORU 4)
SELECT EmployeeID, FirstName, LastName FROM Employees WHERE EmployeeID = (SELECT CategoryID FROM Categories WHERE CategoryName = 'Seafood')

-- SORU 5)
SELECT ProductName, CategoryName FROM Products p 
JOIN Categories ct ON p.CategoryID = ct.CategoryID
ORDER BY CategoryName DESC

-- SORU 6)
SELECT 
	ProductName, 
	(SELECT CategoryName FROM Categories ct WHERE ct.CategoryID = p.CategoryID) [Kategori]
FROM Products p
WHERE p.CategoryID IS NOT NULL
ORDER BY [Kategori] DESC

-- SORU 7)
SELECT ProductName, UnitsInStock, UnitPrice FROM Products
WHERE UnitsInStock > 50 AND UnitPrice > 50
ORDER BY UnitsInStock 

-- SORU 8)
SELECT ProductName, UnitsInStock, UnitPrice
FROM Products
WHERE (UnitPrice) IN (SELECT UnitPrice FROM Products WHERE UnitsInStock > 50 AND UnitPrice > 50)
AND
UnitsInStock IN (SELECT UnitsInStock FROM Products WHERE UnitsInStock > 50 AND UnitPrice > 50)
ORDER BY UnitsInStock;

-- SORU 9)
SELECT p.ProductName, ct.CategoryName, sp.CompanyName FROM Products p
JOIN Categories ct ON p.CategoryID = ct.CategoryID
JOIN Suppliers sp ON p.SupplierID = sp.SupplierID

-- ALTERNAT�F
SELECT
	ProductName,
	(SELECT CategoryName FROM Categories ct WHERE p.CategoryID = ct.CategoryID),
	(SELECT CompanyName FROM Suppliers sp WHERE sp.SupplierID = p.SupplierID)
FROM Products p
WHERE CategoryID IS NOT NULL

