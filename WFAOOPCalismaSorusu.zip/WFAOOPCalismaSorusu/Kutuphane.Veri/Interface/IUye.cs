﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Veri.Interface
{
    public interface IUye
    {
        public string ID { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public DateTime KayitTarihi { get; set; }
        public List<IKitap> AldigiKitaplar { get; set; }
        public string UyeIDUret();
    }
}
