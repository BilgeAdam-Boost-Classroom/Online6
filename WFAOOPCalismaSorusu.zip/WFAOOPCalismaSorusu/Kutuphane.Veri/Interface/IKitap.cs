﻿using Kutuphane.Veri.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Veri.Interface
{
    public interface IKitap
    {
        public int ID { get; set; }
        public string Baslik { get; set; }
        public string Yazar { get; set; }
        public string YayinEvi { get; set; }
        public string YayinTarihi { get; set; }
        public KitapDurum? KitapDurum { get; set; } 
        public int KitapIDUret();
    }
}

      
