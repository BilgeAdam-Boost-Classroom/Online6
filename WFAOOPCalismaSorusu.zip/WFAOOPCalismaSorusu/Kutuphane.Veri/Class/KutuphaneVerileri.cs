﻿using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Kutuphane.Veri.Class
{
    public class KutuphaneVerileri : IKutuphane
    {
        public List<Kitap> Kitaplar { get; set; } = new();
        public List<Uye> Uyeler { get; set; } = new();
        public void VerileriYukle()
        {
            if (File.Exists("kitaplar.json"))
            {
                string kitaplarData = File.ReadAllText("kitaplar.json");
                Kitaplar = JsonSerializer.Deserialize<List<Kitap>>(kitaplarData);
            }
            else
            {
                Kitaplar = new List<Kitap>();
            }

            if (File.Exists("uyeler.json"))
            {
                string uyelerData = File.ReadAllText("uyeler.json");
                Uyeler = JsonSerializer.Deserialize<List<Uye>>(uyelerData);
            }
            else
            {
                Uyeler = new List<Uye>();
            }
        }
        public void VerileriKaydet()
        {
            var options = new JsonSerializerOptions()
            {

                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                WriteIndented = true
            };
            string uyelerData = JsonSerializer.Serialize(Uyeler, options);
            File.WriteAllText("uyeler.json", uyelerData);

            string kitaplarData = JsonSerializer.Serialize(Kitaplar, options);
            File.WriteAllText("kitaplar.json", kitaplarData);
        }
    }
}

