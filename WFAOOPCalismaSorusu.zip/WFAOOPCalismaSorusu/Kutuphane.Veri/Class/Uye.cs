﻿using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Veri.Class
{
    public class Uye : IUye
    {
        public Uye()
        {
           
        }
        private static int sayac = 0;
        private KutuphaneVerileri _kutuphane;
        public Uye(KutuphaneVerileri kutuphane)
        {
            _kutuphane = kutuphane;

        }
        public string ID { get; set; } = null!;
        public string Ad { get; set; } = null!;
        public string Soyad { get; set; } = null!;
        public DateTime KayitTarihi { get; set; } = DateTime.Now;   
        public List<IKitap> AldigiKitaplar { get; set; } = new();

        public string UyeIDUret()
        {
            int gun = KayitTarihi.Day;
            int ay = KayitTarihi.Month;
            int yil = KayitTarihi.Year;
            if (_kutuphane != null && _kutuphane.Uyeler.Count <= 0)
            {
                sayac = 0;
            }
            sayac++;
            ID = gun.ToString() + ay.ToString() + yil.ToString() + sayac.ToString();
            return ID;
        }
    }
}
