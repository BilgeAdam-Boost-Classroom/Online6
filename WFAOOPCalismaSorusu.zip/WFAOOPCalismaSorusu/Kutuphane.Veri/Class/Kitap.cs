﻿using Kutuphane.Veri.Enum;
using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane.Veri.Class
{
    public class Kitap : IKitap
    {
        public Kitap()
        {
            ID = KitapIDUret();
        }
        public int ID { get; set; }
        public string Baslik { get; set; } = null!;
        public KitapDurum? KitapDurum { get; set; } = null;
        public string Yazar { get ; set ; }
        public string YayinEvi { get; set; }
        public string YayinTarihi { get; set; }

        private static int sayac = -1;
        public int KitapIDUret()
        {
            ++sayac;
            return sayac;
        }
    }
}



