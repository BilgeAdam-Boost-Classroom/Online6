﻿using Kutuphane.Veri.Class;
using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFAOOPCalismaSorusu
{
    public partial class UyeEkle : Form
    {
        private KutuphaneVerileri _veriler;
        private Uye _uye;

        public UyeEkle(KutuphaneVerileri veriler, Uye uye)
        {
            _veriler = veriler;
            _uye = uye;
            InitializeComponent();
            _veriler.VerileriYukle();
            ListeGuncelle();
            txtUyeID.Enabled = false;
        }

        private void btnUyeEkle_Click(object sender, EventArgs e)
        {
            Uye uye = new Uye();
            uye.Ad = txtUyeAd.Text.Trim().ToUpper();
            uye.Soyad = txtUyeSoyad.Text.Trim().ToUpper();
            uye.KayitTarihi = dtpKayitTarihi.Value;
            uye.ID = uye.UyeIDUret();
            txtUyeID.Text = uye.ID.Trim().ToUpper();
            bool AyniIdVarMi = _veriler.Uyeler.Any(x => x.ID == uye.ID);
            if (AyniIdVarMi)
            {
                MessageBox.Show("Bu ID'ye sahip bir üye zaten mevcut.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                _veriler.Uyeler.Add(uye);
                _veriler.VerileriKaydet();
                ListeGuncelle();
            }
        }
        private void btnUyeGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvUyelerListesi.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvUyelerListesi.SelectedRows[0];
                Uye secilenUye = (Uye)selectedRow.DataBoundItem;
                _uye = secilenUye;  
                int indeks = _veriler.Uyeler.IndexOf(secilenUye);

                
                UyeGuncelle uyeGuncelleForm = new UyeGuncelle(_uye, _veriler);
                uyeGuncelleForm.ShowDialog();

                if(uyeGuncelleForm.DialogResult == DialogResult.OK)
                {
                    _veriler.Uyeler.RemoveAt(indeks);
                    _veriler.Uyeler.Insert(indeks,_uye);
                }
                ListeGuncelle();
            }
            else
            {
                MessageBox.Show("Lütfen güncellemek istediğiniz bir üye seçin.");
            }
        }
        private void dgvUyelerListesi_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvUyelerListesi.Rows.Count)
            {
                DataGridViewRow selectedRow = dgvUyelerListesi.SelectedRows[e.RowIndex];
                Uye secilenUye = (Uye)selectedRow.DataBoundItem;
                _uye = secilenUye;
                UyeGuncelle uyeGuncelleForm = new UyeGuncelle(_uye, _veriler);
                uyeGuncelleForm.ShowDialog();
                ListeGuncelle();
            }
            else
            {
                MessageBox.Show("Lütfen güncellemek istediğiniz bir üye seçin.");
            }
        }
                
        private void ListeGuncelle()
        {
            dgvUyelerListesi.DataSource = null;
            _veriler.Uyeler = _veriler.Uyeler.OrderBy(x => x.ID).ToList();
            dgvUyelerListesi.DataSource = _veriler.Uyeler;
        }
    }
}

                
            






