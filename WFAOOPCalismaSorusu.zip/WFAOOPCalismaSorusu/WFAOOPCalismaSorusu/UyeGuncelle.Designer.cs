﻿namespace WFAOOPCalismaSorusu
{
    partial class UyeGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            dtpKayitTarihi = new DateTimePicker();
            txtUyeID = new TextBox();
            btnKaydet = new Button();
            label4 = new Label();
            txtUyeSoyad = new TextBox();
            txtUyeAd = new TextBox();
            label2 = new Label();
            label1 = new Label();
            btnSil = new Button();
            SuspendLayout();
            // 
            // label3
            // 
            label3.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(45, 178);
            label3.Name = "label3";
            label3.Size = new Size(146, 33);
            label3.TabIndex = 21;
            label3.Text = "Üye Kayıt Tarihi :";
            // 
            // dtpKayitTarihi
            // 
            dtpKayitTarihi.Location = new Point(197, 178);
            dtpKayitTarihi.MaxDate = new DateTime(2024, 3, 31, 0, 0, 0, 0);
            dtpKayitTarihi.MinDate = new DateTime(1990, 1, 1, 0, 0, 0, 0);
            dtpKayitTarihi.Name = "dtpKayitTarihi";
            dtpKayitTarihi.Size = new Size(279, 31);
            dtpKayitTarihi.TabIndex = 20;
            dtpKayitTarihi.Value = new DateTime(2023, 10, 31, 0, 0, 0, 0);
            // 
            // txtUyeID
            // 
            txtUyeID.Location = new Point(197, 227);
            txtUyeID.Name = "txtUyeID";
            txtUyeID.Size = new Size(279, 31);
            txtUyeID.TabIndex = 19;
            // 
            // btnKaydet
            // 
            btnKaydet.BackColor = Color.LightGray;
            btnKaydet.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnKaydet.Location = new Point(45, 286);
            btnKaydet.Name = "btnKaydet";
            btnKaydet.Size = new Size(431, 46);
            btnKaydet.TabIndex = 18;
            btnKaydet.Text = "Kaydet";
            btnKaydet.UseVisualStyleBackColor = false;
            btnKaydet.Click += btnKaydet_Click;
            // 
            // label4
            // 
            label4.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(45, 225);
            label4.Name = "label4";
            label4.Size = new Size(146, 33);
            label4.TabIndex = 17;
            label4.Text = "Üye ID:";
            // 
            // txtUyeSoyad
            // 
            txtUyeSoyad.Location = new Point(197, 130);
            txtUyeSoyad.Name = "txtUyeSoyad";
            txtUyeSoyad.Size = new Size(279, 31);
            txtUyeSoyad.TabIndex = 16;
            // 
            // txtUyeAd
            // 
            txtUyeAd.Location = new Point(197, 82);
            txtUyeAd.Name = "txtUyeAd";
            txtUyeAd.Size = new Size(279, 31);
            txtUyeAd.TabIndex = 15;
            // 
            // label2
            // 
            label2.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(45, 133);
            label2.Name = "label2";
            label2.Size = new Size(146, 33);
            label2.TabIndex = 14;
            label2.Text = "Üye Soyad :";
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(45, 82);
            label1.Name = "label1";
            label1.Size = new Size(105, 33);
            label1.TabIndex = 13;
            label1.Text = "Üye Ad :";
            // 
            // btnSil
            // 
            btnSil.BackColor = Color.LightGray;
            btnSil.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnSil.Location = new Point(45, 338);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(431, 46);
            btnSil.TabIndex = 22;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = false;
            btnSil.Click += btnSil_Click;
            // 
            // UyeGuncelle
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(569, 450);
            Controls.Add(btnSil);
            Controls.Add(label3);
            Controls.Add(dtpKayitTarihi);
            Controls.Add(txtUyeID);
            Controls.Add(btnKaydet);
            Controls.Add(label4);
            Controls.Add(txtUyeSoyad);
            Controls.Add(txtUyeAd);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UyeGuncelle";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Üye Güncelleme Formu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private DateTimePicker dtpKayitTarihi;
        private TextBox txtUyeID;
        private Button btnKaydet;
        private Label label4;
        private TextBox txtUyeSoyad;
        private TextBox txtUyeAd;
        private Label label2;
        private Label label1;
        private Button btnSil;
    }
}