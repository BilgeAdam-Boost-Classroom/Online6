﻿using Kutuphane.Veri.Class;
using Kutuphane.Veri.Enum;
using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFAOOPCalismaSorusu
{
    public partial class KitapGuncelle : Form
    {
        private KutuphaneVerileri _veriler;
        private Kitap _kitap;
        public KitapGuncelle(KutuphaneVerileri veriler, Kitap kitap)
        {
            InitializeComponent();
            cobKitapDurum.DataSource = Enum.GetValues(typeof(KitapDurum));
            _veriler = veriler;
            _kitap = kitap;
            VerileriYukle();
        }
        public void VerileriYukle()
        {
            txtKitapAd.Text = _kitap.Baslik;
            txtKitapID.Text = Convert.ToString(_kitap.ID);
            txtYayinEvi.Text = _kitap.YayinEvi;
            txtYayinYili.Text = _kitap.YayinTarihi;
            txtYazar.Text = _kitap.Yazar;
            cobKitapDurum.SelectedItem = _kitap.KitapDurum;
            ;
            _veriler.Kitaplar.Remove(_kitap);
        }
        public void VerileriGuncelle()
        {
            _kitap.Baslik = txtKitapAd.Text;
            txtKitapID.Text = Convert.ToString(_kitap.ID);
            _kitap.YayinEvi = txtYayinEvi.Text;
            _kitap.YayinTarihi = txtYayinYili.Text;
            _kitap.Yazar = txtYazar.Text;
            _kitap.KitapDurum = (KitapDurum?)cobKitapDurum.SelectedItem;

            _veriler.Kitaplar.Add(_kitap);
        }
        private void btnKitapKaydet_Click(object sender, EventArgs e)
        {
            VerileriGuncelle();
            _veriler.VerileriKaydet();
            MessageBox.Show("Kitap bilgileri güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnKitapSil_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Silmek istediğiniz emin misiniz ?", "Emin Misiniz?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                _veriler.Kitaplar.Remove(_kitap);
                _veriler.VerileriKaydet();
                MessageBox.Show("Kitap başarıyla kaldırıldı.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.Close();
        }
    }

}










