﻿namespace WFAOOPCalismaSorusu
{
    partial class KitapGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cobKitapDurum = new ComboBox();
            label8 = new Label();
            txtYayinEvi = new TextBox();
            label7 = new Label();
            label6 = new Label();
            txtYazar = new TextBox();
            txtYayinYili = new TextBox();
            label3 = new Label();
            txtKitapID = new TextBox();
            btnKitapSil = new Button();
            label5 = new Label();
            btnKitapKaydet = new Button();
            label4 = new Label();
            txtKitapAd = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // cobKitapDurum
            // 
            cobKitapDurum.FormattingEnabled = true;
            cobKitapDurum.Location = new Point(56, 548);
            cobKitapDurum.Name = "cobKitapDurum";
            cobKitapDurum.Size = new Size(303, 33);
            cobKitapDurum.TabIndex = 44;
            // 
            // label8
            // 
            label8.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(56, 512);
            label8.Name = "label8";
            label8.Size = new Size(145, 33);
            label8.TabIndex = 43;
            label8.Text = "Kitap Durumu";
            // 
            // txtYayinEvi
            // 
            txtYayinEvi.Location = new Point(56, 460);
            txtYayinEvi.Name = "txtYayinEvi";
            txtYayinEvi.Size = new Size(303, 31);
            txtYayinEvi.TabIndex = 42;
            // 
            // label7
            // 
            label7.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(56, 424);
            label7.Name = "label7";
            label7.Size = new Size(195, 33);
            label7.TabIndex = 41;
            label7.Text = "Kitap Yayın Evi";
            // 
            // label6
            // 
            label6.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(54, 333);
            label6.Name = "label6";
            label6.Size = new Size(164, 33);
            label6.TabIndex = 40;
            label6.Text = "Kitap Yayın Yılı";
            // 
            // txtYazar
            // 
            txtYazar.Location = new Point(56, 277);
            txtYazar.Name = "txtYazar";
            txtYazar.Size = new Size(303, 31);
            txtYazar.TabIndex = 39;
            // 
            // txtYayinYili
            // 
            txtYayinYili.Location = new Point(56, 369);
            txtYayinYili.Name = "txtYayinYili";
            txtYayinYili.Size = new Size(303, 31);
            txtYayinYili.TabIndex = 38;
            // 
            // label3
            // 
            label3.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(56, 241);
            label3.Name = "label3";
            label3.Size = new Size(145, 33);
            label3.TabIndex = 37;
            label3.Text = "Kitap Yazar ";
            // 
            // txtKitapID
            // 
            txtKitapID.Location = new Point(56, 81);
            txtKitapID.Name = "txtKitapID";
            txtKitapID.Size = new Size(263, 31);
            txtKitapID.TabIndex = 36;
            // 
            // btnKitapSil
            // 
            btnKitapSil.BackColor = Color.LightGray;
            btnKitapSil.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnKitapSil.Location = new Point(226, 618);
            btnKitapSil.Name = "btnKitapSil";
            btnKitapSil.Size = new Size(133, 46);
            btnKitapSil.TabIndex = 35;
            btnKitapSil.Text = "Sil";
            btnKitapSil.UseVisualStyleBackColor = false;
            btnKitapSil.Click += btnKitapSil_Click;
            // 
            // label5
            // 
            label5.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.DimGray;
            label5.Location = new Point(54, 124);
            label5.Name = "label5";
            label5.Size = new Size(431, 33);
            label5.TabIndex = 34;
            label5.Text = "Bilgi : Kitap ID biligisi sistem tarafından atanmaktadır.\r\n";
            // 
            // btnKitapKaydet
            // 
            btnKitapKaydet.BackColor = Color.LightGray;
            btnKitapKaydet.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnKitapKaydet.Location = new Point(54, 618);
            btnKitapKaydet.Name = "btnKitapKaydet";
            btnKitapKaydet.Size = new Size(156, 46);
            btnKitapKaydet.TabIndex = 33;
            btnKitapKaydet.Text = "Kaydet";
            btnKitapKaydet.UseVisualStyleBackColor = false;
            btnKitapKaydet.Click += btnKitapKaydet_Click;
            // 
            // label4
            // 
            label4.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(54, 45);
            label4.Name = "label4";
            label4.Size = new Size(146, 33);
            label4.TabIndex = 32;
            label4.Text = "Kitap ID:";
            // 
            // txtKitapAd
            // 
            txtKitapAd.Location = new Point(56, 193);
            txtKitapAd.Name = "txtKitapAd";
            txtKitapAd.Size = new Size(303, 31);
            txtKitapAd.TabIndex = 31;
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(56, 157);
            label1.Name = "label1";
            label1.Size = new Size(105, 33);
            label1.TabIndex = 30;
            label1.Text = "Kitap Ad :";
            // 
            // KitapGuncelle
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(502, 742);
            Controls.Add(cobKitapDurum);
            Controls.Add(label8);
            Controls.Add(txtYayinEvi);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(txtYazar);
            Controls.Add(txtYayinYili);
            Controls.Add(label3);
            Controls.Add(txtKitapID);
            Controls.Add(btnKitapSil);
            Controls.Add(label5);
            Controls.Add(btnKitapKaydet);
            Controls.Add(label4);
            Controls.Add(txtKitapAd);
            Controls.Add(label1);
            Name = "KitapGuncelle";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Kitap Güncelleme Formu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cobKitapDurum;
        private Label label8;
        private TextBox txtYayinEvi;
        private Label label7;
        private Label label6;
        private TextBox txtYazar;
        private TextBox txtYayinYili;
        private Label label3;
        private TextBox txtKitapID;
        private Button btnKitapSil;
        private Label label5;
        private Button btnKitapKaydet;
        private Label label4;
        private TextBox txtKitapAd;
        private Label label1;
    }
}