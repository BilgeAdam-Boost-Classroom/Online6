﻿using Kutuphane.Veri.Class;
using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFAOOPCalismaSorusu
{
    public partial class UyeGuncelle : Form
    {
        private Uye _uye;
        private KutuphaneVerileri _veriler;

        public UyeGuncelle(Uye uye, KutuphaneVerileri veriler)
        {
            _uye = uye;
            _veriler = veriler;
            InitializeComponent();
            txtUyeID.Enabled = false;
            VerileriYukle();
        }
        private void btnKaydet_Click(object sender, EventArgs e)
        {
            VerileriGuncelle();
            _veriler.VerileriKaydet();
            MessageBox.Show("Üye bilgileri güncellendi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnSil_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Silmek istediğiniz emin misiniz ?", "Emin Misiniz?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                _veriler.Uyeler.Remove(_uye);
                _veriler.VerileriKaydet();
                MessageBox.Show("Üye  başarıyla kaldırıldı.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            this.Close();
        }
        public void VerileriYukle()
        {
            txtUyeAd.Text = _uye.Ad;
            txtUyeSoyad.Text = _uye.Soyad;
            dtpKayitTarihi.Value = _uye.KayitTarihi;
            txtUyeID.Text = _uye.ID;
            _veriler.Uyeler.Remove(_uye);
        }
        public void VerileriGuncelle()
        {
            _uye.Ad = txtUyeAd.Text.Trim().ToUpper();
            _uye.Soyad = txtUyeSoyad.Text.Trim().ToUpper();
            _uye.KayitTarihi = dtpKayitTarihi.Value;
            _uye.ID = _uye.UyeIDUret();
             txtUyeID.Text = _uye.ID.Trim().ToUpper();
            _veriler.Uyeler.Add(_uye);
        }
        public void VeriGirisiKontrolu()
        {
            if (string.IsNullOrEmpty(txtUyeAd.Text))
                MessageBox.Show("Lütfen geçerli bir ad girin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txtUyeSoyad.Text))
                MessageBox.Show("Lütfen geçerli bir soyad girin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}






