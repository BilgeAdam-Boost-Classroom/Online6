﻿namespace WFAOOPCalismaSorusu
{
    partial class UyeEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtUyeAd = new TextBox();
            txtUyeSoyad = new TextBox();
            label4 = new Label();
            btnUyeEkle = new Button();
            label5 = new Label();
            btnUyeGuncelle = new Button();
            txtUyeID = new TextBox();
            dtpKayitTarihi = new DateTimePicker();
            label3 = new Label();
            label6 = new Label();
            dgvUyelerListesi = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvUyelerListesi).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(41, 147);
            label1.Name = "label1";
            label1.Size = new Size(105, 33);
            label1.TabIndex = 0;
            label1.Text = "Üye Ad :";
            // 
            // label2
            // 
            label2.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(41, 198);
            label2.Name = "label2";
            label2.Size = new Size(146, 33);
            label2.TabIndex = 1;
            label2.Text = "Üye Soyad :";
            // 
            // txtUyeAd
            // 
            txtUyeAd.Location = new Point(193, 147);
            txtUyeAd.Name = "txtUyeAd";
            txtUyeAd.Size = new Size(279, 31);
            txtUyeAd.TabIndex = 3;
            // 
            // txtUyeSoyad
            // 
            txtUyeSoyad.Location = new Point(193, 195);
            txtUyeSoyad.Name = "txtUyeSoyad";
            txtUyeSoyad.Size = new Size(279, 31);
            txtUyeSoyad.TabIndex = 4;
            // 
            // label4
            // 
            label4.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(41, 290);
            label4.Name = "label4";
            label4.Size = new Size(146, 33);
            label4.TabIndex = 5;
            label4.Text = "Üye ID:";
            // 
            // btnUyeEkle
            // 
            btnUyeEkle.BackColor = Color.LightGray;
            btnUyeEkle.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnUyeEkle.Location = new Point(41, 351);
            btnUyeEkle.Name = "btnUyeEkle";
            btnUyeEkle.Size = new Size(431, 46);
            btnUyeEkle.TabIndex = 7;
            btnUyeEkle.Text = "Ekle";
            btnUyeEkle.UseVisualStyleBackColor = false;
            btnUyeEkle.Click += btnUyeEkle_Click;
            // 
            // label5
            // 
            label5.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.DimGray;
            label5.Location = new Point(41, 467);
            label5.Name = "label5";
            label5.Size = new Size(431, 33);
            label5.TabIndex = 8;
            label5.Text = "Bilgi : Üye ID biligisi sistem tarafından atanmaktadır.\r\n";
            // 
            // btnUyeGuncelle
            // 
            btnUyeGuncelle.BackColor = Color.LightGray;
            btnUyeGuncelle.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnUyeGuncelle.Location = new Point(41, 403);
            btnUyeGuncelle.Name = "btnUyeGuncelle";
            btnUyeGuncelle.Size = new Size(431, 46);
            btnUyeGuncelle.TabIndex = 9;
            btnUyeGuncelle.Text = " Güncelle";
            btnUyeGuncelle.UseVisualStyleBackColor = false;
            btnUyeGuncelle.Click += btnUyeGuncelle_Click;
            // 
            // txtUyeID
            // 
            txtUyeID.Location = new Point(193, 292);
            txtUyeID.Name = "txtUyeID";
            txtUyeID.Size = new Size(279, 31);
            txtUyeID.TabIndex = 10;
            // 
            // dtpKayitTarihi
            // 
            dtpKayitTarihi.Location = new Point(193, 243);
            dtpKayitTarihi.MaxDate = new DateTime(2023, 10, 29, 0, 0, 0, 0);
            dtpKayitTarihi.Name = "dtpKayitTarihi";
            dtpKayitTarihi.Size = new Size(279, 31);
            dtpKayitTarihi.TabIndex = 11;
            dtpKayitTarihi.Value = new DateTime(2023, 10, 29, 0, 0, 0, 0);
            // 
            // label3
            // 
            label3.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(41, 243);
            label3.Name = "label3";
            label3.Size = new Size(146, 33);
            label3.TabIndex = 12;
            label3.Text = "Üye Kayıt Tarihi :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(494, 41);
            label6.Name = "label6";
            label6.Size = new Size(260, 25);
            label6.TabIndex = 14;
            label6.Text = "KÜTÜPHANE ÜYELER LİSTESİ";
            // 
            // dgvUyelerListesi
            // 
            dgvUyelerListesi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvUyelerListesi.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvUyelerListesi.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUyelerListesi.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dgvUyelerListesi.Location = new Point(494, 79);
            dgvUyelerListesi.MultiSelect = false;
            dgvUyelerListesi.Name = "dgvUyelerListesi";
            dgvUyelerListesi.RowHeadersVisible = false;
            dgvUyelerListesi.RowHeadersWidth = 62;
            dgvUyelerListesi.RowTemplate.Height = 33;
            dgvUyelerListesi.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvUyelerListesi.Size = new Size(638, 475);
            dgvUyelerListesi.TabIndex = 13;
            dgvUyelerListesi.CellDoubleClick += dgvUyelerListesi_CellDoubleClick;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "ID";
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 8;
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Ad";
            Column2.HeaderText = "AD";
            Column2.MinimumWidth = 8;
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Soyad";
            Column3.HeaderText = "SOYAD";
            Column3.MinimumWidth = 8;
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.DataPropertyName = "KayitTarihi";
            Column4.HeaderText = "KAYIT TARİHİ";
            Column4.MinimumWidth = 8;
            Column4.Name = "Column4";
            // 
            // UyeEkle
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1170, 584);
            Controls.Add(label6);
            Controls.Add(dgvUyelerListesi);
            Controls.Add(label3);
            Controls.Add(dtpKayitTarihi);
            Controls.Add(txtUyeID);
            Controls.Add(btnUyeGuncelle);
            Controls.Add(label5);
            Controls.Add(btnUyeEkle);
            Controls.Add(label4);
            Controls.Add(txtUyeSoyad);
            Controls.Add(txtUyeAd);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UyeEkle";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Üye Ekleme Formu";
            ((System.ComponentModel.ISupportInitialize)dgvUyelerListesi).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtUyeAd;
        private TextBox txtUyeSoyad;
        private Label label4;
        private Button btnUyeEkle;
        private Label label5;
        private Button btnUyeGuncelle;
        private TextBox txtUyeID;
        private DateTimePicker dtpKayitTarihi;
        private Label label3;
        private Label label6;
        private DataGridView dgvUyelerListesi;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
    }
}