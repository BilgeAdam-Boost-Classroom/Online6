﻿using Kutuphane.Veri.Class;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFAOOPCalismaSorusu
{
    public partial class AnaForm : Form
    {

        private KutuphaneVerileri veriler;
        private Kitap kitap;
        private Uye uye;
        public AnaForm()
        {
            InitializeComponent();
            veriler = new KutuphaneVerileri();
            kitap = new Kitap();
            uye = new Uye();
        }

        private void FormGoster(Form secilenForm)
        {
            bool durum = false;
            foreach (Form form in this.MdiChildren)
            {
                if (form.Text == secilenForm.Text)
                {
                    form.Show();
                }
                else
                {
                    form.Close();
                }
            }
            if (!durum)
            {
                secilenForm.MdiParent = this;
                durum = true;
            }
        }

        private void kitapEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGoster(new KitapEkle(veriler,kitap));
        }
        private void uyeEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGoster(new UyeEkle(veriler,uye));
        }

    }
}



