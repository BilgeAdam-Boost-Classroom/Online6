﻿using Kutuphane.Veri.Class;
using Kutuphane.Veri.Enum;
using Kutuphane.Veri.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.Json;

namespace WFAOOPCalismaSorusu
{
    public partial class KitapEkle : Form
    {
        private KutuphaneVerileri _veriler;
        private Kitap _kitap;

        public KitapEkle(KutuphaneVerileri veriler, Kitap kitap)
        {
            _veriler = veriler;
            _kitap = kitap;
            InitializeComponent();
            cobKitapDurum.DataSource = Enum.GetValues(typeof(KitapDurum));
            _veriler.VerileriYukle();
            ListeGuncelle();
            txtKitapID.Enabled = false;
        }
               private void btnKitapEkle_Click(object sender, EventArgs e)
        {
            Kitap kitap = new Kitap();
            txtKitapID.Text = kitap.ID.ToString();
            kitap.Baslik = txtKitapAd.Text.Trim().ToUpper();
            kitap.Yazar = txtYazar.Text.Trim().ToUpper();
            kitap.YayinEvi = txtYayinEvi.Text.Trim().ToUpper();
            kitap.YayinTarihi = txtYayinYili.Text.Trim().ToUpper();
            kitap.KitapDurum = (KitapDurum?)cobKitapDurum.SelectedItem;
            bool AyniIdVarMi = _veriler.Kitaplar.Any(x => x.ID == kitap.ID);
            if (AyniIdVarMi)
            {
                MessageBox.Show("Bu ID'ye sahip bir kitap zaten mevcut.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                _veriler.Kitaplar.Add(kitap);
                _veriler.VerileriKaydet();
                ListeGuncelle();

            }

        }
        private void btnKitapGuncelle_Click(object sender, EventArgs e)
        {

            if (dgvKitaplarListesi.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvKitaplarListesi.SelectedRows[0];
                Kitap secilenKitap = (Kitap)selectedRow.DataBoundItem;
                _kitap = secilenKitap;
                KitapGuncelle uyeGuncelleForm = new KitapGuncelle(_veriler, _kitap);
                uyeGuncelleForm.ShowDialog();

                ListeGuncelle();
            }
        }
        private void dgvKitaplarListesi_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > 0)
            {
                DataGridViewRow selectedRow = dgvKitaplarListesi.Rows[e.RowIndex];
                Kitap secilenKitap = (Kitap)selectedRow.DataBoundItem;
                _kitap = secilenKitap;
                KitapGuncelle uyeGuncelleForm = new KitapGuncelle(_veriler, _kitap);
                uyeGuncelleForm.ShowDialog();

                ListeGuncelle();
            }
        }
        private void ListeGuncelle()
        {
            dgvKitaplarListesi.DataSource = null;
            dgvKitaplarListesi.DataSource = _veriler.Kitaplar;
        }

    }
}





