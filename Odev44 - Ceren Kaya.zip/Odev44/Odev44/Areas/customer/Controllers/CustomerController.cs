﻿using Microsoft.AspNetCore.Mvc;
using Odev44.Data;

namespace Odev44.Areas.customer.Controllers
{
    [Area("customer")]
    public class CustomerController : Controller
    {
        

        private readonly ApplicationDbContext _context;
        public CustomerController(ApplicationDbContext db)
        {
            _context = db;
        }
        public IActionResult Index()
        {
           var items = _context.Arabalar.ToList();
            return View(items);
        }
    }
}
