﻿using System.ComponentModel.DataAnnotations;

namespace Odev44.Data
{
    public class Araba
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Marka zorunludur.")]
        public string Marka { get; set; }
        [Required(ErrorMessage = "Model zorunludur.")]
        public string Model { get; set; }
        [Required(ErrorMessage = "Bu bilgi zorunludur.")]
        public bool ikinciElMi { get; set; }
        [Required(ErrorMessage = "Renk zorunludur.")]
        public string Renk { get; set; }
    }
}
