﻿using Microsoft.EntityFrameworkCore;
using Odev44.Models;

namespace Odev44.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(

                 new Araba()
                 {
                     Id = 1,
                     Marka = "Mercedes",
                     Model = "GLA 200",
                     ikinciElMi = true,
                     Renk = "kırmızı"




                 },
                 new Araba()
                 {
                     Id = 2,
                     Marka = "Honda",
                     Model = "civic",
                     ikinciElMi = false,
                     Renk = "beyaz"



                 },
                 new Araba()
                 {
                     Id = 3,
                     Marka = "Bmw",
                     Model = "M3",
                     ikinciElMi = true,
                     Renk ="siyah"



                 },
                 new Araba()
                 {
                     Id = 4,
                     Marka = "Skoda",
                     Model = "Super B",
                     ikinciElMi= false,
                     Renk="turuncu"

                 }
                );
        }
}

}