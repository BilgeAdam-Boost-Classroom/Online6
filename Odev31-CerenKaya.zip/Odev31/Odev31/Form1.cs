using Odev31.Models;

namespace Odev31
{
    public partial class Form1 : Form
    {
        NorthwndContext db;
        public Form1()
        {
            InitializeComponent();
            db = new NorthwndContext();

            foreach (var item in db.Regions) { comboBox1.Items.Add(item.RegionDescription.Trim()); }

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            Territory territory = new Territory();
            territory.TerritoryId = txtId.Text;
            territory.TerritoryDescription = txtTerritoryDescription.Text;
            if (comboBox1.SelectedItem != null)
            {
                territory.RegionId = comboBox1.SelectedIndex + 1;
            }
            db.Territories.Add(territory);
            db.SaveChanges();
            MessageBox.Show("eklendi");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string silinecekId = txtId.Text;
            var silinecekterritory = db.Territories.FirstOrDefault(x => x.TerritoryId == silinecekId);
            if (silinecekterritory != null)
            {
                db.Territories.Remove(silinecekterritory);
                db.SaveChanges();
            }
            else MessageBox.Show("Id bulunamad�");

        }


        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            string guncellenecekId = txtId.Text;
            var guncellenecekterritory= db.Territories.FirstOrDefault(x => x.TerritoryId==guncellenecekId);  

            if(guncellenecekterritory!= null)
            {

                if (comboBox1.SelectedItem != null)
                {
                guncellenecekterritory.TerritoryDescription= txtTerritoryDescription.Text;
                guncellenecekterritory.RegionId = comboBox1.SelectedIndex + 1;
                db.SaveChanges();
                MessageBox.Show("g�ncellendi");
                 }
                else MessageBox.Show("region Id se�mediniz");

            }           
            else
                MessageBox.Show("G�ncellenecek id bulunamad�.");
            

        }
    }
}
