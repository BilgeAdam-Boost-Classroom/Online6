﻿USE NORTHWND;

-- Odev29;
-- 1)AyHesapla adında, aldığı DATETIME cinsinden değerin üzerinden kaç ay geçtiğini hesaplayan 
--ve bu değeri geri döndüren bir fonksiyon oluşturunuz. Ardından, Employees tablosundaki her 
--bir çalışan için işe başlama tarihinden bu yana kaç ay geçtiğini, bu fonksiyonu kullanarak 
--listeleyiniz.
GO
ALTER FUNCTION AyHesapla(@BaslamaTarihi DATETIME)
	RETURNS INT
AS
	BEGIN
		RETURN DATEDIFF(MONTH, @BaslamaTarihi, GETDATE());
	END;
GO

SELECT FirstName, LastName, dbo.AyHesapla(HireDate) AS 'Gecen Ay Miktari'
FROM Employees;

--2) İki tarih arasındaki farkı alan ve bu farkı gün olarak döndüren bir fonksiyon yazınız. Daha 
--sonra orders tablosundaki her satır için OrderDate ile ShippedDate arasındaki gün sayısını, bu 
--fonksiyonu kullanarak listeleyiniz.
GO
CREATE FUNCTION GunFarki(@Tarih DATETIME, @Tarih2 DATETIME)
	RETURNS INT
AS
	BEGIN
		RETURN DATEDIFF(DAY, @Tarih, @Tarih2);
	END;
GO

SELECT OrderID, dbo.GunFarki(OrderDate, ShippedDate) AS 'Gün Farki'
FROM Orders;

--3) Employees tablosundan firstname’leri, dışarıdan gönderilen harf ile başlayanları tablo olarak 
--döndüren fonksiyon yazınız. Ardından bu fonksiyonu kullanarak A ile başlayanları listeleyiniz.
GO
CREATE FUNCTION BaslayanIsimler (@Harf CHAR(1))
	RETURNS TABLE
AS
	RETURN 
(
    SELECT FirstName
    FROM Employees
    WHERE FirstName LIKE @Harf + '%'
);
GO

SELECT FirstName FROM dbo.BaslayanIsimler('A');

--4) Order details tablosundaki unitprice’ların kırpılmış ortalamasını hesaplayan stored procedure yazınız. (Kırpılmış ortalama: En küçük ve en büyük değerler dahil edilmeden hesaplanan aritmetik ortalamadır. Bölerken, (terim sayısı-2) ’ye bölünmelidir.
GO
CREATE PROCEDURE CalculateTrimmedAverageUnitPrice
AS
    DECLARE @MinPrice DECIMAL(18, 2);
    DECLARE @MaxPrice DECIMAL(18, 2);
    DECLARE @TerimSayisi INT;
    DECLARE @TotalPrice DECIMAL(18, 2);
    DECLARE @TrimmedAverage DECIMAL(18, 2);

    -- Min ve max değerleri bulma
    SELECT @MinPrice = MIN(UnitPrice), @MaxPrice = MAX(UnitPrice)
    FROM [Order Details];

    -- Toplam terim sayısını ve toplam fiyatı bulma (min ve max değerleri hariç)
    SELECT @TerimSayisi = COUNT(UnitPrice), @TotalPrice = SUM(UnitPrice)
    FROM [Order Details]
    WHERE UnitPrice NOT IN (@MinPrice, @MaxPrice);

    -- Kırpılmış ortalama hesaplama
    SET @TrimmedAverage = (@TotalPrice / NULLIF(@TermCount - 2, 0));

    SELECT @TrimmedAverage AS 'TrimmedAverageUnitPrice';
GO