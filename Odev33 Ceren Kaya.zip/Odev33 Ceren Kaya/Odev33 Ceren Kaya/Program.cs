﻿
using Microsoft.EntityFrameworkCore;
using Odev33_Ceren_Kaya.Nortwnd;
using System.Threading.Channels;
namespace Odev33_Ceren_Kaya
{
    public class Program
    {

        static void Main(string[] args)
        {

            NorthwndContext db = new NorthwndContext();

            //1.)Tüm Employeeleri listeleyiniz.
            Console.WriteLine("Employees" + Environment.NewLine);
            Console.WriteLine("-----------1-----------");
            var employeeNames = db.Employees.Select(employee => employee.FirstName + " " + employee.LastName).ToList();
            employeeNames.ForEach(employee => Console.WriteLine(employee));

            //2.)İlk Employee yi yazdırınız.
            Console.WriteLine("-----------2-----------");
            Console.WriteLine("İlk Eleman: " + employeeNames.FirstOrDefault());



            //3.)Employeeleri , FirstName e göre sıralayıp son employee yi yazdırınız.
            Console.WriteLine("-----------3-----------");
            var lastEmployee = db.Employees.OrderByDescending(employee => employee.FirstName).FirstOrDefault();
            Console.WriteLine(lastEmployee.FirstName + " " + lastEmployee.LastName);

            //Alternatif
            var SiraliEmployees = from employee in db.Employees
                                  orderby employee.FirstName descending
                                  select employee.FirstName + " " + employee.LastName;
            Console.WriteLine(SiraliEmployees.FirstOrDefault());


            //4.)İsmi A ile başlayan employee leri listeleyiniz.
            Console.WriteLine("----------4------------");

            var aIleBaslayanlar = db.Employees
                .Select(calisan => calisan.FirstName + " " + calisan.LastName)
                .Where(tamAd => tamAd.StartsWith("A"))
                .ToList();

            aIleBaslayanlar.ForEach(e => Console.WriteLine(e));



            //Alternatif
            var AileBaslayanlar = from employee in db.Employees
                                  where employee.FirstName.StartsWith("A")
                                  select employee.FirstName + " " + employee.LastName;

            foreach (var item in AileBaslayanlar)
            {
                Console.WriteLine(item + " ");

            }


            //5)İsmi A ile başlayan ilk Employee yi yazdırınız.

            Console.WriteLine("----------5------------");
            var aIleBaslayanIlk = db.Employees.Select(e => e.FirstName + " " + e.LastName).Where(TamAdı => TamAdı.StartsWith("A")).ToList().FirstOrDefault();
            Console.WriteLine(aIleBaslayanIlk);

            //6)İsmi içerisinde a harfi içeren employeeleri listeleyiniz.
            Console.WriteLine("----------6------------");
            var aHarfiGecen = db.Employees
                .Select(e => e.FirstName + " " + e.LastName)
                .Where( e => e.ToLower().Contains("a"))
                .ToList();
            aHarfiGecen.ForEach(e => Console.WriteLine(e));

            //7)İsmi içerisinde a harfi içeren ilk employee yi yazdırınız.
            Console.WriteLine("----------7------------");
            Console.WriteLine(aHarfiGecen.FirstOrDefault());

            //8)Adı Andrew olan employee leri yazdırınız.
            Console.WriteLine("----------8------------");
            var adiAndrew = db.Employees
                .Where(a => a.FirstName == "Andrew")
                .ToList();
            adiAndrew.ForEach(a => Console.WriteLine(a.FirstName+" "+a.LastName));

            //9)En pahalı productı yazdırınız.
            Console.WriteLine("----------9------------");
            var enPahaliUrun = db.Products
                .OrderByDescending(p => p.UnitPrice) //B-K
                .Select(a => a.ProductName)
                .FirstOrDefault();
            Console.WriteLine(enPahaliUrun);

            //10)En ucuz productı yazdırınız.
            Console.WriteLine("----------10------------");
            var enUcuzUrun = db.Products
                .OrderBy(p => p.UnitPrice) //K-B
                .Select(a => a.ProductName)
                .FirstOrDefault();
            Console.WriteLine(enPahaliUrun);

            //11)Fiyatı ortalama fiyat üzerinde olan ürünleri yazdırınız.
            Console.WriteLine("----------11------------");

            var ortalamaFiyatUstu = db.Products
                .Where(p => p.UnitPrice > db.Products.Average(p => p.UnitPrice))
                .Select(p => p.ProductName).ToList();
            ortalamaFiyatUstu.ForEach(f => Console.WriteLine(f));

            //12)Product ları Stock sayısına göre sıralayınız.
            Console.WriteLine("----------12------------");
            var UrunStokSirala = db.Products
                .OrderBy(p => p.UnitsInStock)
                .Select(a => a.ProductName)
                .ToList();
            UrunStokSirala.ForEach( f => Console.WriteLine(f));

            //13)Product ları önce Stock sayısına göre sonra ProductName e göre büyükten küçüğe sıralayın. (iki sıralama da büyükten küçüğe olmalıdır)
            Console.WriteLine("----------13------------");
            var UrunSirala = db.Products
               .OrderByDescending(p => p.UnitsInStock)
               .ThenByDescending(p => p.ProductName)
               .Select(a => a.ProductName)
               .ToList();
            UrunSirala.ForEach(p => Console.WriteLine(p));

            //14)Order detaillarda, order bazında toplam satış tutarı 500 ve altında olan orderid'leri getirip, toplam tutara göre sıralayınız.
            Console.WriteLine("----------14------------");
            var siraliSiparisler = db.OrderDetails
                .GroupBy(od => od.OrderId)
                .Select(a => new
                {
                    OrderId = a.Key, //groupby da kullandığımız için key . grupların anahtarını temsil ediyor.
                    ToplamTutar = a.Sum(od => od.UnitPrice * od.Quantity * (1 - (decimal)od.Discount))
                })
                .Where(result => result.ToplamTutar <= 500)
                .OrderBy(result => result.ToplamTutar)
                .ToList();
            siraliSiparisler.ForEach( s => Console.WriteLine(s));

            //15)Tüm product ları category leri ile birlikte listeleyiniz.
            Console.WriteLine("----------15------------");

            var KategoriUrun = db.Products
                .Include(p => p.Category).Select(p => p.Category.CategoryName + " " + p.ProductName).ToList();

            KategoriUrun.ForEach(p => Console.WriteLine(p));

            //16)ProductName, CategoryName, Suplier'ın CompanyName 'ini ile birlikte yazdırınız. 
            Console.WriteLine("----------16------------");
            var topluYazdir = db.Products.Include(p => p.Category).Include(p => p.Supplier)
                .Select(p => p.ProductName + " , " + p.Category.CategoryName + " , " + p.Supplier.CompanyName).ToList();
            topluYazdir.ForEach(p => Console.WriteLine(p));
        }
    }
}
