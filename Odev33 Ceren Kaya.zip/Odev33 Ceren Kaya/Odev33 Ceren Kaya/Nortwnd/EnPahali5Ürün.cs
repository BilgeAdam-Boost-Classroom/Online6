﻿using System;
using System.Collections.Generic;

namespace Odev33_Ceren_Kaya.Nortwnd;

public partial class EnPahali5Ürün
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public string? ContactName { get; set; }
}
