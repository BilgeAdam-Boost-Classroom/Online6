﻿using System;
using System.Collections.Generic;

namespace Odev33_Ceren_Kaya.Nortwnd;

public partial class QuarterlyOrder
{
    public string? CustomerId { get; set; }

    public string? CompanyName { get; set; }

    public string? City { get; set; }

    public string? Country { get; set; }
}
