﻿using System;
using System.Collections.Generic;

namespace Odev33_Ceren_Kaya.Nortwnd;

public partial class KritikSeviyeUrunBilgileri
{
    public string ÜrünAdı { get; set; } = null!;

    public string Kategori { get; set; } = null!;

    public string TedarikçiFirma { get; set; } = null!;

    public short? MinimumSiparişAdedi { get; set; }

    public decimal? BirimFiyat { get; set; }
}
