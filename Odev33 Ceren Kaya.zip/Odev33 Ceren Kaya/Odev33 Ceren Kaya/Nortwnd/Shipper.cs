﻿using System;
using System.Collections.Generic;

namespace Odev33_Ceren_Kaya.Nortwnd;

public partial class Shipper
{
    public int ShipperId { get; set; }

    public string CompanyName { get; set; } = null!;

    public string? Phone { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
