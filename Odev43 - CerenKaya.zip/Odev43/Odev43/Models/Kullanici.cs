﻿using Odev43.CustomValidation;

namespace Odev43.Models
{
    public class Kullanici
    {
        [EmailAttribute]
        public string Email { get; set; }
    }
}
