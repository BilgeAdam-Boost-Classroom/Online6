﻿using System.ComponentModel.DataAnnotations;

namespace Odev43.CustomValidation
{
    public class EmailAttribute : ValidationAttribute
    {
        public EmailAttribute()
        {
            
        }

        public override bool IsValid(object? value)
        {
            string mail = value?.ToString();

            if (mail != null)
            {
                if (mail.Trim().EndsWith("@bilgeadam.com"))
                {
                    return true;
                }
                else {
                    ErrorMessage = "Mailiniz '@bilgeadam.com' ile bitmelidir.";
                    return false;}
            }
            else { ErrorMessage = "Mail Boş bırakılamaz";  return false; }

            
        }
    }
}
