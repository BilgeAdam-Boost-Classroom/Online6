using Microsoft.AspNetCore.Mvc;
using Odev43.Models;
using System.Diagnostics;

namespace Odev43.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Kullanici kullanici)
        {
            try
            {
                if(ModelState.IsValid)
                {
                    Kullanici k = new Kullanici();
                    k.Email = kullanici.Email;
                
           
                    ViewData["basarili"] = "E-mail kabul edildi!";
                }
               
            }
            catch (Exception)
            {
                ViewData["Hata"] = "Bilinmeyen hata ile kar��al�t�k. Tekrar giri� yap�n!";
                return View();
               
            }
        
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
