﻿using Microsoft.AspNetCore.Mvc;
using Odev38_MVC.Models;

namespace Odev38_MVC.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult Liste()
        {
            List<Urun> urunler = new List<Urun>();
            Urun urun1 = new Urun();
            Urun urun2 = new Urun();
            Urun urun3 = new Urun();
            Urun urun4 = new Urun();
            Urun urun5 = new Urun();
            urunler.AddRange(new Urun[] { urun1, urun2, urun3, urun4, urun5 });
            return View(urunler);

        }
    }
}
