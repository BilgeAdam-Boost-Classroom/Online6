﻿namespace Odev38_MVC.Models
{
    public class Urun
    {
        Random rnd = new Random();
        public int Numara { get; set; }

        public Urun()
        {
            Numara = rnd.Next(1, 101);
        }
    }
}
