﻿using Microsoft.AspNetCore.Mvc;

namespace Odev38.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult Liste()
        {
            List<Urun> urunListesi = new List<Urun>
        {
            new Urun(),
            new Urun(),
            new Urun(),
            new Urun(),
            new Urun()
        };


            return View(urunListesi);
        }
    }
}
