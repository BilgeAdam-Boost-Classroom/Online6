﻿using Microsoft.AspNetCore.Mvc;
using Odev38.Models;

namespace Odev38.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult Liste()
        {
            List<Urun> urunler = new List<Urun>();
            for (int i = 0; i < 5; i++)
            {
                urunler.Add(new Urun());  
            }
            return View(urunler);
        }
    }
}
