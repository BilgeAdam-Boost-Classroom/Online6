﻿using Microsoft.AspNetCore.Mvc;
using Odev38.Models;

namespace Odev38.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult Liste()
        {
            List<Urun> urunler = new List<Urun>();
            urunler.Add(new Urun() { Ad = "Domates"});
            urunler.Add(new Urun() { Ad = "Biber"});
            urunler.Add(new Urun() { Ad = "Patlıcan"});
            urunler.Add(new Urun() { Ad = "Salatalık"});
            urunler.Add(new Urun() { Ad = "Havuç"});
            return View(urunler);
        }
    }
}
