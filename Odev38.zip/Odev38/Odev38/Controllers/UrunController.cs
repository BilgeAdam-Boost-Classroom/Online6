﻿using Microsoft.AspNetCore.Mvc;
using Odev38.Models;

namespace Odev38.Controllers
{
	public class UrunController : Controller
	{
		public IActionResult Liste()
		{
			List<UrunViewModel> list = new List<UrunViewModel>()
			{
				new UrunViewModel(),
				new UrunViewModel(),
				new UrunViewModel(),
				new UrunViewModel(),
				new UrunViewModel()
			};
			return View(list);
		}
	}
}

