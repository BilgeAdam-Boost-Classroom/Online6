﻿namespace Odev38.Controllers
{
    public class Urun
    {
        public int Numara { get; set; }

        public Urun()
        {
           
            Random random = new Random();
            Numara = random.Next(1, 100); 
        }
    }
}
