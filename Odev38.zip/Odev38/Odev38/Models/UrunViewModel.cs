﻿namespace Odev38.Models
{
	public class UrunViewModel
	{
		public int Numara { get; set; } = new Random().Next(10);
    }
}
