﻿namespace Odev38.Models
{
    public class Urun
    {
        Random rnd = new Random();
        public Urun()
        {
            Numara = rnd.Next(0, 1000);
        }
        public int Numara { get; set; }
    }
}
