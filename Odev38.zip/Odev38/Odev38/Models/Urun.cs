﻿namespace Odev38.Models
{
    public class Urun
    {
        public string Ad { get; set; } = string.Empty;
        public int Numara { get { return new Random().Next(1, 100); } }
    }
}
