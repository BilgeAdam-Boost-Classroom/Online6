﻿using Microsoft.AspNetCore.Mvc;

namespace Odev38.Models
{
	public class Urun
	{
		public int Numara { get; set; }

		public Urun()
		{
			Random random = new Random();
			Numara = random.Next(1, 1000);
		}

	}
}
