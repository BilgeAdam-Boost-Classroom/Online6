namespace _6._10._2023_tahminOyunu
{
    public partial class Form1 : Form
    {
        Random rastgeleUretici = new Random();
        int uretilenSayi, tahminEdilen;
        

        public Form1()
        {
            InitializeComponent();
            progressBar.Maximum = 10; //s�re 30 saniyeymi� gibi ayarland�

        }

        private void btnBaslat_Click(object sender, EventArgs e)
        {
            // oyun ba�lad���nda , oyunu ba�lat butonunu kapat
            btnBaslat.Enabled = false;

            // oyun ba�lad��� zaman �nce timer ' � ba�latal�m
            oyunTimer.Start();

            // program rastgele say� uretecek
            uretilenSayi = rastgeleUretici.Next(1, 101);

            // progress bar ' �n durumunu ayarlayal�m ( yani doluluk oran� )
            progressBar.Value = progressBar.Maximum;   // =100;  da yaz�labilir.       // doluluk oran� %100

            // oyun ba�lad��� zaman txtSayi textini a�
            txtSayi.Enabled = true;



        }

        private void txtSayi_TextChanged(object sender, EventArgs e)  // metin her de�i�ti�inde buras� �al���r
        {
            if (txtSayi.Text == "" || !int.TryParse(txtSayi.Text, out int anlikYazilanSayi)
               || (txtSayi.Text.Contains(" ") && btnTahmin.Enabled))
                btnTahmin.Enabled = false;

            else if (!btnTahmin.Enabled && !txtSayi.Text.Contains(" "))
                btnTahmin.Enabled = true;
        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            lblBilgi.Text = string.Empty;

            // tahmin edilen say�y� al
            tahminEdilen = Convert.ToInt32(txtSayi.Text);

            if (tahminEdilen < uretilenSayi)
                lblBilgi.Text = tahminEdilen.ToString() + "=> k���k bir say� girdiniz " + " => ipucu:" + uretilenSayi;
            else if (tahminEdilen > uretilenSayi)
                lblBilgi.Text = tahminEdilen.ToString() + "=> b�y�k bir say� girdiniz " + " => ipucu:" + uretilenSayi;
            else
            {
                lblBilgi.Text = "KAZANDINIZ :)";
            }
        }

        private void oyunTimer_Tick(object sender, EventArgs e)   // buras� her bir saniye de �al��acak ( ��nk� timer '�n interval '�n� 1000 ms yapt�k.
        {

            // progres bar�n de�erini azalt
            progressBar.Value--;

            // her saniye ge�ti�inde tahmin et butonunun yan�nda kalan s�reyi g�ster
            btnTahmin.Text = "TAHM�N ET" + "(" + progressBar.Value.ToString() + ")";

            if (progressBar.Value >= 30 && progressBar.Value <= 50)
                lblMesaj.Text = "s�re daha var :)";
            else if (progressBar.Value >= 20 && progressBar.Value <= 29)
                lblMesaj.Text = "s�re yava� yava� azal�yor...";
            else if (progressBar.Value >= 1 && progressBar.Value <= 19)
                lblMesaj.Text = "s�re �ok az kald� !!!";

            // progress bar�n degeri s�f�r oldu�u zaman timer durdur
            if (progressBar.Value == 0)
            {
                oyunTimer.Stop();
                btnBaslat.Enabled = true;
                txtSayi.Clear();
                txtSayi.Enabled = false;
                btnTahmin.Enabled = false;
                if (lblBilgi.Text != "KAZANDINIZ :)")
                {
                    lblMesaj.Text = "KAYBETT�N�Z :(";
                    lblBilgi.Text=string.Empty;
                }
                else
                    lblMesaj.Text=string.Empty;

            }
        }
    }
}