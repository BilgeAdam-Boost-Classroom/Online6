﻿namespace _6._10._2023_tahminOyunu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnBaslat = new Button();
            label1 = new Label();
            txtSayi = new TextBox();
            btnTahmin = new Button();
            lblBilgi = new Label();
            progressBar = new ProgressBar();
            lblMesaj = new Label();
            oyunTimer = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // btnBaslat
            // 
            btnBaslat.Location = new Point(25, 26);
            btnBaslat.Margin = new Padding(4);
            btnBaslat.Name = "btnBaslat";
            btnBaslat.Size = new Size(514, 101);
            btnBaslat.TabIndex = 0;
            btnBaslat.Text = "OYUNU BAŞLAT";
            btnBaslat.UseVisualStyleBackColor = true;
            btnBaslat.Click += btnBaslat_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(55, 168);
            label1.Name = "label1";
            label1.Size = new Size(249, 21);
            label1.TabIndex = 1;
            label1.Text = "[1-100] arasında bir sayı giriniz:";
            // 
            // txtSayi
            // 
            txtSayi.Enabled = false;
            txtSayi.Location = new Point(320, 168);
            txtSayi.Name = "txtSayi";
            txtSayi.Size = new Size(189, 29);
            txtSayi.TabIndex = 2;
            txtSayi.TextChanged += txtSayi_TextChanged;
            // 
            // btnTahmin
            // 
            btnTahmin.Enabled = false;
            btnTahmin.Location = new Point(55, 219);
            btnTahmin.Name = "btnTahmin";
            btnTahmin.Size = new Size(462, 47);
            btnTahmin.TabIndex = 3;
            btnTahmin.Text = "TAHMİN ET";
            btnTahmin.UseVisualStyleBackColor = true;
            btnTahmin.Click += btnTahmin_Click;
            // 
            // lblBilgi
            // 
            lblBilgi.BackColor = Color.Coral;
            lblBilgi.BorderStyle = BorderStyle.FixedSingle;
            lblBilgi.Location = new Point(25, 310);
            lblBilgi.Name = "lblBilgi";
            lblBilgi.Size = new Size(514, 39);
            lblBilgi.TabIndex = 4;
            // 
            // progressBar
            // 
            progressBar.Location = new Point(25, 374);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(514, 23);
            progressBar.TabIndex = 5;
            // 
            // lblMesaj
            // 
            lblMesaj.BackColor = Color.Bisque;
            lblMesaj.BorderStyle = BorderStyle.FixedSingle;
            lblMesaj.Location = new Point(25, 436);
            lblMesaj.Name = "lblMesaj";
            lblMesaj.Size = new Size(514, 73);
            lblMesaj.TabIndex = 4;
            // 
            // oyunTimer
            // 
            oyunTimer.Interval = 1000;
            oyunTimer.Tick += oyunTimer_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(567, 562);
            Controls.Add(progressBar);
            Controls.Add(lblMesaj);
            Controls.Add(lblBilgi);
            Controls.Add(btnTahmin);
            Controls.Add(txtSayi);
            Controls.Add(label1);
            Controls.Add(btnBaslat);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnBaslat;
        private Label label1;
        private TextBox txtSayi;
        private Button btnTahmin;
        private Label lblBilgi;
        private ProgressBar progressBar;
        private Label lblMesaj;
        private System.Windows.Forms.Timer oyunTimer;
    }
}