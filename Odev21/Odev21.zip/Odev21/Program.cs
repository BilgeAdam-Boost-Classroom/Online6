﻿

using Odev21;

BaseKitap k1 = new BaseKitap();
Kitap k2 = new Kitap();
TuremisKitap k3 = new TuremisKitap();


k1.GetLog();
k1.GetUser();

Console.WriteLine("***********************************");

k2.GetLog();
k2.GetUser();

Console.WriteLine("**************************************");

k3.GetLog();
k3.GetUser();



Console.ReadKey();