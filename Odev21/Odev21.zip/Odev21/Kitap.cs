﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21
{
    internal class Kitap : BaseKitap
    {

        public Kitap() { }

        public override void GetLog()
        {
            Console.WriteLine("Kitap get log ...");
        }

        public sealed override void GetUser()
        {
            Console.WriteLine("kitap get user ...");
        }






    }
}
