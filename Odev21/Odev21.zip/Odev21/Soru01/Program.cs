﻿using Soru01;

Kitap k = new Kitap();
BaseKitap bK = new BaseKitap();
TuremisKitap tK = new TuremisKitap();

k.GetUser(); k.GetLog();
bK.GetUser(); bK.GetLog();
tK.GetUser(); tK.GetLog();




Console.ReadLine(); 