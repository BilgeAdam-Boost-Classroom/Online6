﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru01
{
    public class Kitap : BaseKitap
    {
        public override void GetLog()
        {
            Console.WriteLine("Kitap get log...");
        }
        public override sealed void GetUser()
        {
            Console.WriteLine("Kitap get user...");
        }
    }
}
