﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21
{
    internal class TuremisKitap : Kitap
    {

        public TuremisKitap() { }

        public override void GetLog()
        {
            base.GetLog();
        }

        public override void GetUser()
        {
            Console.WriteLine("turemis kitap get user ...");
        }

    }
}
