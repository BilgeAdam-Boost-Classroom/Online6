﻿using Soru02;

Random rnd = new Random();
List<IPiece> taslar = new List<IPiece>();

string enCokTekrarEdenTas = "";
int ToplamTekrarSayisi = 0;

Console.WriteLine("Oyuna hoşgeldiniz. \nLütfen öncelikle satranç taşı eklemek için herhangi bir tuşa basınız.");
Console.WriteLine("Çıkmak için H/h basınız.");
char input = Console.ReadKey().KeyChar;
Console.WriteLine();

while (input != 'h' || input != 'h')
{
    Console.WriteLine("Satranç taşı listeye eklendi. Çıkmak için H/h basınız.\nDevam etmek için herhangi bir tuşa basınız.");
    // Random olarak çekilen taşı cekilen listesine ekle.
    taslar.Add(RandomCek());

    input = Console.ReadKey().KeyChar;
    Console.WriteLine();
}

for (int i = 0; i < taslar.Count; i++)
{
    int tekrarSayisi = 0;

    // Listeyi ekrana basan kod parçası
    Console.WriteLine("-----------------");
    Console.WriteLine(taslar[i].Name);
    Console.WriteLine(taslar[i].Color);
    taslar[i].Move();
    if (taslar[i].Name == "Piyon")
        taslar[i].Promote();
    Console.WriteLine("-----------------");

    // En çok tekrar eden taşın adedini bul.
    for (int j = i + 1; j < taslar.Count; j++)
        if (taslar[j].Name == taslar[i].Name)
            tekrarSayisi++;
    // En çok tekrar eden taşın adını bul.
    if (tekrarSayisi > ToplamTekrarSayisi)
        enCokTekrarEdenTas = taslar[i].Name;

}

Console.WriteLine("En çok tekrar eden taş: " + enCokTekrarEdenTas);

Console.WriteLine("Hoşçakalın.");
Console.ReadKey();


IPiece RandomCek()
{
    // Random ile enum'daki rengi çekip onu PieceColor tipinde al.
    int renkCek = rnd.Next(2);
    var cekilenRenkIsmi = Enum.GetName(typeof(PieceColor), renkCek);
    PieceColor cekilenRndRenk = (PieceColor)Enum.Parse(typeof(PieceColor), cekilenRenkIsmi!);

    // Taşları geçici bir listeye ekleyip renklerini random olarak belirlenen renge boya.
    List<IPiece> OrnekTaslar = new List<IPiece>()
    {
        new Bishop("Fil", cekilenRndRenk),
        new King("Şah", cekilenRndRenk),
        new Knight("At", cekilenRndRenk),
        new Pawn("Piyon", cekilenRndRenk),
        new Queen("Vezir", cekilenRndRenk),
        new Rook("Kale", cekilenRndRenk)
    };
    int CekilenRndTas = rnd.Next(OrnekTaslar.Count);

    // OrnekTaslar Listesinden random olarak çekilen taşı programa döndür.
    return OrnekTaslar[CekilenRndTas];
}