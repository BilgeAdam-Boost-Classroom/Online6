﻿using Microsoft.AspNetCore.Mvc;
using Odev44.Data;

namespace Odev44.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class ArabaController : Controller
    {
        private readonly UygulamaDBContext _db;

        public ArabaController(UygulamaDBContext db)
        {
            _db = db;   
        }

        [Route("Customer")]
        public IActionResult Index()
        {
            return View(_db.Arabalar.ToList());
        }
    }
}
