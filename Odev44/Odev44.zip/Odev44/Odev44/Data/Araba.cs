﻿
namespace Odev44.Data
{
    public class Araba
    {
        public int Id { get; set; }
        public string Marka { get; set; }
        public int Yili { get; set; }
    }
}
