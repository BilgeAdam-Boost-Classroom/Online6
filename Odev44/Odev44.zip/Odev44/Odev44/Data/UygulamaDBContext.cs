﻿using Microsoft.EntityFrameworkCore;

namespace Odev44.Data
{
    public class UygulamaDBContext : DbContext
    {
        public UygulamaDBContext(DbContextOptions<UygulamaDBContext> options) : base(options)
        {

        }

        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(
                new Araba() { Id = 1, Marka = "VW", Yili = 2008 },
                new Araba() { Id = 2, Marka = "Honda", Yili = 2023 },
                new Araba() { Id = 3, Marka = "Toyota", Yili = 2005 },
                new Araba() { Id = 4, Marka = "Ferrari", Yili = 2024 },
                new Araba() { Id = 5, Marka = "Alfa Romeo", Yili = 2023 }
            );
        }
    }
}
