﻿using System.ComponentModel.DataAnnotations;

namespace Odev46.Data
{
    public class Oyun
    {
        public Oyun()
        {
            string barkod = "";
            Random rnd = new Random();
            for (int i = 0; i < 13; i++)
            {
                if (i == 0)
                {
                    barkod += rnd.Next(1, 10).ToString();
                }
                else
                {
                    barkod += rnd.Next(10).ToString();
                }
            }
            _barkodNumarasi = barkod;
        }

        public int Id { get; set; }

        public string OyunAdi { get; set; } = null!;

        public double Fiyat { get; set; }

        public string Platform { get; set; } = null!;

        private string _barkodNumarasi = null!;

        [MaxLength(13)]
        public string BarkodNumarasi
        {
            get
            {
                return _barkodNumarasi;
            }
            private set 
            {
                _barkodNumarasi = value;
            }
        }

        public bool TekPlatform { get; set; }
    }
}
