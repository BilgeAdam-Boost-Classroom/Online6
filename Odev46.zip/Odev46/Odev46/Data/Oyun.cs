﻿namespace Odev46.Data
{
    public class Oyun
    {
        public int Id { get; set; }

        public string OyunAdi { get; set; } = null!;

        public double Fiyat { get; set; } 

        public string Platform { get; set; } = null!;

        public long BarkodNo { get; set; } 

        public bool TekPlatform { get; set; }
    }
}
