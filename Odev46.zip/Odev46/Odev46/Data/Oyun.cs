﻿namespace Odev46.Data
{
	public class Oyun
	{
        public int Id { get; set; }
        public string Ad { get; set; } = null!;
        public double Fiyat { get; set; }
        public string Platform { get; set; } = null!;
        public string BarkodNo { get; set; } = null!;
        public bool TekPlatform { get; set; }
    }
}
