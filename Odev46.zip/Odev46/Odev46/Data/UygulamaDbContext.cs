﻿using Microsoft.EntityFrameworkCore;

namespace Odev46.Data
{
	public class UygulamaDbContext:DbContext
	{
		public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
		{

		}
		public DbSet<Oyun> Oyunlar {  get; set; }
	}
}
