using Microsoft.AspNetCore.Mvc;
using Odev46.Models;
using System.Diagnostics;

namespace Odev46.Controllers
{
	public class Home2Controller : Controller
	{
		private readonly ILogger<Home2Controller> _logger;

		public Home2Controller(ILogger<Home2Controller> logger)
		{
			_logger = logger;
		}

		public IActionResult Index()
		{
			return View();
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
