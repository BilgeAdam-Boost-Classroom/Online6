﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev46.Data;

namespace Odev46.Controllers
{
	public class HomeController : Controller
	{
		private readonly UygulamaDbContext _context;

		public HomeController(UygulamaDbContext context)
		{
			_context = context;
		}

		public async Task<IActionResult> Index()
		{
			return View(await _context.Oyunlar.ToListAsync());
		}

		public async Task<IActionResult> Details(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var oyun = await _context.Oyunlar
				.FirstOrDefaultAsync(m => m.Id == id);
			if (oyun == null)
			{
				return NotFound();
			}

			return View(oyun);
		}

		public IActionResult Create()
		{
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("Id,Ad,Fiyat,Platform,BarkodNo,TekPlatform")] Oyun oyun)
		{
			ModelState.Remove("BarkodNo");
			if (ModelState.IsValid)
			{
				if (oyun.TekPlatform && _context.Oyunlar.Any(x => x.Ad == oyun.Ad))
				{
					ModelState.AddModelError("", "Oyun bulunmaktadır");
					return View(oyun);
				}


				if (_context.Oyunlar.Any(x => x.Ad == oyun.Ad && x.TekPlatform))
				{
					ModelState.AddModelError("", "Oyun Tek Platform olarak bulunmaktadır.");
					return View(oyun);
				}

				if (_context.Oyunlar.Any(x => x.Ad == oyun.Ad && x.Platform == oyun.Platform))
				{
					ModelState.AddModelError("", "Oyun aynı platformda bulunmaktadır.");
					return View(oyun);
				}

				string ornek;
				do
				{
					ornek = Rnd13();
				}
				while (_context.Oyunlar.Any(x => x.BarkodNo == ornek));

				oyun.BarkodNo = ornek;

				_context.Add(oyun);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			return View(oyun);
		}

		private string Rnd13()
		{
			Random rnd = new Random();

			string barkod = ((long)(rnd.NextDouble() * Math.Pow(10, 13))).ToString();
			return barkod.Length == 13 ? barkod : "0" + barkod;
			//return ((long)((rnd.Next(1,10)+rnd.NextDouble()) * Math.Pow(10, 12))).ToString();

		}

		public async Task<IActionResult> Edit(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var oyun = await _context.Oyunlar.FindAsync(id);
			if (oyun == null)
			{
				return NotFound();
			}
			return View(oyun);
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(int id, [Bind("Id,Ad,Fiyat,Platform,BarkodNo,TekPlatform")] Oyun oyun)
		{
			if (id != oyun.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{

				if (oyun.TekPlatform && _context.Oyunlar.Any(x => x.Ad == oyun.Ad && !(x.Id == oyun.Id)))
				{
					ModelState.AddModelError("", "Oyun bulunmaktadır");
					return View(oyun);
				}


				if (_context.Oyunlar.Any(x => x.Ad == oyun.Ad && x.TekPlatform && !(x.Id == oyun.Id)))
				{
					ModelState.AddModelError("", "Oyun Tek Platform olarak bulunmaktadır.");
					return View(oyun);
				}

				if (_context.Oyunlar.Any(x => x.Ad == oyun.Ad && x.Platform == oyun.Platform && !(x.Id == oyun.Id)))
				{
					ModelState.AddModelError("", "Oyun aynı platformda bulunmaktadır.");
					return View(oyun);
				}



				try
				{
					_context.Update(oyun);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!OyunExists(oyun.Id))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			return View(oyun);
		}

		public async Task<IActionResult> Delete(int? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var oyun = await _context.Oyunlar
				.FirstOrDefaultAsync(m => m.Id == id);
			if (oyun == null)
			{
				return NotFound();
			}

			return View(oyun);
		}

		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(int id)
		{
			var oyun = await _context.Oyunlar.FindAsync(id);
			if (oyun != null)
			{
				_context.Oyunlar.Remove(oyun);
			}

			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		private bool OyunExists(int id)
		{
			return _context.Oyunlar.Any(e => e.Id == id);
		}
	}
}
