﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev46.Data;

namespace Odev46.Controllers
{
    public class OyunlarController : Controller
    {
        private readonly UygulamaDbContext _context;
        private readonly Oyun _oyun;

        public OyunlarController(UygulamaDbContext context, Oyun oyun)
        {
            _context = context;
            _oyun = oyun;
        }

        // GET: Oyunlar
        public async Task<IActionResult> Index()
        {
            return View(await _context.Oyunlar.ToListAsync());
        }

        // GET: Oyunlar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oyun == null)
            {
                return NotFound();
            }

            return View(oyun);
        }

        // GET: Oyunlar/Create
        public IActionResult Create()
        {
            return View(_oyun);
        }

        // POST: Oyunlar/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,OyunAdi,Fiyat,BarkodNumarasi,Platform,TekPlatform")] Oyun oyun)
        {
            if (ModelState.IsValid)
            {
                if (oyun.TekPlatform && _context.Oyunlar.Any(x => x.OyunAdi == oyun.OyunAdi))
                {
                    ViewBag.Hata = "Eklemek istediğiniz oyun daha önce eklenmiş!";
                    return View(oyun);
                }
                else if (!oyun.TekPlatform && _context.Oyunlar.Any(x => x.OyunAdi.ToUpper() == oyun.OyunAdi.ToUpper() && x.Platform.ToUpper() == oyun.Platform.ToUpper()))
                {
                    ViewBag.Hata = "Eklemek istediğiniz oyun daha önce aynı platform için eklenmiş!";
                    return View(oyun);
                }
                else if (_context.Oyunlar.Any(x => x.OyunAdi == oyun.OyunAdi && x.TekPlatform))
                {
                    ViewBag.Hata = "Eklemek istediğiniz oyun daha önce başka bir platform için, \"TekPlatform\" özelliği ile eklenmiş!";
                    return View(oyun);
                }
                _context.Add(oyun);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(oyun);
        }

        // GET: Oyunlar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar.FindAsync(id);
            if (oyun == null)
            {
                return NotFound();
            }
            return View(oyun);
        }

        // POST: Oyunlar/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,OyunAdi,Fiyat,Platform,BarkodNumarasi,TekPlatform")] Oyun oyun)
        {
            if (id != oyun.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                if (oyun.TekPlatform && _context.Oyunlar.Any(x => x.OyunAdi.ToUpper() == oyun.OyunAdi.ToUpper() && x.Id != oyun.Id))
                {
                    ViewBag.Hata = "Aynı isimde başka kayıt olduğu için TekPlatform olarak kaydedilemez!";
                    return View(oyun);
                }
                else if (_context.Oyunlar.Any(x => x.OyunAdi.ToUpper() == oyun.OyunAdi.ToUpper() && x.Id != oyun.Id && x.Platform.ToUpper() == oyun.Platform.ToUpper()))
                {
                    ViewBag.Hata = "Daha önce aynı platform için ekleme yapılmış!";
                    return View(oyun);
                }
                try
                {
                    _context.Update(oyun);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OyunExists(oyun.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oyun);
        }

        // GET: Oyunlar/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oyun == null)
            {
                return NotFound();
            }

            return View(oyun);
        }

        // POST: Oyunlar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oyun = await _context.Oyunlar.FindAsync(id);
            if (oyun != null)
            {
                _context.Oyunlar.Remove(oyun);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OyunExists(int id)
        {
            return _context.Oyunlar.Any(e => e.Id == id);
        }
    }
}
