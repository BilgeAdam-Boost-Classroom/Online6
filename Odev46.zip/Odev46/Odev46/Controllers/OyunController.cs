﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev46.Data;

namespace Odev46.Controllers
{
    public class OyunController : Controller
    {
        private readonly UygulamaDbContext _context;

        public OyunController(UygulamaDbContext context)
        {
            _context = context;
        }

        // GET: Oyun
        public async Task<IActionResult> Index()
        {
            return View(await _context.Oyunlar.ToListAsync());
        }

        // GET: Oyun/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oyun == null)
            {
                return NotFound();
            }

            return View(oyun);
        }

        // GET: Oyun/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Oyun/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,OyunAdi,Fiyat,Platform,BarkodNo,TekPlatform")] Oyun oyun)
        {
            if (ModelState.IsValid)
            {
                // 1. Kontrol: Tek platformda aynı isimden başka oyun var mı?
                if (oyun.TekPlatform && _context.Oyunlar.Any(o => o.OyunAdi == oyun.OyunAdi))
                {
                    ModelState.AddModelError("OyunAdi", "Bu oyun ismi zaten kullanılmaktadır.");
                    return View(oyun);
                }

                // 2. Kontrol: Barkod numarası oluşturma ve daha önce kullanılmamış olmalı
                oyun.BarkodNo = BarkodNoOlustur();
                while (_context.Oyunlar.Any(o => o.BarkodNo == oyun.BarkodNo))
                {
                    oyun.BarkodNo = BarkodNoOlustur();
                }

                _context.Add(oyun);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(oyun);
        }

        // GET: Oyun/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar.FindAsync(id);
            if (oyun == null)
            {
                return NotFound();
            }
            return View(oyun);
        }

        // POST: Oyun/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,OyunAdi,Fiyat,Platform,BarkodNo,TekPlatform")] Oyun oyun)
        {
            if (id != oyun.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // 1. Kontrol: Tek platformda aynı isimden başka oyun var mı?
                if (oyun.TekPlatform && _context.Oyunlar.Any(o => o.OyunAdi == oyun.OyunAdi && o.Id != oyun.Id))
                {
                    ModelState.AddModelError("OyunAdi", "Bu oyun ismi zaten kullanılmaktadır.");
                    return View(oyun);
                }

                // 2. Kontrol: Barkod numarası daha önce kullanılmamış olmalı
                if (_context.Oyunlar.Any(o => o.BarkodNo == oyun.BarkodNo && o.Id != oyun.Id))
                {
                    ModelState.AddModelError("BarkodNo", "Bu barkod numarası zaten kullanılmaktadır.");
                    return View(oyun);
                }

                try
                {
                    _context.Update(oyun);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OyunExists(oyun.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oyun);
        }

        // GET: Oyun/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oyun == null)
            {
                return NotFound();
            }

            return View(oyun);
        }

        // POST: Oyun/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oyun = await _context.Oyunlar.FindAsync(id);
            if (oyun != null)
            {
                _context.Oyunlar.Remove(oyun);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private long BarkodNoOlustur()
        {
            Guid guid = Guid.NewGuid();
            byte[] bytes = guid.ToByteArray();

            // Guid'den alınan byte dizisini long'a çevirme
            long barkodNo = BitConverter.ToInt64(bytes, 0);

            // Negatif değerleri pozitife çevirme
            barkodNo = Math.Abs(barkodNo);

            return barkodNo;
        }

        private bool OyunExists(int id)
        {
            return _context.Oyunlar.Any(e => e.Id == id);
        }
    }
}
