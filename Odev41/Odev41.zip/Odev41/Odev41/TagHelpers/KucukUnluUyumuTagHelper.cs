﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Globalization;

namespace Odev41.TagHelpers
{

    public class KucukUnluUyumuTagHelper : TagHelper
    {
        [HtmlAttributeName("kelime")]
        public string Kelime { get; set; }
        bool uyuyorMu;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {


            if (KucukUnluUyumu(Kelime))
                output.Content.SetHtmlContent("küçük ünlü uyumu'na uygundur.");
            else
                output.Content.SetHtmlContent("küçük ünlü uyumu'na uymaz!");

        }

        private bool KucukUnluUyumu(string kelime)
        {
            if (string.IsNullOrEmpty(kelime))
            {
                return true;
            }

            char sonUnlu = SonUnluGetir(kelime);

            if ("aeıioöuü".Contains(sonUnlu))
            {
                return true;
            }
            else if ("ou".Contains(sonUnlu))
            {
                return "ae".Contains(kelime.ToLower()[0]);
            }
            else if ("aı".Contains(sonUnlu))
            {
                return "aeı".Contains(kelime.ToLower()[0]);
            }

            return false;
        }

        private char SonUnluGetir(string kelime)
        {
            CultureInfo trCulture = new CultureInfo("tr-TR");
            TextInfo textInfo = trCulture.TextInfo;
            kelime = textInfo.ToLower(kelime);

            for (int i = kelime.Length - 1; i >= 0; i--)
            {
                if ("aeıioöuü".Contains(kelime[i]))
                {
                    return kelime[i];
                }
            }

            return ' ';
        }
    }
}
