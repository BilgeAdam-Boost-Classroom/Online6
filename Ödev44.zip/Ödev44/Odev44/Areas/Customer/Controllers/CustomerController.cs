﻿using Microsoft.AspNetCore.Mvc;
using Odev44.Data;

namespace Odev44.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class CustomerController : Controller
    {
        private readonly UygulamaDbContext _db;

        public CustomerController(UygulamaDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            return View(_db.Arabalar.ToList());
        }
    }
}
