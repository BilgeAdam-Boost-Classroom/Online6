﻿using Microsoft.EntityFrameworkCore;

namespace Odev44.Data
{
	public class UygulamaDbContext : DbContext
	{
		public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
		{
		}

		public DbSet<Araba> Arabalar { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Araba>().HasData(
				new Araba() { Id = 1, Marka = "Audi", Model = "A4", Yil = 2010 },
				new Araba() { Id = 2, Marka = "BMW", Model = "X5", Yil = 2015 },
				new Araba() { Id = 3, Marka = "Mercedes", Model = "C200", Yil = 2018 },
				new Araba() { Id = 4, Marka = "Toyota", Model = "Corolla", Yil = 2020 },
				new Araba() { Id = 5, Marka = "Honda", Model = "Civic", Yil = 2019 }
			);
		}
	}
}
