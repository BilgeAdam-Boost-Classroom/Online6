﻿using System.ComponentModel.DataAnnotations;

namespace Odev44.Data
{
	public class Araba
	{
        public int Id { get; set; }

        [Required(ErrorMessage = "{0} alanı zorunludur")]
        public string Marka { get; set; } = null!;

        [Required(ErrorMessage ="{0} alanı zorunludur")]
        public string Model { get; set; } = null!;

		[Range(1900,2024,ErrorMessage ="Yıl aralığı 1900 ile {2} arasında olmalıdır.")]
        public int Yil { get; set; } = DateTime.Now.Year;
	}
}
