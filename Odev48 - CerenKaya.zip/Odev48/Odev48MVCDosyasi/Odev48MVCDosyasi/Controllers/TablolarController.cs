﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev48MVCDosyasi.Data;

namespace Odev48MVCDosyasi.Controllers
{
    public class TablolarController : Controller
    {
        private readonly HttpClient _httpClient;

        public TablolarController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // GET: Tablolar
        public async Task<IActionResult> Index()
        {
            return View(await _httpClient.GetFromJsonAsync<List<Tablo>>("https://localhost:7171/api/Tablolar"));
        }

        // GET: Tablolar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7171/api/Tablolar/"+id);
              
            if (tablo == null)
            {
                return NotFound();
            }

            return View(tablo);
        }

        // GET: Tablolar/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tablolar/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Ressam,YapilmaTarihi")] Tablo tablo)
        {
            if (ModelState.IsValid)
            {
                await _httpClient.PostAsJsonAsync("https://localhost:7171/api/Tablolar", tablo);              
                return RedirectToAction(nameof(Index));
            }
            return View(tablo);
        }

        // GET: Tablolar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7171/api/Tablolar/" + id);
            if (tablo == null)
            {
                return NotFound();
            }
            return View(tablo);
        }

        // POST: Tablolar/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Ressam,YapilmaTarihi")] Tablo tablo)
        {
            if (id != tablo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _httpClient.PutAsJsonAsync<Tablo>("https://localhost:7171/api/Tablolar/"+ id, tablo);
              
                }
                catch (DbUpdateConcurrencyException)
                {               
                        return NotFound();                  
                   
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tablo);
        }

        // GET: Tablolar/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7171/api/Tablolar/" + id);             
            if (tablo == null)
            {
                return NotFound();
            }

            return View(tablo);
        }

        // POST: Tablolar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7171/api/Tablolar/" + id);
            if (tablo != null)
            {
                await _httpClient.DeleteFromJsonAsync<Tablo>("https://localhost:7171/api/Tablolar/" + id);
            }

          
            return RedirectToAction(nameof(Index),"Tablolar");
        }
    }
}
