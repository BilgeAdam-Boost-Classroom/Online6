﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Odev48MVCDosyasi.Data
{
    public class TabloDbContext : DbContext
    {
        public TabloDbContext(DbContextOptions<TabloDbContext> options)
          : base(options)
        {
        }
        public DbSet<Tablo> Tablolar { get; set; } = default!;
    }
}
