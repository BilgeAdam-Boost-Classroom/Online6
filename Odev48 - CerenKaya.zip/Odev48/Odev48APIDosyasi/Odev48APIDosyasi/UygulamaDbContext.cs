﻿using Microsoft.EntityFrameworkCore;
using Odev48APIDosyasi;

public class UygulamaDbContext: DbContext
{
    public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options)
       : base(options)
    {
    }
    public DbSet<Tablo> Tablolar { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.Entity<Tablo>().HasData(new List<Tablo> {
    new Tablo { Id = 1, Ressam = "Vincent van Gogh", YapilmaTarihi = new DateTime(1889, 9, 9) }, // "Vincent van Gogh - Yıldızlı Gece"
    new Tablo { Id = 2, Ressam = "Leonardo da Vinci", YapilmaTarihi = new DateTime(1503, 6, 1) }, // "Leonardo da Vinci - Mona Lisa"
    new Tablo { Id = 3, Ressam = "Pablo Picasso", YapilmaTarihi = new DateTime(1907, 5, 11) }     // "Pablo Picasso - Les Demoiselles d'Avignon"
});

    }

}