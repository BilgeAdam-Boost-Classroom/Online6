﻿namespace Online6GaleriAjax.Dtos
{
    public class PostTablo
    {
        public string Ressam { get; set; }
        public DateTime YapilmaTarihi { get; set; }
    }
}
