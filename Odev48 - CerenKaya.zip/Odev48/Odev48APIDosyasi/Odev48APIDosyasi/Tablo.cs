﻿namespace Odev48APIDosyasi
{
    public class Tablo
    {
        public int Id { get; set; }
        public string Ressam { get; set; }
        public DateTime YapilmaTarihi { get; set; }
    }
}
