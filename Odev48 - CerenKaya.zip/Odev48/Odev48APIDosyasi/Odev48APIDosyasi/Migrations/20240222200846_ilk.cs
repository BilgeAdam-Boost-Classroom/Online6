﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev48APIDosyasi.Migrations
{
    /// <inheritdoc />
    public partial class ilk : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Tablolar",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ressam = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    YapilmaTarihi = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tablolar", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Tablolar",
                columns: new[] { "Id", "Ressam", "YapilmaTarihi" },
                values: new object[,]
                {
                    { 1, "Vincent van Gogh", new DateTime(1889, 9, 9, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, "Leonardo da Vinci", new DateTime(1503, 6, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, "Pablo Picasso", new DateTime(1907, 5, 11, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Tablolar");
        }
    }
}
