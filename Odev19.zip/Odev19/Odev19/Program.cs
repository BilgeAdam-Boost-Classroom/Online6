﻿namespace Odev19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ürünün adını giriniz: ");
            string ad = Console.ReadLine();
            Console.WriteLine("Ürünün fiyatını giriniz: ");
            decimal fiyat = Convert.ToDecimal(Console.ReadLine());
            Console.WriteLine("Ürünün üretim tarihini giriniz: ");
            DateTime uretimTarihi = Convert.ToDateTime(Console.ReadLine());

            Cihaz cihaz = new Cihaz("Kukalık", 7550.5m, new DateTime(2000,05,04));
            cihaz.SeriNumarasiUret();
            cihaz.BilgileriGoster();

            Console.ReadKey();
        }
    }
}
            
