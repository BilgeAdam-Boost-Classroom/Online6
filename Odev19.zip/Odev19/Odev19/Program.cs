﻿




using Odev19;

Console.WriteLine("Cihaz Adı: ");
string ad = Console.ReadLine();

Console.WriteLine("Fiyat: ");
double fiyat;
while (!double.TryParse(Console.ReadLine(), out fiyat))
{
    Console.Write("Geçerli bir fiyat giriniz: ");
}

Console.WriteLine("Üretim Tarihi: ");
DateTime uretimTarihi;
while (!DateTime.TryParse(Console.ReadLine(), out uretimTarihi))
{
    Console.Write("Geçerli bir tarih giriniz (GG.AA.YYYY): ");
}

Console.WriteLine( );
Cihaz cihaz = new Cihaz(ad, fiyat, uretimTarihi);
cihaz.BilgileriGoster();

Console.ReadKey();