﻿




using Odev19;

Console.WriteLine("Cihaz Adı: ");
string ad = Console.ReadLine();

Console.WriteLine("Fiyat: ");
double fiyat =Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Üretim Tarihi: ");
DateTime uretimTarihi = Convert.ToDateTime(Console.ReadLine());

Console.WriteLine();

Cihaz cihaz = new Cihaz(ad, fiyat, uretimTarihi);
cihaz.BilgileriGoster();




Console.ReadKey();