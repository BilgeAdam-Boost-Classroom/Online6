﻿
using Odev19;

Cihaz c1 = new Cihaz();
c1.BilgiGoster();



Console.ReadKey();