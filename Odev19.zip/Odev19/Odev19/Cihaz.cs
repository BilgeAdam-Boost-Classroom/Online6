﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev19
{
    public class Cihaz
    {
        Random rnd = new Random();
        double rastgeleUretilenSayi;
        public Cihaz(string ad, decimal fiyat, DateTime uretimTarihi)
        {
            Ad = ad;
            Fiyat = fiyat;
            UretimTarihi = uretimTarihi;
        }
        public string Ad { get; set; }
        public decimal Fiyat { get; set; }
        public double SeriNumarasi { get; set; }
        public DateTime UretimTarihi { get; set; }
        public double SeriNumarasiUret()
        {
            rastgeleUretilenSayi = rnd.Next(1000,9999);
            SeriNumarasi = rastgeleUretilenSayi;
            return SeriNumarasi;
        }
        public void BilgileriGoster()
        {

            Console.WriteLine("Ad: " + Ad + "\n" + "Fiyat: " + Fiyat + "\n" + "Seri Numarası: "
                + SeriNumarasi + "\n" + "Üretim Tarihi: " + UretimTarihi.ToLongDateString());
        }
    }
}

