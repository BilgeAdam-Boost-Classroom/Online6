﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev19
{
    public class Cihaz
    {
        public string Ad { get; set; }
        public decimal Fiyat { get; set; }
        public int SeriNo { get; private set; }
        public DateTime UretimTarihi { get; set; }


        public Cihaz()
        {
            decimal deger;
            DateTime tarih;

            Console.Write("Cihaz adını girin: ");
            Ad = Console.ReadLine();

            Console.Write("Fiyatını girin: ");
            while (!decimal.TryParse(Console.ReadLine(),out deger)||deger<0)
                Console.Write("Fiyatı tekrar girin:");
            Fiyat = deger;

            Console.Write("Üretim tarihi girin: ");
            while (!DateTime.TryParse(Console.ReadLine(), out tarih))
                Console.Write("Üretim tarihini tekrar girin:");

            UretimTarihi = tarih;

            SeriNoAta();


        }
        public void SeriNoAta()
        {
            SeriNo=new Random().Next(1000,10000);
        }

        public void BilgiGoster()
        {
            Console.WriteLine($"Adı          : {Ad}\nFiyatı       : {Fiyat}\nSeri no      : {SeriNo}\nÜretim tarihi: {UretimTarihi.ToShortDateString()}");
        }
    }
}
