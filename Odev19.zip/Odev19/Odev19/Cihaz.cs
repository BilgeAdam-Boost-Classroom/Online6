﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev19
{
    public class Cihaz
    {
        public Cihaz(string ad, double fiyat, DateTime uretimTarihi)
        {
            Ad = ad;
            Fiyat = fiyat;
            UretimTarihi = uretimTarihi;
            SeriNumarasiUret();
        }

        public string Ad { get; set; }

        public double Fiyat { get; set; }

        public int SeriNumarasi { get; private set; }

        public DateTime UretimTarihi { get; set; }

        private void SeriNumarasiUret()
        {
            Random rnd = new Random();
            SeriNumarasi = rnd.Next(1000, 10000);
        }

        public void BilgileriGoster()
        {
            Console.WriteLine("Cihaz Adı: " + Ad);
            Console.WriteLine("Fiyat: " + Fiyat);
            Console.WriteLine("Seri Numarası: " + SeriNumarasi);
            Console.WriteLine("Üretim Tarihi: " + UretimTarihi.ToLongDateString());
        }
    }
}
