USE NORTHWND;
GO
--UYGULAMA 1
SELECT * FROM Employees
WHERE FirstName NOT LIKE '[A-I]%';

--UYGULAMA 2
--Y�NTEM 1
SELECT * FROM Employees
WHERE (FirstName NOT LIKE '_A%') AND (FirstName NOT LIKE '_T%');
--Y�NTEM 2
SELECT * FROM Employees
WHERE FirstName NOT LIKE '_[AT]%';

--UYGULAMA 3
SELECT * FROM Employees
WHERE SUBSTRING(FirstName, 1,2) IN ('LA', 'LN', 'AA', 'AN');

--UYGULAMA 4
SELECT FirstName FROM Employees
WHERE FirstName NOT LIKE '%_%';

--UYGULAMA 5
SELECT TOP 10 PERCENT CustomerID FROM Customers
WHERE CustomerID LIKE N'_A_T%'
ORDER BY CustomerId DESC;

--UYGULAMA 6
SELECT FirstName, LastName, DATEPART(MINUTE, BirthDate)[Saat] FROM Employees
ORDER BY [Saat] DESC;

--UYGULAMA 7
SELECT FirstName, LastName, DATEPART(MINUTE, BirthDate) [Dakika] FROM Employees
ORDER BY [Dakika] DESC;

--UYGULAMA 8
SELECT DATEDIFF(DAY, '2000-07-15', GETDATE()) AS Gunler;

--UYGULAMA 9
SELECT OrderDate, ShippedDate FROM Orders
WHERE MONTH(OrderDate) = 7 AND DAY(ShippedDate) > 15;

--UYGULAMA 10
CREATE DATABASE SatrancDb;
GO
USE SatrancDb;
GO
CREATE TABLE Taslar
(
   Id INT PRIMARY KEY,
   Ad NVARCHAR(50) NOT NULL,
   Hareket NVARCHAR(MAX) NOT NULL,
   Renk BIT NOT NULL
);

INSERT INTO Taslar (Id, Ad, Hareket, Renk) VALUES 
(1, '�ah', '1 Birim D�z-Yatay-�apraz', 0),
(2, 'Vezir', 'D�z, �apraz ve Yatay', 0),
(3, 'Kale', 'Yatay ve D��ey', 0),
(4, 'Fil', '�apraz', 0),
(5, 'At', 'L Bi�iminde', 0),
(6, 'Piyon', '1 Birim �leri', 1);
