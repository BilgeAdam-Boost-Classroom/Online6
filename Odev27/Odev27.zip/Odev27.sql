Create Database Odev27
go
use Odev27

/*
1 sınıfın 1 öğretmeni olabilir ama 1 öğretmenin birden fazla sınıfı olabilir.
Öğretmensiz sınıf ve sınıfı olmayan öğretmen de olabilir.

Öğretmenler tablosuna 5 adet öğretmen ekleyiniz.() (Soyadlarını istediğiniz gibi giriniz.) Sınıflar tablosuna ise 10 adet sınıf ekleyiniz. 1. eklediğiniz sınıfa Salih, 2. eklediğiniz sınıfa Burcu, 3. eklediğiniz sınıfa Nazmi, 4. 5. ve 6. eklediğiniz sınıfa Remzi öğretmeni atayınız. Geriye kalan 4 sınıfın öğretmeni NULL olmalıdır. Pelin öğretmenin de hiç sınıfı olmamalıdır. 

Bu bilgilere göre aşağıdaki sonuçları getiren sorguları yazınız. 
• Sınıfı olan öğretmenlerin ad,soyad,sınıfId ve sınıfad listesi
• Sınıfı olmayan öğretmenlerin ad ve soyad listesi 
• Öğretmeni olmayan sınıfların Id’leri ve sinifadları listesi 
• GENEL liste: Ogretmen ad, ogretmen soyad,sınıfıd ve sınıfad. Değerler varsa yazmalı yoksa NULL yazmalı.*/

create table Ogretmenler(
OgretmenId int primary key identity,
OgretmenAd nvarchar(50) not null,
OgretmenSoyAd nvarchar(50) not null
)

Create table Siniflar(
SinifId int primary key identity,
SinifAd nvarchar(10) not null,
OgretmenId int foreign key references Ogretmenler(OgretmenId) null
unique(SinifAd)
)

insert into Ogretmenler (OgretmenAd, OgretmenSoyAd)
values ('Salih','Yıldırım'), ('Burcu','Demirhan'), ('Nazmi','Aksoy'), ('Pelin','Öztürk'), ('Remzi','Kaya')

insert into Siniflar(SinifAd, OgretmenId)
values ('10A', 1), ('10B', 2), ('10C', 3), ('10D', 5), ('10E', 5), ('10F', 5), ('10G', null), ('10H', null), ('10I', null), ('10J', null)


/* Bu bilgilere göre aşağıdaki sonuçları getiren sorguları yazınız. */

-- Sınıfı olan öğretmenlerin ad,soyad,sınıfId ve sınıfad listesi
select o.OgretmenAd, o.OgretmenSoyAd, s.SinifId, s.SinifAd from Ogretmenler o
join Siniflar s on s.OgretmenId = o.OgretmenId

-- Sınıfı olmayan öğretmenlerin ad ve soyad listesi 
select o.OgretmenAd, o.OgretmenSoyAd from Ogretmenler o
left join Siniflar s on s.OgretmenId = o.OgretmenId
where s.SinifId is null

-- Öğretmeni olmayan sınıfların Id’leri ve sinif adları listesi 
select s.SinifId, s.SinifAd from Siniflar s
where s.OgretmenId is null

-- GENEL liste: Ogretmen ad, ogretmen soyad,
-- sınıfid ve sınıfad. 
-- Değerler varsa yazmalı yoksa NULL yazmalı.

select o.OgretmenAd, o.OgretmenSoyAd, s.SinifId, s.SinifAd from Ogretmenler o
full outer join Siniflar s on s.OgretmenId = o.OgretmenId