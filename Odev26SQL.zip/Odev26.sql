﻿--ODEV26

--1
USE master;
GO

DROP DATABASE IF EXISTS Odev26;
GO

CREATE DATABASE Odev26;
GO

USE Odev26;
GO

CREATE TABLE Danismanlar
(
	Id  INT PRIMARY KEY IDENTITY(1,1),
	Ad NVARCHAR(50) NOT NULL,
	Soyad NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Talebeler
(
	Id  INT PRIMARY KEY IDENTITY(1,1),
	Ad NVARCHAR(50) NOT NULL,
	Soyad NVARCHAR(50) NOT NULL,
	DanismanId INT FOREIGN KEY REFERENCES Danismanlar(Id) NULL
);
GO

INSERT INTO Danismanlar(Ad, Soyad)
VALUES
(N'Ali', N'Kara'),
(N'Ayse', N'Yilmaz'),
(N'Zeynep', N'Ata'),
(N'Ahmet', N'Can'),
(N'Cemre', N'Akar');
GO

INSERT INTO Talebeler(Ad, Soyad, DanismanId)
VALUES 
('Elif', 'Yılmaz', NULL),
('Ayşe', 'Kara', NULL),
('Can', 'Aydın', NULL),
('Mehmet', 'Demir', NULL),
('Ali', 'Kara', 1),
('Veli', 'Yılmaz', 1),
('Ahmet', 'Aydın', 2),
('Ayşe', 'Yılmaz', 3),
('Fatma', 'Kara', 4),
('Ali', 'Demir', 5);
GO

SELECT * FROM Danismanlar;
SELECT * FROM Talebeler;

SELECT Talebeler.Ad, Talebeler.Soyad, Danismanlar.Ad AS [Danisman Adi], Danismanlar.Soyad AS [Danisman Soyadi]
FROM Talebeler JOIN Danismanlar ON Talebeler.DanismanId = Danismanlar.Id;

SELECT Talebeler.Ad, Talebeler.Soyad, Danismanlar.Ad AS [Danisman Adi], Danismanlar.Soyad AS [Danisman Soyadi]
FROM Talebeler FULL JOIN Danismanlar ON Talebeler.DanismanId = Danismanlar.Id;


USE NORTHWND;
GO
--2
SELECT ProductName, Products.UnitPrice FROM Products JOIN [Order Details] ON Products.ProductID = [Order Details].ProductID
WHERE Discount != 0;

--3
SELECT City, CompanyName, ProductName FROM Products JOIN Suppliers ON Products.SupplierID = Suppliers.SupplierID
WHERE City = 'New Orleans' ORDER BY ProductName DESC;

--4
SELECT RegionDescription FROM Region JOIN Territories ON Region.RegionID = Territories.RegionID
WHERE TerritoryDescription = 'Boston';

--5
SELECT ProductName, CategoryName, Discontinued FROM Products JOIN Categories ON Products.CategoryID = Categories.CategoryID
WHERE (CategoryName = 'Seefood' OR CategoryName = 'Cheeses') AND Discontinued = 1;

--6
--SELECT Employees.FirstName, Employees.LastName FROM Employees JOIN Employees ON Employees.ReportsTo = Employees.EmployeeID;

SELECT e.FirstName, e.LastName, e2.FirstName AS ReportToFirstName, e2.LastName AS ReportToLastName
FROM Employees e JOIN Employees e2 ON e.ReportsTo = e2.EmployeeID;