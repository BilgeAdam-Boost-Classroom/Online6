-- 1)Danismanlar ad�nda bir tablo olu�turunuz.
create table Danismanlar(
Id int primary key identity(1,1),
Ad nvarchar(50) not null,
Soyad nvarchar(50) not null
)

-- Talebeler ad�nda bir tablo olu�turunuz
create table Talebeler(
Id int primary key identity(1,1),
Ad nvarchar(50) not null,
Soyad nvarchar(50) not null,
DanismanId int null foreign key references Danismanlar(Id)
)

-- 5 adet dan��man ekleyiniz.
insert into Danismanlar (Ad, Soyad)
values ('Ali', 'Veli'), ('Can', 'Dan��man'), ('Cem', 'Demir'), ('Ece', 'Kaya'), ('Mehmet', 'Y�lmaz')

-- Sonra 10 adet talebe ekleyiniz.
-- Ekledi�iniz 10 adet talebenin 6 tanesine birer dan��man atay�n�z.
insert into Talebeler (Ad, Soyad, DanismanId)
values
	('Ahmet', 'Y�lmaz', null),
    ('Ay�e', 'Kaya', 5),
    ('Mehmet', '�ahin', 1),
    ('Elif', 'Demir', null),
    ('Mustafa', 'Aksoy', 4),
    ('Fatma', 'Ayd�n', 3),
    ('Ali', '�elik', null),
    ('Zeynep', 'Akar', 5),
    ('�mer', 'G�ne�', 2),
    ('G�l', 'Ko�', null);

-- dan��man� olan talebelerin 
-- ad,soyad, dan��man ad ve dan��man soyad 
-- olmak �zere inner join sorgusu ile getiriniz.
select t.Ad, t.Soyad, d.Ad'Dan��man Ad�', d.Soyad'Dan��man Soyad�' from Talebeler t
inner join Danismanlar d
on d.Id = t.DanismanId

-- 2) Order Details tablosu ile Products tablosunu 
-- inner join yaparak discount'u s�f�rdan farkl� olanlar�n 
-- ProductName ve UnitPrice kolonlar�n� getiriniz.

use NORTHWND;
GO

select p.ProductName, od.UnitPrice
from [Order Details] od
inner join Products p
on od.ProductID = p.ProductID
where od.Discount > 0

-- 3) Products tablosu ile Suppliers tablosunu 
-- inner join yaparak Supplier'�n �ehri (city) 
-- New Orleans olanlar�n, city, companyname ve 
-- productname'lerini, productname'e g�re azalan
-- s�rada s�ralayarak getiriniz.

select s.City, s.CompanyName, p.ProductName from Products p
inner join Suppliers s
on p.SupplierID = s.SupplierID
where s.City = 'New Orleans'
order by p.ProductName desc

-- 4)TerritoryDescripttion'� Boston olan�n 
-- RegionDescription'�n� bulunuz. 
-- (Inner join kullanarak)

select t.TerritoryDescription, r.RegionDescription from Territories t
inner join Region r
on t.RegionID = r.RegionID
where TerritoryDescription = 'Boston'

-- 5) CategoryName'i Seefood VEYA description'� Cheeses olan
-- VE discontinued de�eri 1 olanlar� ProductName,CategoryName
-- ve Discontinued de�erlerini inner join ile getiriniz.

select p.ProductName, c.CategoryName, p.Discontinued
from Categories c
inner join Products p
on c.CategoryID = p.CategoryID
where (c.CategoryName like 'Seafood' OR c.Description like 'Cheeses')
and Discontinued = 1

-- 6)Employees tablosundaki ki�ilerin adlar�n�, soyadlar�n�
-- rapor verdikleri �al��an�n adlar�n� ve soyadlar�n� getiriniz.
-- (reports to kolonunu kullan�n�z). (Tabloyu kendisi ile inner join yap�n�z.)

select e.FirstName, e.LastName, r.FirstName'Rep. Name', r.LastName'Rep. Last Name'
from Employees e
inner join Employees r
on e.ReportsTo = r.EmployeeID