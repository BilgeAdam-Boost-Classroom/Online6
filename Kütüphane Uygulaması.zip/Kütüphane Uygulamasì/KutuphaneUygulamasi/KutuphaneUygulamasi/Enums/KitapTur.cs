﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KutuphaneUygulamasi.Enums
{
	public enum KitapTur
	{
		
		Bilim,
		BilimKurgu,
		Biyografi,
		CocukKitaplari,
		Deneme,
		Dini,
		DiniMetinler,
		EdebiyatElestiri,
		Fantastik,
		KendiniYardim,
		Klasik,
		Korku,
		Macera,
		MutfakveYemek,
		Polisiye,
		Roman,
		Romantik,
		SanatveMuzik,
		Seyahat,
		Tarih
	}
}
