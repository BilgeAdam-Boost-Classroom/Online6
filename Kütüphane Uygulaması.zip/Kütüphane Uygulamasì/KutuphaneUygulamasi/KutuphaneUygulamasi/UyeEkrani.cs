﻿using KutuphaneUygulamasi.Concrete;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneUygulamasi
{
	public partial class UyeEkrani : Form
	{
		public static List<Uye> uyeler = new List<Uye>();
		Uye secilenUye;

		public UyeEkrani()
		{
			InitializeComponent();
			lstUyeler.Items.AddRange(uyeler.ToArray());
		}

		private void UyeEkrani_Load(object sender, EventArgs e)
		{
			dtpDogumTarih.Value = Convert.ToDateTime("03 01 2000");
			dtpDogumTarih.MaxDate = DateTime.Now;
			dtpDogumTarih.MinDate = Convert.ToDateTime("01.01.1900");
		}
		private void btnEkle_Click(object sender, EventArgs e)
		{
			if (uyeler.Any(u => u.Numara == numNumara.Value))
			{
				MessageBox.Show("Üye numaraları aynı olamaz");
				return;
			}
			foreach (char c in txtAd.Text.Trim())
			{
				if (char.IsLetter(c) != true && (char.IsLetter(c) || c != ' '))
				{
					MessageBox.Show("Üye Adı sadece harflerden oluşmalıdır");
					return;
				}
			}
			foreach (char c in txtSoyad.Text)
			{
				if (!char.IsLetter(c))
				{
					MessageBox.Show("Üye Soyadı sadece harflerden oluşmaktadır.");
					return;
				}
			}
			Uye uye = new Uye();
			uye.Ad = txtAd.Text;
			uye.Soyad = txtSoyad.Text;
			uye.DogumTarih = dtpDogumTarih.Value;
			uye.Numara = (int)numNumara.Value;
			uyeler.Add(uye);
			lstUyeler.Items.Add(uye);
		}


		private void btnDuzenle_Click(object sender, EventArgs e)
		{
			if (secilenUye != null)
			{
				uyeler.Remove(secilenUye);
				if (uyeler.Any(u => u.Numara == numNumara.Value))
				{
					MessageBox.Show("Üye numaraları aynı olamaz");
					return;
				}
				foreach (char c in txtAd.Text)
				{
					if (!char.IsLetter(c) && (char.IsLetter(c) || c != ' '))
					{
						MessageBox.Show("Ad sadece harflerden oluşur.");
					}
				}
				foreach (char c in txtSoyad.Text)
				{
					if (!char.IsLetter(c))
					{
						MessageBox.Show("Soyad sadece harflerden oluşur.");
						return;
					}
				}
				{

				}

				secilenUye.Ad = txtAd.Text;
				secilenUye.Soyad = txtSoyad.Text;
				secilenUye.DogumTarih = dtpDogumTarih.Value;
				secilenUye.Numara = (int)numNumara.Value;
				uyeler.Add(secilenUye);
				lstUyeler.Items.Clear();
				lstUyeler.Items.AddRange(uyeler.ToArray());
			}
		}

		private void btnSil_Click(object sender, EventArgs e)
		{
			if (secilenUye != null)
			{
				uyeler.Remove(secilenUye);
				lstUyeler.Items.Remove(secilenUye);
			}
		}

		private void lstUyeler_SelectedIndexChanged(object sender, EventArgs e)
		{
			secilenUye = (Uye)lstUyeler.SelectedItem;
		}
	}
}
