﻿using KutuphaneUygulamasi.Concrete;
using KutuphaneUygulamasi.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneUygulamasi
{
	public partial class KitapEkrani : Form
	{
		public static List<Kitap> kitaplar = new List<Kitap>();
		Kitap secilenKitap;

		public KitapEkrani()
		{
			InitializeComponent();
			lstKitaplar.Items.AddRange(kitaplar.ToArray());
			List<KitapTur> kitapTurleri = new List<KitapTur>();
			foreach (var turler in Enum.GetNames(typeof(KitapTur)))
			{
				kitapTurleri.Add((KitapTur)Enum.Parse(typeof(KitapTur), turler));
			}

			cmbKitapTur.DataSource = kitapTurleri;

		}

		private void btnEkle_Click(object sender, EventArgs e)
		{
			if (kitaplar.Any(k => k.Numara == nudKitapNumara.Value))
			{
				MessageBox.Show("Kitap numaraları aynı olamaz.");
				return;
			}

			Kitap kitap = new Kitap();
			kitap.Ad = txtKitapAd.Text;
			kitap.Yazar = txtKitapYazar.Text;
			kitap.Numara = (int)nudKitapNumara.Value;
			kitap.BasimTarih = dtpKitapBasimTarih.Value;
			kitap.Tur = (KitapTur)cmbKitapTur.SelectedItem;
			kitaplar.Add(kitap);
			lstKitaplar.Items.Add(kitap);


		}

		private void KitapEkrani_Load(object sender, EventArgs e)
		{
			dtpKitapBasimTarih.MaxDate = DateTime.Now;
		}

		private void btnDuzenle_Click(object sender, EventArgs e)
		{
			if (secilenKitap != null)
			{
				kitaplar.Remove(secilenKitap);
				if (kitaplar.Any(k => k.Numara == nudKitapNumara.Value))
				{
					MessageBox.Show("Kitap numaraları aynı olamaz.");
					return;
				}

				secilenKitap.Ad = txtKitapAd.Text;
				secilenKitap.Yazar = txtKitapYazar.Text;
				secilenKitap.Numara = (int)nudKitapNumara.Value;
				secilenKitap.BasimTarih = dtpKitapBasimTarih.Value;
				secilenKitap.Tur = (KitapTur)cmbKitapTur.SelectedItem;
				kitaplar.Add(secilenKitap);
				lstKitaplar.Items.Clear();
				lstKitaplar.Items.AddRange(kitaplar.ToArray());
			}
		}

		private void lstKitaplar_SelectedIndexChanged(object sender, EventArgs e)
		{
			secilenKitap = (Kitap)lstKitaplar.SelectedItem;
		}

		private void btnSil_Click(object sender, EventArgs e)
		{
			if (secilenKitap != null)
			{
				kitaplar.Remove(secilenKitap);
				lstKitaplar.Items.Remove(secilenKitap);
			}
		}
	}
}
