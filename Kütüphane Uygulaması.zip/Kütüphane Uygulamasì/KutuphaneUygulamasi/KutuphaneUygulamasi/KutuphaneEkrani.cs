﻿using KutuphaneUygulamasi.Concrete;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneUygulamasi
{
	public partial class KutuphaneEkrani : Form
	{
		public static Uye secilenUye;
		public static Kitap secilenKitap;
		public KutuphaneEkrani()
		{
			InitializeComponent();
			cmbKisi.Items.AddRange(UyeEkrani.uyeler.ToArray());
			cmbKitap.Items.AddRange(KitapEkrani.kitaplar.ToArray());
		}

		private void KutuphaneEkrani_Load(object sender, EventArgs e)
		{

			dtpTeslim.MinDate = DateTime.Now;
			dtpTeslim.MaxDate = DateTime.Now.AddDays(60);
		}

		private void btnOduncVer_Click(object sender, EventArgs e)
		{
			//Kutuphane kutuphane = new Kutuphane();
			//kutuphane.TeslimTarih = dtpTeslim.Value;
			secilenUye = (Uye)cmbKisi.SelectedItem;
			secilenKitap = (Kitap)cmbKitap.SelectedItem;
			cmbKitap.Items.Remove(cmbKitap.SelectedItem);

			lstOduncVerilenler.Items.Add(secilenUye + " => (" + secilenKitap.Ad + secilenKitap.Yazar +secilenKitap.Tur+ ") " + "Teslim Tarihi:" + dtpTeslim.Value.ToShortDateString());
		}
	}
}
