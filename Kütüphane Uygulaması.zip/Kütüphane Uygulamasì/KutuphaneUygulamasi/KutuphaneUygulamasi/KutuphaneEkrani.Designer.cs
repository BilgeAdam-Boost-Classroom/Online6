﻿namespace KutuphaneUygulamasi
{
	partial class KutuphaneEkrani
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			cmbKisi = new ComboBox();
			label2 = new Label();
			cmbKitap = new ComboBox();
			label3 = new Label();
			dtpTeslim = new DateTimePicker();
			btnOduncVer = new Button();
			lstOduncVerilenler = new ListBox();
			label4 = new Label();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label1.Location = new Point(29, 52);
			label1.Name = "label1";
			label1.Size = new Size(102, 28);
			label1.TabIndex = 0;
			label1.Text = "Kişi Seçin:";
			// 
			// cmbKisi
			// 
			cmbKisi.DropDownStyle = ComboBoxStyle.DropDownList;
			cmbKisi.FormattingEnabled = true;
			cmbKisi.Location = new Point(169, 56);
			cmbKisi.Name = "cmbKisi";
			cmbKisi.Size = new Size(250, 28);
			cmbKisi.TabIndex = 1;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label2.Location = new Point(29, 127);
			label2.Name = "label2";
			label2.Size = new Size(117, 28);
			label2.TabIndex = 2;
			label2.Text = "Kitap Seçin:";
			// 
			// cmbKitap
			// 
			cmbKitap.DropDownStyle = ComboBoxStyle.DropDownList;
			cmbKitap.FormattingEnabled = true;
			cmbKitap.Location = new Point(169, 131);
			cmbKitap.Name = "cmbKitap";
			cmbKitap.Size = new Size(250, 28);
			cmbKitap.TabIndex = 3;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label3.Location = new Point(29, 201);
			label3.Name = "label3";
			label3.Size = new Size(128, 28);
			label3.TabIndex = 4;
			label3.Text = "Teslim Tarihi:";
			// 
			// dtpTeslim
			// 
			dtpTeslim.Location = new Point(169, 202);
			dtpTeslim.Name = "dtpTeslim";
			dtpTeslim.Size = new Size(250, 27);
			dtpTeslim.TabIndex = 5;
			// 
			// btnOduncVer
			// 
			btnOduncVer.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnOduncVer.Location = new Point(29, 303);
			btnOduncVer.Name = "btnOduncVer";
			btnOduncVer.Size = new Size(390, 48);
			btnOduncVer.TabIndex = 6;
			btnOduncVer.Text = "ÖDÜNÇ VER";
			btnOduncVer.UseVisualStyleBackColor = true;
			btnOduncVer.Click += btnOduncVer_Click;
			// 
			// lstOduncVerilenler
			// 
			lstOduncVerilenler.FormattingEnabled = true;
			lstOduncVerilenler.ItemHeight = 20;
			lstOduncVerilenler.Location = new Point(464, 53);
			lstOduncVerilenler.Name = "lstOduncVerilenler";
			lstOduncVerilenler.Size = new Size(657, 504);
			lstOduncVerilenler.TabIndex = 7;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
			label4.Location = new Point(464, 22);
			label4.Name = "label4";
			label4.Size = new Size(260, 28);
			label4.TabIndex = 8;
			label4.Text = "ÖDÜNÇ VERİLEN KİTAPLAR";
			// 
			// KutuphaneEkrani
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1266, 635);
			Controls.Add(label4);
			Controls.Add(lstOduncVerilenler);
			Controls.Add(btnOduncVer);
			Controls.Add(dtpTeslim);
			Controls.Add(label3);
			Controls.Add(cmbKitap);
			Controls.Add(label2);
			Controls.Add(cmbKisi);
			Controls.Add(label1);
			Name = "KutuphaneEkrani";
			Text = "KutuphaneEkrani";
			Load += KutuphaneEkrani_Load;
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private ComboBox cmbKisi;
		private Label label2;
		private ComboBox cmbKitap;
		private Label label3;
		private DateTimePicker dtpTeslim;
		private Button btnOduncVer;
		private ListBox lstOduncVerilenler;
		private Label label4;
	}
}