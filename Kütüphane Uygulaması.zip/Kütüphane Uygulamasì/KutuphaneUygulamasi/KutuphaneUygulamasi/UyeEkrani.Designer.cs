﻿namespace KutuphaneUygulamasi
{
	partial class UyeEkrani
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			label2 = new Label();
			label3 = new Label();
			dtpDogumTarih = new DateTimePicker();
			lstUyeler = new ListBox();
			btnEkle = new Button();
			btnDuzenle = new Button();
			btnSil = new Button();
			txtAd = new TextBox();
			txtSoyad = new TextBox();
			label4 = new Label();
			numNumara = new NumericUpDown();
			((System.ComponentModel.ISupportInitialize)numNumara).BeginInit();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label1.Location = new Point(22, 42);
			label1.Name = "label1";
			label1.Size = new Size(88, 28);
			label1.TabIndex = 0;
			label1.Text = "Üye Adı:";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label2.Location = new Point(22, 90);
			label2.Name = "label2";
			label2.Size = new Size(118, 28);
			label2.TabIndex = 1;
			label2.Text = "Uye Soyadı:";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label3.Location = new Point(22, 203);
			label3.Name = "label3";
			label3.Size = new Size(134, 28);
			label3.TabIndex = 2;
			label3.Text = "Doğum Tarihi";
			// 
			// dtpDogumTarih
			// 
			dtpDogumTarih.Location = new Point(183, 203);
			dtpDogumTarih.Name = "dtpDogumTarih";
			dtpDogumTarih.Size = new Size(250, 27);
			dtpDogumTarih.TabIndex = 3;
			// 
			// lstUyeler
			// 
			lstUyeler.FormattingEnabled = true;
			lstUyeler.ItemHeight = 20;
			lstUyeler.Location = new Point(550, 30);
			lstUyeler.Name = "lstUyeler";
			lstUyeler.Size = new Size(377, 384);
			lstUyeler.TabIndex = 4;
			lstUyeler.SelectedIndexChanged += lstUyeler_SelectedIndexChanged;
			// 
			// btnEkle
			// 
			btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnEkle.Location = new Point(31, 283);
			btnEkle.Name = "btnEkle";
			btnEkle.Size = new Size(114, 40);
			btnEkle.TabIndex = 5;
			btnEkle.Text = "EKLE";
			btnEkle.UseVisualStyleBackColor = true;
			btnEkle.Click += btnEkle_Click;
			// 
			// btnDuzenle
			// 
			btnDuzenle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnDuzenle.Location = new Point(183, 283);
			btnDuzenle.Name = "btnDuzenle";
			btnDuzenle.Size = new Size(114, 40);
			btnDuzenle.TabIndex = 6;
			btnDuzenle.Text = "DÜZENLE";
			btnDuzenle.UseVisualStyleBackColor = true;
			btnDuzenle.Click += btnDuzenle_Click;
			// 
			// btnSil
			// 
			btnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnSil.Location = new Point(344, 283);
			btnSil.Name = "btnSil";
			btnSil.Size = new Size(114, 40);
			btnSil.TabIndex = 7;
			btnSil.Text = "SİL";
			btnSil.UseVisualStyleBackColor = true;
			btnSil.Click += btnSil_Click;
			// 
			// txtAd
			// 
			txtAd.BorderStyle = BorderStyle.FixedSingle;
			txtAd.Location = new Point(183, 47);
			txtAd.Name = "txtAd";
			txtAd.Size = new Size(250, 27);
			txtAd.TabIndex = 8;
			// 
			// txtSoyad
			// 
			txtSoyad.Location = new Point(183, 90);
			txtSoyad.Name = "txtSoyad";
			txtSoyad.Size = new Size(250, 27);
			txtSoyad.TabIndex = 9;
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label4.Location = new Point(22, 139);
			label4.Name = "label4";
			label4.Size = new Size(139, 28);
			label4.TabIndex = 10;
			label4.Text = "Üye Numarası";
			// 
			// numNumara
			// 
			numNumara.Location = new Point(183, 144);
			numNumara.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
			numNumara.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
			numNumara.Name = "numNumara";
			numNumara.Size = new Size(250, 27);
			numNumara.TabIndex = 12;
			numNumara.Value = new decimal(new int[] { 1, 0, 0, 0 });
			// 
			// UyeEkrani
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1003, 487);
			Controls.Add(numNumara);
			Controls.Add(label4);
			Controls.Add(txtSoyad);
			Controls.Add(txtAd);
			Controls.Add(btnSil);
			Controls.Add(btnDuzenle);
			Controls.Add(btnEkle);
			Controls.Add(lstUyeler);
			Controls.Add(dtpDogumTarih);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "UyeEkrani";
			Text = "UyeEkrani";
			Load += UyeEkrani_Load;
			((System.ComponentModel.ISupportInitialize)numNumara).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Label label2;
		private Label label3;
		private DateTimePicker dtpDogumTarih;
		private ListBox lstUyeler;
		private Button btnEkle;
		private Button btnDuzenle;
		private Button btnSil;
		private TextBox txtAd;
		private TextBox txtSoyad;
		private Label label4;
		private NumericUpDown numNumara;
	}
}