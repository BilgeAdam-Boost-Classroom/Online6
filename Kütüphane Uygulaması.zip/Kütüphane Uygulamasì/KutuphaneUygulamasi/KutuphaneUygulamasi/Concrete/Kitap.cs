﻿using KutuphaneUygulamasi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KutuphaneUygulamasi.Concrete
{
	public class Kitap
	{
        public string Ad { get; set; }
        public string Yazar { get; set; }
        public DateTime BasimTarih { get; set; }
        public KitapTur Tur  { get; set; }
        public int Numara { get; set; }
		public override string ToString()
		{
			return $"{Numara} : {Ad} - {Yazar} - {Tur} - ({BasimTarih.ToShortDateString()})";
		}

	}
}
