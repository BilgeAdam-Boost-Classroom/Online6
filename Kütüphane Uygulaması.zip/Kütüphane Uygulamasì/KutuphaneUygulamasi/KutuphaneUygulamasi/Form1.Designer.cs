﻿namespace KutuphaneUygulamasi
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			menuStrip1 = new MenuStrip();
			üyeİslemleriToolStripMenuItem = new ToolStripMenuItem();
			kitapİslemleriToolStripMenuItem = new ToolStripMenuItem();
			kutuphaneIslemleriToolStripMenuItem = new ToolStripMenuItem();
			menuStrip1.SuspendLayout();
			SuspendLayout();
			// 
			// menuStrip1
			// 
			menuStrip1.ImageScalingSize = new Size(20, 20);
			menuStrip1.Items.AddRange(new ToolStripItem[] { üyeİslemleriToolStripMenuItem, kitapİslemleriToolStripMenuItem, kutuphaneIslemleriToolStripMenuItem });
			menuStrip1.Location = new Point(0, 0);
			menuStrip1.Name = "menuStrip1";
			menuStrip1.Size = new Size(1044, 28);
			menuStrip1.TabIndex = 0;
			menuStrip1.Text = "menuStrip1";
			// 
			// üyeİslemleriToolStripMenuItem
			// 
			üyeİslemleriToolStripMenuItem.Name = "üyeİslemleriToolStripMenuItem";
			üyeİslemleriToolStripMenuItem.Size = new Size(108, 24);
			üyeİslemleriToolStripMenuItem.Text = "Üye İşlemleri";
			üyeİslemleriToolStripMenuItem.Click += üyeİslemleriToolStripMenuItem_Click;
			// 
			// kitapİslemleriToolStripMenuItem
			// 
			kitapİslemleriToolStripMenuItem.Name = "kitapİslemleriToolStripMenuItem";
			kitapİslemleriToolStripMenuItem.Size = new Size(118, 24);
			kitapİslemleriToolStripMenuItem.Text = "Kitap İşlemleri";
			kitapİslemleriToolStripMenuItem.Click += kitapİslemleriToolStripMenuItem_Click;
			// 
			// kutuphaneIslemleriToolStripMenuItem
			// 
			kutuphaneIslemleriToolStripMenuItem.Name = "kutuphaneIslemleriToolStripMenuItem";
			kutuphaneIslemleriToolStripMenuItem.Size = new Size(154, 24);
			kutuphaneIslemleriToolStripMenuItem.Text = "Kütüphane İşlemleri";
			kutuphaneIslemleriToolStripMenuItem.Click += kutuphaneIslemleriToolStripMenuItem_Click;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1044, 603);
			Controls.Add(menuStrip1);
			MainMenuStrip = menuStrip1;
			Name = "Form1";
			Text = "Form1";
			menuStrip1.ResumeLayout(false);
			menuStrip1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private MenuStrip menuStrip1;
		private ToolStripMenuItem üyeİslemleriToolStripMenuItem;
		private ToolStripMenuItem kitapİslemleriToolStripMenuItem;
		private ToolStripMenuItem kutuphaneIslemleriToolStripMenuItem;
	}
}