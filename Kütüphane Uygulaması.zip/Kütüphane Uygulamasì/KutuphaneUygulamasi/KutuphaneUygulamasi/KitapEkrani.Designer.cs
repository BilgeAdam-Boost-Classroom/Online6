﻿namespace KutuphaneUygulamasi
{
	partial class KitapEkrani
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			label1 = new Label();
			label2 = new Label();
			label3 = new Label();
			label4 = new Label();
			txtKitapAd = new TextBox();
			txtKitapYazar = new TextBox();
			dtpKitapBasimTarih = new DateTimePicker();
			cmbKitapTur = new ComboBox();
			btnEkle = new Button();
			btnDuzenle = new Button();
			btnSil = new Button();
			lstKitaplar = new ListBox();
			label5 = new Label();
			nudKitapNumara = new NumericUpDown();
			((System.ComponentModel.ISupportInitialize)nudKitapNumara).BeginInit();
			SuspendLayout();
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label1.Location = new Point(16, 37);
			label1.Name = "label1";
			label1.Size = new Size(99, 28);
			label1.TabIndex = 0;
			label1.Text = "Kitap Adı:";
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label2.Location = new Point(16, 79);
			label2.Name = "label2";
			label2.Size = new Size(120, 28);
			label2.TabIndex = 1;
			label2.Text = "Kitap Yazarı:";
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label3.Location = new Point(10, 127);
			label3.Name = "label3";
			label3.Size = new Size(177, 28);
			label3.TabIndex = 2;
			label3.Text = "Kitap Basım Tarihi:";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label4.Location = new Point(16, 175);
			label4.Name = "label4";
			label4.Size = new Size(109, 28);
			label4.TabIndex = 3;
			label4.Text = "Kitap Türü:";
			// 
			// txtKitapAd
			// 
			txtKitapAd.Location = new Point(204, 41);
			txtKitapAd.Name = "txtKitapAd";
			txtKitapAd.Size = new Size(250, 27);
			txtKitapAd.TabIndex = 4;
			// 
			// txtKitapYazar
			// 
			txtKitapYazar.Location = new Point(204, 83);
			txtKitapYazar.Name = "txtKitapYazar";
			txtKitapYazar.Size = new Size(250, 27);
			txtKitapYazar.TabIndex = 5;
			// 
			// dtpKitapBasimTarih
			// 
			dtpKitapBasimTarih.Location = new Point(204, 129);
			dtpKitapBasimTarih.Name = "dtpKitapBasimTarih";
			dtpKitapBasimTarih.Size = new Size(250, 27);
			dtpKitapBasimTarih.TabIndex = 6;
			// 
			// cmbKitapTur
			// 
			cmbKitapTur.DropDownStyle = ComboBoxStyle.DropDownList;
			cmbKitapTur.FormattingEnabled = true;
			cmbKitapTur.Location = new Point(204, 179);
			cmbKitapTur.Name = "cmbKitapTur";
			cmbKitapTur.Size = new Size(250, 28);
			cmbKitapTur.TabIndex = 7;
			// 
			// btnEkle
			// 
			btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnEkle.Location = new Point(12, 272);
			btnEkle.Name = "btnEkle";
			btnEkle.Size = new Size(124, 37);
			btnEkle.TabIndex = 8;
			btnEkle.Text = "EKLE";
			btnEkle.UseVisualStyleBackColor = true;
			btnEkle.Click += btnEkle_Click;
			// 
			// btnDuzenle
			// 
			btnDuzenle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnDuzenle.Location = new Point(189, 272);
			btnDuzenle.Name = "btnDuzenle";
			btnDuzenle.Size = new Size(122, 37);
			btnDuzenle.TabIndex = 9;
			btnDuzenle.Text = "DÜZENLE";
			btnDuzenle.UseVisualStyleBackColor = true;
			btnDuzenle.Click += btnDuzenle_Click;
			// 
			// btnSil
			// 
			btnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			btnSil.Location = new Point(355, 272);
			btnSil.Name = "btnSil";
			btnSil.Size = new Size(122, 37);
			btnSil.TabIndex = 10;
			btnSil.Text = "SİL";
			btnSil.UseVisualStyleBackColor = true;
			btnSil.Click += btnSil_Click;
			// 
			// lstKitaplar
			// 
			lstKitaplar.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
			lstKitaplar.FormattingEnabled = true;
			lstKitaplar.ItemHeight = 20;
			lstKitaplar.Location = new Point(516, 29);
			lstKitaplar.Name = "lstKitaplar";
			lstKitaplar.Size = new Size(433, 384);
			lstKitaplar.TabIndex = 11;
			lstKitaplar.SelectedIndexChanged += lstKitaplar_SelectedIndexChanged;
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
			label5.Location = new Point(16, 222);
			label5.Name = "label5";
			label5.Size = new Size(155, 28);
			label5.TabIndex = 12;
			label5.Text = "Kitap Numarası:";
			// 
			// nudKitapNumara
			// 
			nudKitapNumara.Location = new Point(204, 227);
			nudKitapNumara.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
			nudKitapNumara.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
			nudKitapNumara.Name = "nudKitapNumara";
			nudKitapNumara.Size = new Size(250, 27);
			nudKitapNumara.TabIndex = 13;
			nudKitapNumara.Value = new decimal(new int[] { 1, 0, 0, 0 });
			// 
			// KitapEkrani
			// 
			AutoScaleDimensions = new SizeF(8F, 20F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(961, 476);
			Controls.Add(nudKitapNumara);
			Controls.Add(label5);
			Controls.Add(lstKitaplar);
			Controls.Add(btnSil);
			Controls.Add(btnDuzenle);
			Controls.Add(btnEkle);
			Controls.Add(cmbKitapTur);
			Controls.Add(dtpKitapBasimTarih);
			Controls.Add(txtKitapYazar);
			Controls.Add(txtKitapAd);
			Controls.Add(label4);
			Controls.Add(label3);
			Controls.Add(label2);
			Controls.Add(label1);
			Name = "KitapEkrani";
			Text = "KitapEkrani";
			Load += KitapEkrani_Load;
			((System.ComponentModel.ISupportInitialize)nudKitapNumara).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private TextBox txtKitapAd;
		private TextBox txtKitapYazar;
		private DateTimePicker dtpKitapBasimTarih;
		private ComboBox cmbKitapTur;
		private Button btnEkle;
		private Button btnDuzenle;
		private Button btnSil;
		private ListBox lstKitaplar;
		private Label label5;
		private NumericUpDown nudKitapNumara;
	}
}