namespace KutuphaneUygulamasi
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}
		public void FormGoster(Form secilenForm)
		{
			secilenForm.StartPosition = 0;
			bool durum = false;
			foreach (Form form in this.MdiChildren)
			{
				if (form.Text == secilenForm.Text)
				{
					durum = true;
					form.Show();
				}
				else
				{
					form.Close();
				}
			}
			if (!durum)
			{
				this.IsMdiContainer = true;
				secilenForm.MdiParent = this;
				secilenForm.Show();
			}
		}

		private void �ye�slemleriToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormGoster(new UyeEkrani());
		}

		private void kitap�slemleriToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormGoster(new KitapEkrani());
		}

		private void kutuphaneIslemleriToolStripMenuItem_Click(object sender, EventArgs e)
		{
			FormGoster(new KutuphaneEkrani());
		}
	}
}