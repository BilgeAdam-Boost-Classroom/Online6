﻿using Microsoft.AspNetCore.Mvc;

namespace Odev39.Models
{
	public class Oyuncu
	{
		public string Lig { get; set; }
		public int Ortalama { get; set; }
	}
}
