﻿using Microsoft.AspNetCore.Mvc;
using Odev39.Models;

namespace Odev39.Controllers
{
	public class BowlingController : Controller
	{
		public IActionResult Bowling()
		{
			Random rnd = new Random();
			List<Oyuncu> oyuncular = new List<Oyuncu>();

			string[] ligler = { "Profesyonel Lig", "Yarı Profesyonel Lig", "Amatör Lig" };
			int oyuncuSayisi = 15;

			for (int i = 1; i <= oyuncuSayisi; i++)
			{

				Oyuncu oyuncu = new Oyuncu();

				oyuncu.Lig = ligler[rnd.Next(0, 3)];

				oyuncular.Add(oyuncu);

			}
			return View(oyuncular);
		}
	}
}
