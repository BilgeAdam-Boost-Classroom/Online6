﻿namespace Odev39.Models
{
    public enum Ligler
    {
        AmatorLig,
        YariProfesyonelLig,
        ProfesyonelLig
    }
}
