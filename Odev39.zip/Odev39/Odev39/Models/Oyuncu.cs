﻿using System.Diagnostics.Metrics;

namespace Odev39.Models
{
    public class Oyuncu
    {
        public int Id { get; set; }
        public string LigTuru { get; set; } = string.Empty;
        public double Ortalama { get; set; }
    }
}
