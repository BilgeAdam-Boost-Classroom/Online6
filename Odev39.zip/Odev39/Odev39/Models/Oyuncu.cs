﻿namespace Odev39.Models
{
    public class Oyuncu
    {
        public int Id { get; set; }
        public string LigAdi { get; set; }
        public int LigOrtalamasi { get; set; }

    }
}
