﻿namespace Odev39.Models
{
    public class OyuncuViewModel
    {
        public int OyuncuNo { get; set; }   
        public string Lig { get; set; } = string.Empty;
        public int Ortalama { get; set; }
    }
}
