﻿namespace Odev39.Models
{
	public class OyuncuViewModel
	{
		public string Lig { get; set; }
        public int Ortalama { get; set; }

        public OyuncuViewModel()
        {
            int rnd = new Random().Next(3);
            int alt = rnd == 0 ? 180:rnd==1?191:220;
            int ust = rnd == 0 ? 191:rnd==1?220:241;

			Lig = new string[] { "Amatör Lig", "Yarı Profesyonel Lig","Profesyonel Lig"  }[rnd];
            Ortalama= new Random().Next(alt,ust);

		}
    }
}
