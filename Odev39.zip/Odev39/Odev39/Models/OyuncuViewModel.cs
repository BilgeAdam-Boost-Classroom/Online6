﻿namespace Odev39.Models
{
    public class OyuncuViewModel
    {
        public string Ad { get; set; } = null!;
        public int Puan { get; set; } = new Random().Next(180, 241);
        public string Lig
        {
            get
            {
                if (Puan <= 190)
                    return "Amatör Lig";
                else if (Puan <= 219)
                    return "Yarı Profesyonel Lig";
                else
                    return "Profesyonel Lig";
            }
        }
        public string Renk 
        {
            get
            {
                if (Puan <= 190)
                    return "secondary";
                else if (Puan <= 219)
                    return "success";
                else
                    return "danger";
            }
        }
    }
}
