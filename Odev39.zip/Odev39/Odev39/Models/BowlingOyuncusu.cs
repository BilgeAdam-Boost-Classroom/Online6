﻿namespace Odev39.Models
{
    public class BowlingOyuncusu
    {
        public string Ad { get; set; }
        public string Lig { get; set; }
        public int Ortalama { get; set; }
    }
}
