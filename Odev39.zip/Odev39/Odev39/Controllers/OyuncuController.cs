﻿using Microsoft.AspNetCore.Mvc;
using Odev39.Models;

namespace Odev39.Controllers
{
    public class OyuncuController : Controller
    {
        public IActionResult LigListesi()
        {
            List<Oyuncu> oyuncular = new List<Oyuncu>();
            List<string> ligTurleri = new List<string>() { "Amatör Lig", "Yarı Profesyonel Lig", "Profesyonel Lig" };
            Random rnd = new Random();
            for (int i = 1; i <= 15; i++)
            {
                Oyuncu oyuncu = new Oyuncu();
                oyuncu.Id = i;
                int rastgeleIndeks = rnd.Next(0, ligTurleri.Count);
                oyuncu.LigTuru = ligTurleri[rastgeleIndeks];

                if (oyuncu.LigTuru == ligTurleri[0])
                {
                    oyuncu.Ortalama = rnd.Next(180, 191);
                }
                else if (oyuncu.LigTuru == ligTurleri[1])
                {
                    oyuncu.Ortalama = rnd.Next(191, 220);
                }
                else if (oyuncu.LigTuru == ligTurleri[2])
                {
                    oyuncu.Ortalama = rnd.Next(220, 241);
                }

                oyuncular.Add(oyuncu);
            }
            return View(oyuncular);
        }
    }
}