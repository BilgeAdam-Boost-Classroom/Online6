﻿using Microsoft.AspNetCore.Mvc;
using Odev39.Models;

namespace Odev39.Controllers
{
    public class BowlingLigController : Controller
    {
        public IActionResult Lig()
        {
            List<OyuncuViewModel> oyuncular = new List<OyuncuViewModel>();
            List<string> ligTurleri = new List<string>() { "Amatör Lig", "Yarı Profesyonel Lig", "Profesyonel Lig" };
            Random rnd = new Random();
            for (int i = 1; i <= 15; i++)
            {
                OyuncuViewModel oyuncu = new OyuncuViewModel();
                oyuncu.OyuncuNo = i;
                int rastgeleIndeks = rnd.Next(0, ligTurleri.Count);
                oyuncu.Lig = ligTurleri[rastgeleIndeks];

                if (oyuncu.Lig == ligTurleri[0])
                {
                    oyuncu.Ortalama = rnd.Next(180, 191);
                }
                else if (oyuncu.Lig == ligTurleri[1])
                {
                    oyuncu.Ortalama = rnd.Next(191, 220);
                }
                else if (oyuncu.Lig == ligTurleri[2])
                {
                    oyuncu.Ortalama = rnd.Next(220, 241);
                }

                oyuncular.Add(oyuncu);
            }
            return View(oyuncular);
        }
    }
}

