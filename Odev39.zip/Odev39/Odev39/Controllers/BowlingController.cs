﻿using Microsoft.AspNetCore.Mvc;
using Odev39.Models;

namespace Odev39.Controllers
{
    public class BowlingController : Controller
    {
        Random rnd = new Random();
        public IActionResult Oyuncular()
        {
            List<Oyuncu> oyuncular = OyuncuOLustur();
            return View(oyuncular);
        }

        private List<Oyuncu> OyuncuOLustur()
        {
            List<Oyuncu> oyuncular = new List<Oyuncu>();
            for (int i = 1; i <= 15; i++)
            {
                Oyuncu oyuncu = new Oyuncu();
                oyuncu.Id = i;
                oyuncu.LigAdi = RastgeleLigSec();
                oyuncu.LigOrtalamasi = RastgeleOrtalama(oyuncu.LigAdi);
                oyuncular.Add(oyuncu);
            }
            return oyuncular;
        }
        private string RastgeleLigSec()
        {
            int ligNo = rnd.Next(3);

            switch (ligNo)
            {
                case 0:
                    return "Amatör lig";
                case 1:
                    return "Yarı Profesyonel lig";
                case 2:
                    return "Profesyonel lig";
                default:
                    return "";
            }

        }
        private int RastgeleOrtalama(string ligAdi)
        {
            switch (ligAdi)
            {
                case "Amatör lig":
                    return rnd.Next(180, 191);
                case "Yarı Profesyonel lig":
                    return rnd.Next(191, 220);
                case "Profesyonel lig":
                    return rnd.Next(220, 241);
                default:
                    return 0;
            }
        }
    }
}
