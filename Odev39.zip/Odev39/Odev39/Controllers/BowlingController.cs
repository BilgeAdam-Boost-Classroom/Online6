﻿using Microsoft.AspNetCore.Mvc;
using Odev39.Models;

namespace Odev39.Controllers
{
    public class BowlingController : Controller
    {
        public IActionResult Oyuncular()
        {
            List<OyuncuViewModel> oyuncular = new List<OyuncuViewModel>
            {
                new OyuncuViewModel { Ad = "Ethan Anderson" },
                new OyuncuViewModel { Ad = "Olivia Baker" },
                new OyuncuViewModel { Ad = "Liam Carter" },
                new OyuncuViewModel { Ad = "Ava Davis" },
                new OyuncuViewModel { Ad = "Noah Edwards" },
                new OyuncuViewModel { Ad = "Emma Foster" },
                new OyuncuViewModel { Ad = "Aiden Garcia" },
                new OyuncuViewModel { Ad = "Mia Hall" },
                new OyuncuViewModel { Ad = "Lucas Johnson" },
                new OyuncuViewModel { Ad = "Sophia King" },
                new OyuncuViewModel { Ad = "Jackson Lee" },
                new OyuncuViewModel { Ad = "Harper Martinez" },
                new OyuncuViewModel { Ad = "Caleb Nelson" },
                new OyuncuViewModel { Ad = "Abigail Owens" },
                new OyuncuViewModel { Ad = "Logan Parker" }
            };
            return View(oyuncular);
        }
    }
}
