﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Odev39.Models;

namespace Odev39.Controllers
{
    public class BowlingController : Controller
    {
        public IActionResult Oyuncular()
        {
            List<BowlingOyuncusu> oyuncular = OyuncuListesiOlustur(15);

            return View(oyuncular);
        }

        private List<BowlingOyuncusu> OyuncuListesiOlustur(int oyuncuSayisi)
        {
            List<BowlingOyuncusu> oyuncular = new List<BowlingOyuncusu>();
            Random random = new Random();

            for (int i = 1; i <= oyuncuSayisi; i++)
            {
                BowlingOyuncusu oyuncu = new BowlingOyuncusu();
                oyuncu.Ad = "Oyuncu " + i;

                // Lig seçimi
                int ligSecimi = random.Next(3);
                switch (ligSecimi)
                {
                    case 0:
                        oyuncu.Lig = "Amatör";
                        oyuncu.Ortalama = random.Next(180, 191); // 180-190 aralığı (limitler dahil)
                        break;
                    case 1:
                        oyuncu.Lig = "Yarı Profesyonel";
                        oyuncu.Ortalama = random.Next(191, 220); // 191-219 aralığı (limitler dahil)
                        break;
                    case 2:
                        oyuncu.Lig = "Profesyonel";
                        oyuncu.Ortalama = random.Next(220, 241); // 220-240 aralığı (limitler dahil)
                        break;
                }

                oyuncular.Add(oyuncu);
            }

            return oyuncular;
        }
    }
}
