﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru2
{
    internal class Pawn : Ipiece
    {
        public string Name { get; set; }
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("Two forward at the beginning or one forward.");
        }
        public void Promote()
        {
            Console.WriteLine("can promote to rook,Knight,bishop or green.");
        }
    }
}
