﻿namespace soru2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            List<Ipiece> list = new List<Ipiece>();

            Pawn pawn = new Pawn();
            pawn.Name = "piyon";
            list.Add(pawn);

            Rook rook = new Rook();
            rook.Name = "kale";
            list.Add(rook);

            Knight knight = new Knight();
            knight.Name = "At";
            list.Add(knight);

            Bishop bishop = new Bishop();
            bishop.Name = "Fil";
            list.Add(bishop);

            Queen queen = new Queen();
            queen.Name = "vezir";
            list.Add(queen);

            King king = new King();
            king.Name = "Şah";
            list.Add(king);

            List<PieceColor> renk = new List<PieceColor>();
            List<Ipiece> secilentaslar = new List<Ipiece>();
            string giris;

            while (true)
            {
                int randomIndex = rnd.Next(0, list.Count);
                Console.WriteLine("satranç taşı listeye eklendi. Çıkmak için H/h basınız. Devam etmek için herhangi bir tuşa basınız.");
                
                giris = Console.ReadLine();

                if (giris.ToLower() != "h")
                {
                    

                    int randomEnum = rnd.Next(0, 2);
                    list[randomIndex].Color = randomEnum == 1 ? PieceColor.white : PieceColor.black;
                    secilentaslar.Add(list[randomIndex]);


                }

                else if (giris.ToLower() == "h")
                {
                    

                    foreach (Ipiece tas in secilentaslar)
                    {
                        Console.WriteLine(tas.Name);
                        Console.WriteLine(tas.Color);
                        tas.Move();


                        Console.WriteLine("- - - - - - - - - - - - -");
                        Console.WriteLine("- - - - - - - - - - - - -");

                    }

                    Console.ReadKey();
                    break;

                }
            }

        }
    }
}