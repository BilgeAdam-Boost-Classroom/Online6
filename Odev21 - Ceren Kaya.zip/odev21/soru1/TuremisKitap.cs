﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru1
{
    internal class TuremisKitap : Kitap
    {
        public override void GetUser()
        {
            Console.WriteLine("ffkkf");
        }
        public override void GetLog()
        {
            base.GetLog();
            
        }


    }
}
