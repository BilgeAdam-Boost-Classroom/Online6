﻿


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru1
{
    internal class Kitap : BaseKitap
    {
        public override sealed void GetLog()
        {
            Console.WriteLine("kitap get user..");
        }
        public override void GetUser()
        {
            Console.WriteLine("kitap get user");
        }
    }
}
