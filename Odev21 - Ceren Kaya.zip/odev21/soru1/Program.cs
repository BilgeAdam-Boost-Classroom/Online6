﻿
namespace soru1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TuremisKitap turemis = new TuremisKitap();
            turemis.GetLog();
            turemis.GetUser();
            Console.ReadKey();
        }
    }
}