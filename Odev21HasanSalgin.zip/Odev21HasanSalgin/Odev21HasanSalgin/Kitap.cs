﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21HasanSalgin
{
    internal class Kitap:BaseKitap
    {
        public override void GetLog()
        {
            Console.WriteLine("kitap get log...");
        }
        public override sealed void GetUser()
        {
            Console.WriteLine("kitap get user...");

        }
    }
}
