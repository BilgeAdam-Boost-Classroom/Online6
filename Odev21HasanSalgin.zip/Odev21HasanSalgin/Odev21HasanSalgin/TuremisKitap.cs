﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21HasanSalgin
{
    internal class TuremisKitap:Kitap
    {
        public override void GetLog()
        {
            base.GetLog();
        }

        //public override void GetUser()  // kitap sınıfında sealed tanımladığımız GetUser() metodunu burada override edemiyoruz !!!
        //{

        //}


    }
}
