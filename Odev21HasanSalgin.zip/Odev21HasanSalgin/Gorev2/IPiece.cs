﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gorev2
{
    
    public interface IPiece
    {
        public string Name { get; set; }
        public PieceColor Color { get; set; }

        public void Move();
    }

    public class Pawn : IPiece   
    {
        public string Name { get; set; } 
        public PieceColor Color { get ; set ; }

        public void Move()
        {
            Console.WriteLine("two forward at the beginning or one forward");
        }
        public void Promote()
        {
            Console.WriteLine("can promote to rook,knight,bishop or queen");
        }
        public override string ToString()
        {
            return $"{Name} \n{Color}";
        }
    }
    public class Rook : IPiece  
    {
        public string Name { get; set; } 
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("ranks and files only");
        }
        public override string ToString()
        {
            return $"{Name} \n{Color}";
        }
    }
    public class Knight : IPiece
    {
        public string Name { get; set; } 
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("L shaped only");
        }
        public override string ToString()
        {
            return $"{Name} \n{Color}";
        }
    }
    public class Bishop : IPiece  
    {
        public string Name { get; set; } 
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("diagonals only");
        }
        public override string ToString()
        {
            return $"{Name} \n{Color}";
        }
    }
    public class Queen : IPiece
    {
        public string Name { get; set; } 
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("rook + bishop");
        }
        public override string ToString()
        {
            return $"{Name} \n{Color}";
        }
    }
    public class King : IPiece
    {
        public string Name { get; set; }
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("rook + bishop + one");
        }
        public override string ToString()
        {
            return $"{Name} \n{Color}";
        }
    }
    public enum PieceColor
    {
        Black,white
    }

   
}
