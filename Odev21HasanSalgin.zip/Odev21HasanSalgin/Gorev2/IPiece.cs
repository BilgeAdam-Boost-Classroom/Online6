﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gorev2
{
    
    public interface IPiece
    {
        public string Name { get; set; }
        public PieceColor Color { get; set; }

        public void Move();
    }

    public class Pawn : IPiece   //pawn:piyon
    {
        public string Name { get; set; } = "piyon";
        public PieceColor Color { get ; set ; }

        public void Move()
        {
            Console.WriteLine("two forward at the beginning or one forward");
        }
        public void Promote()
        {
            Console.WriteLine("can promote to rook,knight,bishop or queen");
        }

    }
    public class Rook : IPiece  //rook:kale
    {
        public string Name { get; set; } = "kale";
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("ranks and files only");
        }
    }
    public class Knight : IPiece
    {
        public string Name { get; set; } = "at";
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("L shaped only");
        }
    }
    public class Bishop : IPiece  
    {
        public string Name { get; set; } = "fil";
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("diagonals only");
        }
    }
    public class Queen : IPiece
    {
        public string Name { get; set; } = "vezir";
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("rook + bishop");
        }
    }
    public class King : IPiece
    {
        public string Name { get; set; } = "şah";
        public PieceColor Color { get; set; }

        public void Move()
        {
            Console.WriteLine("rook + bishop + one");
        }
    }
    public enum PieceColor
    {
        Black,white
    }

    public enum TasKodu
    {
        Piyon,Kale,At,Fil,Vezir,Sah
    }
}
