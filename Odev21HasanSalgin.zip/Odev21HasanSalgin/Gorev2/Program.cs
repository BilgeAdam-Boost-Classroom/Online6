﻿
using Gorev2;
Random rnd = new Random();
List<IPiece> taslarim = new();  // IPiece tipinde taş listesi

int Piyon = 0, Kale = 0, At = 0, Fil = 0, Vezir = 0, Sah = 0;  //en çok tekrar eden taşı bulmak

while (true)
{
    Console.WriteLine("satranç taşı listeye eklendi, çıkmak için H/h basınız,devam etmek için herhangi bir tuşa basınız:");
    char devamMi = Convert.ToChar(Console.ReadLine());

    int rastgeleTas = rnd.Next(7);

    IPiece tas = null;

    switch (rastgeleTas)
    {
        case 0:
            tas = new Pawn();
            tas.Name = "piyon";
            tas.Color = (PieceColor)rnd.Next(2);
            Piyon++;
            break;
        case 1:
            tas = new Rook();
            tas.Name = "kale";
            tas.Color = (PieceColor)rnd.Next(2);
            Kale++;
            break;
        case 2:
            tas = new Knight();
            tas.Name = "at";
            tas.Color = (PieceColor)rnd.Next(2);
            At++;
            break;
        case 3:
            tas = new Bishop();
            tas.Name = "fil";
            tas.Color = (PieceColor)rnd.Next(2);
            Fil++;
            break;
        case 4:
            tas = new Queen();
            tas.Name = "vezir";
            tas.Color = (PieceColor)rnd.Next(2);
            Vezir++;
            break;
        case 5:
            tas = new King();
            tas.Name = "şah";
            tas.Color = (PieceColor)rnd.Next(2);
            Sah++;
            break;
    }

    taslarim.Add(tas);

    if (devamMi == 'H' || devamMi == 'h')
    {
        Console.WriteLine("oyun sonlandırılıyor...");
        break;
    }
}

foreach (IPiece item in taslarim)
{
    Console.WriteLine("***********************");
    if (item != null)
    {
        Console.WriteLine(item);
        item.Move();
        if (item.GetType() == typeof(Pawn))
            ((Pawn)item).Promote();
    }
}

int[] tekrarSayilari = { Piyon, Kale, At, Fil, Vezir, Sah };
int enCokTekrarEden = tekrarSayilari.Max();

if (enCokTekrarEden == Piyon)
    Console.WriteLine("En çok tekrar eden taş: piyon");
else if (enCokTekrarEden == Kale)
    Console.WriteLine("En çok tekrar eden taş: kale");
else if (enCokTekrarEden == At)
    Console.WriteLine("En çok tekrar eden taş: at");
else if (enCokTekrarEden == Fil)
    Console.WriteLine("En çok tekrar eden taş: fil");
else if (enCokTekrarEden == Vezir)
    Console.WriteLine("En çok tekrar eden taş: vezir");
else if (enCokTekrarEden == Sah)
    Console.WriteLine("En çok tekrar eden taş: Şah");
















Console.ReadKey();
