﻿
using Gorev2;
Random rnd1 = new Random();
Random rnd2 = new Random();

Pawn p1 = new Pawn();
Rook r1 = new Rook();
Knight knight1 = new Knight();
Bishop b1 = new Bishop();
Queen q1 = new Queen();
King kral1 = new King();

//List<IPiece> taslarim = new List<IPiece>();

//taslarim.Add(p1);
//taslarim.Add(r1);
//taslarim.Add(knight1);
//taslarim.Add(b1);
//taslarim.Add(q1);
//taslarim.Add(kral1);

// eksikler: çıktı da taşların en son gözükmesi gerekiyor.

char devamMi;
PieceColor renk = new PieceColor();
int Piyon = 0, Kale = 0, At = 0, Fil = 0, Vezir = 0, Sah = 0;

do
{
    Console.WriteLine("satranç taşı listeye eklendi, çıkmak için H/h basınız,devam etmek için herhangi bir tuşa basınız:");
    devamMi = Convert.ToChar(Console.ReadLine());

    int sayi1 = rnd1.Next(6);
    int sayi2 = rnd2.Next(2);
    if (sayi1 == 0)
    {
        Piyon++;
        if (sayi2 == 0)
        {
            Console.WriteLine("piyon");
            p1.Color = PieceColor.Black;
            Console.WriteLine(p1.Color);
            p1.Move();
            p1.Promote();
        }
        else if (sayi2 == 1)
        {
            Console.WriteLine("piyon");
            p1.Color = PieceColor.white;
            Console.WriteLine(p1.Color);
            p1.Move();
            p1.Promote();
        }

    }
    else if (sayi1 == 1)
    {
        Kale++;
        if (sayi2 == 0)
        {
            Console.WriteLine("kale");
            r1.Color = PieceColor.Black;
            Console.WriteLine(r1.Color);
            r1.Move();
        }
        else if (sayi2 == 1)
        {
            Console.WriteLine("kale");
            r1.Color = PieceColor.white;
            Console.WriteLine(r1.Color);
            r1.Move();
        }
    }
    else if (sayi1 == 2)
    {
        At++;
        if (sayi2 == 0)
        {
            Console.WriteLine("at");
            knight1.Color = PieceColor.Black;
            Console.WriteLine(knight1.Color);
            knight1.Move();
        }
        else if (sayi2 == 1)
        {
            Console.WriteLine("at");
            knight1.Color = PieceColor.white;
            Console.WriteLine(knight1.Color);
            knight1.Move();
        }
    }
    else if (sayi1 == 3)
    {
        Fil++;
        if (sayi2 == 0)
        {
            Console.WriteLine("fil");
            b1.Color = PieceColor.Black;
            Console.WriteLine(b1.Color);
            b1.Move();
        }
        else if (sayi2 == 1)
        {
            Console.WriteLine("fil");
            b1.Color = PieceColor.white;
            Console.WriteLine(b1.Color);
            b1.Move();
        }
    }
    else if (sayi1 == 4)
    {
        Vezir++;
        if (sayi2 == 0)
        {
            Console.WriteLine("vezir");
            q1.Color = PieceColor.Black;
            Console.WriteLine(q1.Color);
            q1.Move();
        }
        else if (sayi2 == 1)
        {
            Console.WriteLine("vezir");
            q1.Color = PieceColor.white;
            Console.WriteLine(q1.Color);
            q1.Move();
        }
    }
    else if (sayi1 == 5)
    {
        Sah++;
        if (sayi2 == 0)
        {
            Console.WriteLine("şah");
            kral1.Color = PieceColor.Black;
            Console.WriteLine(kral1.Color);
            kral1.Move();
        }
        else if (sayi2 == 1)
        {
            Console.WriteLine("şah");
            kral1.Color = PieceColor.white;
            Console.WriteLine(kral1.Color);
            kral1.Move();
        }
    }

} while (devamMi != 'H' && devamMi != 'h');

int[] tekrarSayilari = { Piyon, Kale, At, Fil, Vezir, Sah };
int enCokTekrarEden = tekrarSayilari.Max();

if (enCokTekrarEden == Piyon)
    Console.WriteLine("En çok tekrar eden taş: piyon");
else if (enCokTekrarEden == Kale)
    Console.WriteLine("En çok tekrar eden taş: kale");
else if (enCokTekrarEden == At)
    Console.WriteLine("En çok tekrar eden taş: at");
else if (enCokTekrarEden == Fil)
    Console.WriteLine("En çok tekrar eden taş: fil");
else if (enCokTekrarEden == Vezir)
    Console.WriteLine("En çok tekrar eden taş: vezir");
else if (enCokTekrarEden == Sah)
    Console.WriteLine("En çok tekrar eden taş: Şah");



















Console.ReadKey();
