let on=false;
let p=document.getElementById("btnP");
let o=document.getElementById("btnO");
let n=document.getElementById("btnN");
let l=document.getElementById("btnL");
let n0=document.getElementById("btn0");
let n6=document.getElementById("btn6");

let txt=document.getElementById("top");

o.onclick=()=>onl06("red","O","white");
n.onclick=()=>onl06("white","N","red");
l.onclick=()=>onl06("blue","L","white");
n0.onclick=()=>onl06("white","0","blue");
n6.onclick=()=>onl06("grey","6","white");

p.onclick=()=>{
    on=!on;
    if(on){
        txt.textContent="AÇILDI";
        txt.style="background-color:white;"
    }
    else{
        txt.textContent="KAPANDI";
        txt.style="background-color:black;"
    }
};

function onl06(colorB,text,colorF){
    if(on){
        txt.textContent=text;
        txt.style="background-color:"+colorB+";"+"color:"+colorF+";";
    }
    else{
        txt.textContent="ÖNCE AÇINIZ!";
    }
};