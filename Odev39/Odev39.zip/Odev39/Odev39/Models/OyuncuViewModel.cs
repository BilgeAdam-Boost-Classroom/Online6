﻿namespace Odev39.Models
{
    public class Oyuncu
    {
        public int Ortalama { get; set; }
    }
}
