using Microsoft.AspNetCore.Mvc;
using Odev39.Models;
using System.Diagnostics;

namespace Odev39.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<Oyuncu> oyuncular = new List<Oyuncu>();
            Random rnd = new Random();

            for (int i = 0; i < 15; i++)
            {
                Oyuncu oyuncu = new Oyuncu
                {
                    Ortalama = rnd.Next(180,241)
                };
                oyuncular.Add(oyuncu);
            }

            return View(oyuncular);
        }




        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
