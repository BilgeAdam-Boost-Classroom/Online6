﻿namespace soru1
{
    internal class Araba : MotorluTasit
    {
        public override void Git()
        {
            Console.WriteLine("Araba gidiyor. ");
        }
    }
}
