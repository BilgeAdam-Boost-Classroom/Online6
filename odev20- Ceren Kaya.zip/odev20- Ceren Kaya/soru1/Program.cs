﻿namespace soru1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            Araba araba1 = new Araba();
            araba1.Git();
            MotorluTasit motorlu1 = new MotorluTasit();
            motorlu1.Git();

            MotorluTasit motorlu2 = new Araba();
            motorlu2.Git();


            Console.ReadKey();
        }
    }
}