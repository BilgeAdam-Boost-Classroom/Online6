using System;
using System.Windows.Forms;

namespace odev20__Ceren_Kaya
{
    public partial class Form1 : Form
    {

              List<Araba> arabalar = new List<Araba>()
            {
                new Araba() { Marka = "A", Model = "A1", Renk = "Siyah", UretimYili = "2010" },
                new Araba() { Marka = "B", Model = "B1", Renk = "Siyah", UretimYili = "2020" },
                new Araba() { Marka = "C", Model = "C1", Renk = "Mavi", UretimYili = "2016" },
                new Araba() { Marka = "D", Model = "D1", Renk = "Metalik Gri", UretimYili = "2018" }
             };


        public Form1()
        {
            InitializeComponent();
            
            foreach (var item in arabalar)
            {

                listBox1.Items.Add(item);
                
            }
            

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (listBox1.SelectedItem != null)
            {

                Araba selectedAraba = (Araba)listBox1.SelectedItem;

                lblBilgi.Text = selectedAraba.OzellikleriYaz();
            }
            else
            {
                lblBilgi.Text = "Bilgi yok";
            }




        }
    }
}
