﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev20__Ceren_Kaya
{
    public class Araba
    {
        public Araba()
        {

        }
        public string Marka { get; set; }
        public string Model { get; set; }

        public string Renk { get; set; }

        public string UretimYili { get; set; }

        public string OzellikleriYaz()
        {
            return "Marka : " +Marka + Environment.NewLine + "Model : " + Model + Environment.NewLine + "Renk : " +Renk + Environment.NewLine + "Üretim Yılı : " + UretimYili;
        }
        public override string ToString()
        {
            return Marka + " - " + Model;
        }

    }

}

