﻿namespace Odev39.Models
{
    public enum Lig
    {
        Amatorlig,
        Yariprofesyonellig,
        Profesyonellig

    }
  
}
