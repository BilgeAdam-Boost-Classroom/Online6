﻿
namespace Odev39.Models
{
    public class Oyuncu
    {
        private int _Puan { get; set; }

        public Oyuncu(int id)
        {
            Id = id;
            
            _Puan = RandomSayi();
            Lig = LigBelirle();
            Puan = _Puan;
        }

        private Lig LigBelirle()
        {
            if (_Puan < 191)
            {
                return Lig.Amatorlig;
            }
            else if( _Puan < 220)
            {
                return Lig.Yariprofesyonellig;
            }
            else
                return Lig.Profesyonellig;
        }

        public int Puan { get; set; }
        public int Id { get; set; }
        public Lig Lig { get; set; }
       

        public int RandomSayi()
        {
            Random rnd = new Random();
           
            return rnd.Next(180,241);
        }
     
    }
    
}
