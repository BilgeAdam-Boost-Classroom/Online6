using Microsoft.AspNetCore.Mvc;
using Odev39.Models;
using System.Diagnostics;

namespace Odev39.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<Oyuncu> Oyuncular = new List<Oyuncu>();
            for (int i = 1; i < 16; i++)
            {
                 Oyuncu oyuncu = new Oyuncu(i);
                
                Oyuncular.Add(oyuncu);
            }         
            return View(Oyuncular);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
