﻿using System;
using System.Collections.Generic;

namespace Odev33.Models;

public partial class EnPahaliCondiment
{
    public int ProductId { get; set; }

    public string ÜrünAdı { get; set; } = null!;

    public string TedarikçiAdı { get; set; } = null!;
}
