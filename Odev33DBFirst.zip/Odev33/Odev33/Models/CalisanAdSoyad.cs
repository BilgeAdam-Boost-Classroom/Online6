﻿using System;
using System.Collections.Generic;

namespace Odev33.Models;

public partial class CalisanAdSoyad
{
    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public DateTime? BirthDate { get; set; }
}
