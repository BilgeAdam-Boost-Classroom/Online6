﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.SqlServer.Server;
using Odev33.Models;

NorthwndContext db;
db = new NorthwndContext();


// Tüm Employeeleri listeleyiniz
var employees = db.Employees.ToList();


// İlk Employee yi yazdırınız
var firstEmployee = db.Employees.FirstOrDefault();
Console.WriteLine($"First Employee: {firstEmployee?.FirstName} {firstEmployee?.LastName}");

// Employeeleri FirstName e göre sıralayıp son Employee yi yazdırınız
var lastEmployeeOrderedByFirstName = db.Employees.OrderBy(e => e.FirstName).LastOrDefault();
Console.WriteLine($"Last Employee Ordered by FirstName: {lastEmployeeOrderedByFirstName?.FirstName} {lastEmployeeOrderedByFirstName?.LastName}");

// İsmi A ile başlayan Employeeleri listeleyiniz
var employeesWithA = db.Employees.Where(e => e.FirstName.StartsWith("A")).ToList();

// İsmi A ile başlayan ilk Employee yi yazdırınız
var firstEmployeeWithA = db.Employees.FirstOrDefault(e => e.FirstName.StartsWith("A"));
Console.WriteLine($"First Employee with Name starting with A: {firstEmployeeWithA?.FirstName} {firstEmployeeWithA?.LastName}");


// İsmi içerisinde 'a' harfi geçen Employeeleri listeleyiniz
var employeesWithNameContainingA = db.Employees.Where(e => e.FirstName.Contains("a") || e.LastName.Contains("a")).ToList();

// İsmi içerisinde 'a' harfi geçen ilk Employee yi yazdırınız
var firstEmployeeWithNameContainingA = db.Employees.FirstOrDefault(e => e.FirstName.Contains("a") || e.LastName.Contains("a"));
Console.WriteLine($"First Employee with Name containing 'a': {firstEmployeeWithNameContainingA?.FirstName} {firstEmployeeWithNameContainingA?.LastName}");

// Adı 'Andrew' olan employeeleri yazdırınız
var andrewEmployees = db.Employees.Where(e => e.FirstName == "Andrew").ToList();

// En pahalı productı yazdırınız
var mostExpensiveProduct = db.Products.OrderByDescending(p => p.UnitPrice).FirstOrDefault();
Console.WriteLine($"Most Expensive Product: {mostExpensiveProduct?.ProductName} - Price: {mostExpensiveProduct?.UnitPrice}");

// En ucuz productı yazdırınız
var cheapestProduct = db.Products.OrderBy(p => p.UnitPrice).FirstOrDefault();
Console.WriteLine($"Cheapest Product: {cheapestProduct?.ProductName} - Price: {cheapestProduct?.UnitPrice}");

// Fiyatı ortalama fiyat üzerinde olan ürünleri yazdırınız
var averagePrice = db.Products.Average(p => p.UnitPrice);
var aboveAveragePricedProducts = db.Products.Where(p => p.UnitPrice > averagePrice).ToList();

// Product ları Stock sayısına göre sıralayınız
var productsOrderedByStock = db.Products.OrderBy(p => p.UnitsInStock).ToList();

// Product ları önce Stock sayısına göre sonra ProductName e göre büyükten küçüğe sıralayın
var productsOrderedByStockAndName = db.Products.OrderByDescending(p => p.UnitsInStock).ThenByDescending(p => p.ProductName).ToList();

// Order detaillarda, order bazında toplam satış tutarı 500 ve altında olan orderid'leri getirip, toplam tutara göre sıralayınız
var ordersWithTotalSalesUnder500 = db.OrderDetails.GroupBy(od => od.OrderId)
    .Where(g => g.Sum(od => od.UnitPrice * od.Quantity) <= 500)
    .OrderBy(g => g.Sum(od => od.UnitPrice * od.Quantity))
    .Select(g => g.Key)
    .ToList();

// Tüm product ları category leri ile birlikte listeleyiniz
var productsWithCategories = db.Products.Include(p => p.Category).ToList();

// ProductName, CategoryName, Supplier'ın CompanyName 'ini ile birlikte yazdırınız
var productsWithDetails = db.Products
    .Select(p => new
    {
        ProductName = p.ProductName,
        CategoryName = p.Category.CategoryName,
        SupplierCompanyName = p.Supplier.CompanyName
    })
    .ToList();


Console.ReadKey();