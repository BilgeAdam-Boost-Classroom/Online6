/* AL�CAN D�KMEN
1) Employees tablosunda ad�n�n ilk harfi alfabetik
olarak A ile I aral���nda olmayanlar�n b�t�n
bilgilerini getiren sorguyu yaz�n�z.
*/

select * from Employees
where FirstName like '[^A-I]%'
order by FirstName

/*
2) Employees tablosunda ad�n�n ikinci harfi
A ve T olmayanlar�n b�t�n bilgilerini getiren
sorguyu yaz�n�z.
*/

select * from Employees
where FirstName not like '_A%' 
AND FirstName not like '_T%'

/*
3) Employees tablosunda ad�n�n ilk iki harfi
LA, LN, AA veya AN olanlar�n b�t�n bilgilerini
getiren sorguyu yaz�n�z.
*/

select * from Employees
where FirstName like 'LA%'
or FirstName like 'LN%'
or FirstName like 'AA%'
or FirstName like 'AN%'

/*
4) Employees tablosunda ad�n�n i�inde _ (Alt �izgi)
ge�enlerin sadece adlar�n� getiren sorguyu
yaz�n�z.
*/

select FirstName from Employees
where FirstName like '%[\_]%' 

/*
5) Customers tablosundan, CustomerID'sinin 2.harfi A
ve 4. harfi T olanlar�n CustomerID'ye g�re AZALAN halinin
ilk 10%'luk k�sm�n� getiren sorguyu yaz�n�z. (kolon olarak CustomerID)
*/

select top 10 Percent CustomerID from Customers
where CustomerID like '_A_T%'
order by CustomerID desc

/*
6) Employees tablosundan ad, soyad, ve do�um tarihinin saati
(Saat ad�yla) bilgilerini saate g�re azalan s�ralay�p getiren sorgu
*/

select FirstName, LastName, datename(hour, BirthDate) 'Saat' 
from Employees
order by Saat desc

/*
7) Employees tablosundan ad, soyad ve do�um tarihinin dakika
(dakika ad�yla) bilgilerini dakikaya g�re azalan olarak
s�ralay�p getiren sorguyu yaz�n�z.
*/

select FirstName, LastName, datename(minute, BirthDate) 'Dakika'
from Employees
order by Dakika desc

/*
8) Kendi do�um g�n�n�ze g�re ka� g�nd�r hayatta
oldu�unuzu hesaplayan sorguyu yaz�n�z.
*/

select datediff(day, '1989-07-30', getdate()) 
N'Ka� g�nd�r hayattay�m?'

/*
9) Orders tablosundan OrderDate'inin ay� temmuz olanlar�
VEYA ShippedDate'inin g�n� 15'ten b�y�k olanlar�n
SADECE OrderDate ve ShippedDate'lerini getiren sorgu
*/

select OrderDate, ShippedDate from Orders
where datepart(month, OrderDate) = 7
or datepart(day, ShippedDate) >= 15

/*
10) SatrancDB Ad�nda bir veritaban� olu�turunuz.
��erisine Taslar ad�nda bir tablo olu�turunuz.
�zellikleri:
ID -> int, pk
Ad -> nvarchar(50), not null
Hareket -> nvarchar(max), not null
Renk -> Bit, not null

Tabloya piyon, kale, at, fil, vezir ve �ah
isimlerinde veriler giriniz ve i�ini doldurunuz.
*/

create database SatrancDB
use SatrancDB

create table Taslar(
ID int primary key,
Ad nvarchar(50) not null,
Hareket nvarchar(max) not null,
Renk bit not null
)

insert into Taslar(ID, Ad, Hareket, Renk)
values (1, N'Piyon', N'D�z', 1);

insert into Taslar(ID, Ad, Hareket, Renk)
values (2, N'Kale', N'Sa�a', 0);

insert into Taslar(ID, Ad, Hareket, Renk)
values (3, N'At', N'L', 1);

insert into Taslar(ID, Ad, Hareket, Renk)
values (4, N'Fil', N'�apraz', 0);

insert into Taslar(ID, Ad, Hareket, Renk)
values (5, N'Vezir', N'D�z ve �apraz', 1);

insert into Taslar(ID, Ad, Hareket, Renk)
values (6, N'�ah', N'�leri', 1);

select * from Taslar