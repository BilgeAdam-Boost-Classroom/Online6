﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDersler
{
    public class HarfNotKatSayilari
    {
        public string HarfNotu { get; set; }
        public double Katsayi { get; set; }
    }
}
