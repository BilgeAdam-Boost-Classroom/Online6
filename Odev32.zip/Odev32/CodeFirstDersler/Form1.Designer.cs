﻿namespace CodeFirstDersler
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnEkle = new Button();
            btnGuncelle = new Button();
            btnKaldır = new Button();
            txtDersId = new TextBox();
            txtDersKodu = new TextBox();
            txtDersAdi = new TextBox();
            txtHarfNotu = new TextBox();
            txtKredi = new TextBox();
            dgvDersler = new DataGridView();
            btnOrtHesapla = new Button();
            btnIstatistik = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(87, 59);
            label1.Name = "label1";
            label1.Size = new Size(74, 23);
            label1.TabIndex = 0;
            label1.Text = "Ders ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(87, 121);
            label2.Name = "label2";
            label2.Size = new Size(84, 23);
            label2.TabIndex = 1;
            label2.Text = "Ders Adı:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(87, 182);
            label3.Name = "label3";
            label3.Size = new Size(98, 23);
            label3.TabIndex = 2;
            label3.Text = "Ders Kodu:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(87, 245);
            label4.Name = "label4";
            label4.Size = new Size(96, 23);
            label4.TabIndex = 3;
            label4.Text = "Harf Notu:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(87, 311);
            label5.Name = "label5";
            label5.Size = new Size(70, 23);
            label5.TabIndex = 4;
            label5.Text = "Kredisi:";
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(91, 408);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 5;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(223, 408);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(107, 29);
            btnGuncelle.TabIndex = 6;
            btnGuncelle.Text = "GÜNCELLE";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnKaldır
            // 
            btnKaldır.Location = new Point(153, 465);
            btnKaldır.Name = "btnKaldır";
            btnKaldır.Size = new Size(94, 29);
            btnKaldır.TabIndex = 7;
            btnKaldır.Text = "KALDIR";
            btnKaldır.UseVisualStyleBackColor = true;
            btnKaldır.Click += btnKaldır_Click;
            // 
            // txtDersId
            // 
            txtDersId.Location = new Point(205, 56);
            txtDersId.Name = "txtDersId";
            txtDersId.Size = new Size(125, 30);
            txtDersId.TabIndex = 8;
            // 
            // txtDersKodu
            // 
            txtDersKodu.Location = new Point(205, 184);
            txtDersKodu.Name = "txtDersKodu";
            txtDersKodu.Size = new Size(125, 30);
            txtDersKodu.TabIndex = 9;
            // 
            // txtDersAdi
            // 
            txtDersAdi.Location = new Point(205, 121);
            txtDersAdi.Name = "txtDersAdi";
            txtDersAdi.Size = new Size(125, 30);
            txtDersAdi.TabIndex = 10;
            // 
            // txtHarfNotu
            // 
            txtHarfNotu.Location = new Point(205, 238);
            txtHarfNotu.Name = "txtHarfNotu";
            txtHarfNotu.Size = new Size(125, 30);
            txtHarfNotu.TabIndex = 11;
            // 
            // txtKredi
            // 
            txtKredi.Location = new Point(205, 311);
            txtKredi.Name = "txtKredi";
            txtKredi.Size = new Size(125, 30);
            txtKredi.TabIndex = 12;
            // 
            // dgvDersler
            // 
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Location = new Point(428, 56);
            dgvDersler.Name = "dgvDersler";
            dgvDersler.RowHeadersWidth = 51;
            dgvDersler.Size = new Size(648, 438);
            dgvDersler.TabIndex = 13;
            // 
            // btnOrtHesapla
            // 
            btnOrtHesapla.Location = new Point(466, 537);
            btnOrtHesapla.Name = "btnOrtHesapla";
            btnOrtHesapla.Size = new Size(208, 50);
            btnOrtHesapla.TabIndex = 14;
            btnOrtHesapla.Text = "ORTALAMA HESAPLA";
            btnOrtHesapla.UseVisualStyleBackColor = true;
            // 
            // btnIstatistik
            // 
            btnIstatistik.Location = new Point(842, 537);
            btnIstatistik.Name = "btnIstatistik";
            btnIstatistik.Size = new Size(208, 50);
            btnIstatistik.TabIndex = 15;
            btnIstatistik.Text = "İSTATİSTİKLERİ GÖSTER";
            btnIstatistik.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1189, 630);
            Controls.Add(btnIstatistik);
            Controls.Add(btnOrtHesapla);
            Controls.Add(dgvDersler);
            Controls.Add(txtKredi);
            Controls.Add(txtHarfNotu);
            Controls.Add(txtDersAdi);
            Controls.Add(txtDersKodu);
            Controls.Add(txtDersId);
            Controls.Add(btnKaldır);
            Controls.Add(btnGuncelle);
            Controls.Add(btnEkle);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnEkle;
        private Button btnGuncelle;
        private Button btnKaldır;
        private TextBox txtDersId;
        private TextBox txtDersKodu;
        private TextBox txtDersAdi;
        private TextBox txtHarfNotu;
        private TextBox txtKredi;
        private DataGridView dgvDersler;
        private Button btnOrtHesapla;
        private Button btnIstatistik;
    }
}
