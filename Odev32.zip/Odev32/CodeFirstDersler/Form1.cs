using Microsoft.EntityFrameworkCore;

namespace CodeFirstDersler
{
    public partial class Form1 : Form
    {
        private DersDbContext db = new DersDbContext();

        private List<HarfNotKatSayilari> harfNotuKatsayilari = new List<HarfNotKatSayilari>
        {
            new HarfNotKatSayilari { HarfNotu = "A", Katsayi = 4.0 },
            new HarfNotKatSayilari { HarfNotu = "B", Katsayi = 3.5 },
            new HarfNotKatSayilari { HarfNotu = "C", Katsayi = 2.0 },
            new HarfNotKatSayilari { HarfNotu = "D", Katsayi = 1.0 },
            new HarfNotKatSayilari { HarfNotu = "F", Katsayi = 0.0 }
        };
        public Form1()
        {
            InitializeComponent();
            VerileriYukle();
        }

        private double HarfNotKatSayilari(string harfNotu)
        {
            // LINQ kullanarak harf notuna kar��l�k gelen katsay�y� al
            var katsayi = harfNotuKatsayilari.FirstOrDefault(item => item.HarfNotu == harfNotu);

            return katsayi?.Katsayi ?? 0.0;
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            var yeniDers = new Ders
            {
                Ad = txtDersAdi.Text,
                Kod = txtDersKodu.Text,
                HarfNotu = txtHarfNotu.Text,
                Kredi = Convert.ToInt32(txtKredi.Text)
            };

            db.Dersler.Add(yeniDers);
            db.SaveChanges();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            var seciliDersId = Convert.ToInt32(dgvDersler.SelectedRows[0].Cells["Id"].Value);
            var dersToUpdate = db.Dersler.FirstOrDefault(d => d.Id == seciliDersId);

            if (dersToUpdate != null)
            {
                dersToUpdate.Ad = txtDersAdi.Text;
                dersToUpdate.Kod = txtDersKodu.Text;
                dersToUpdate.HarfNotu = txtHarfNotu.Text;
                dersToUpdate.Kredi = Convert.ToInt32(txtKredi.Text);
                db.SaveChanges();

            }
        }

        private void btnKald�r_Click(object sender, EventArgs e)
        {
            var seciliDersId = Convert.ToInt32(dgvDersler.SelectedRows[0].Cells["Id"].Value);
            var dersKaldir = db.Dersler.FirstOrDefault(d => d.Id == seciliDersId);

            if (dersKaldir != null)
            {
                db.Dersler.Remove(dersKaldir);
                db.SaveChanges();
            }
        }


        private void VerileriYukle()
        {
            // Veritaban�ndan veriyi alarak DataGridView'i g�ncelle
            var dersler = db.Dersler.ToList();
            dgvDersler.DataSource = dersler;
            dgvDersler.Columns["Id"].Visible = false; // Id s�tununu gizle

            // Ortalama ve �statistikleri g�ster
            var ortalama = dersler.Sum(d => d.Kredi * HarfNotKatSayilari(d.HarfNotu)) / dersler.Sum(d => d.Kredi);
            dgvDersler.Text = $"Ortalama: {ortalama:N2}";

            var basariliDersSayisi = dersler.Count(d => HarfNotKatSayilari(d.HarfNotu) > 0);
            var basarisizDersSayisi = dersler.Count(d => HarfNotKatSayilari(d.HarfNotu) == 0);
            var sinamaliDersSayisi = dersler.Count(d => d.HarfNotu == "D");
            var toplamDersSayisi = dersler.Count;

            dgvDersler.Text = $"Toplam Ders: {toplamDersSayisi}, Ba�ar�l� Ders: {basariliDersSayisi}, " +
                                   $"Ba�ar�s�z Ders: {basarisizDersSayisi}, S�namal� Ders: {sinamaliDersSayisi}";
        }


        
    }
}
