﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev32
{
    public class UygulamaContextDb : DbContext
    {
        public DbSet<Ders> Dersler { get; set; }
        public DbSet<HarfNotu> HarfNotları { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.;Database=Odev32Db;Trusted_Connection=True;TrustServerCertificate=True;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<HarfNotu>().HasData
            (
               new HarfNotu { Id = 1, NotAdi = "A", Katsayi = 4 },
               new HarfNotu { Id = 2, NotAdi = "B", Katsayi = 3.5 },
               new HarfNotu { Id = 3, NotAdi = "C", Katsayi = 2 },
               new HarfNotu { Id = 4, NotAdi = "D", Katsayi = 1 },
               new HarfNotu { Id = 5, NotAdi = "F", Katsayi = 0 }
            );
        }
    }
}
