﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev32
{
    public class Ders
    {
        public int Id { get; set; }
        [MaxLength(150)]
        public string Ad { get; set; } = null!;
        public string Kod { get; set; } = null!;
        public HarfNotu HarfNotu { get; set; } = null!;
        public int HarfNotuId { get; set; }

        [Precision(18,2)]
        public double Kredi { get; set; }

        
    }
}
