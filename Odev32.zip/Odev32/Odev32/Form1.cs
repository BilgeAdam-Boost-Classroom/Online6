
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;

namespace Odev32
{
    public partial class Form1 : Form
    {
        UygulamaContextDb db = new UygulamaContextDb();
        public Form1()
        {
            InitializeComponent();
            cobHarfNotu.DisplayMember = "NotAdi";
            dgvDersler.AutoGenerateColumns = false;
            GuncelVerileriYukle();
        }

        private void Temizle()
        {
           txtDersAdi.Clear();
           txtDersId.Clear();  
           txtDersKodu.Clear();    
           cobHarfNotu.SelectedIndex = -1;  
           nudDersKredisi.Value = 0;    
        }

        private void GuncelVerileriYukle()
        {
            dgvDersler.DataSource = null;
            dgvDersler.DataSource = db.Dersler.ToList();
            cobHarfNotu.DataSource = db.HarfNotlar�.ToList();
            cobHarfNotu.SelectedIndex = -1;
        }

        private void GuncellecekDersBilgileriniAl()
        {
            if (dgvDersler.SelectedRows.Count > 0)
            {
                DataGridViewRow seciliSatir = dgvDersler.SelectedRows[0];
                Ders guncellenecekDers = (Ders)seciliSatir.DataBoundItem;
                txtDersAdi.Text = guncellenecekDers.Ad;
                txtDersId.Text = guncellenecekDers.Id.ToString();
                txtDersKodu.Text = guncellenecekDers.Kod.ToString();
                (nudDersKredisi.Value) = (int)guncellenecekDers.Kredi;
                cobHarfNotu.SelectedItem = guncellenecekDers.HarfNotu;
            }
        }


        private string DersIstatisti�iHesapla()
        {
            List<Ders> basariliDersler = new List<Ders>();
            basariliDersler.AddRange(db.Dersler.Where(x => x.HarfNotu.Katsayi > 1).ToList());

            List<Ders> sinanmaliDersler = new List<Ders>();
            sinanmaliDersler.AddRange(db.Dersler.Where(x => x.HarfNotu.Katsayi == 1).ToList());

            List<Ders> basarisizDersler = new List<Ders>();
            basarisizDersler.AddRange(db.Dersler.Where(x => x.HarfNotu.Katsayi == 0));

              return $"{basariliDersler.Count} tanesi \"Ba�ar�l�\" \n {basarisizDersler.Count} tanesi \"Ba�ar�s�z\" \n {sinanmaliDersler.Count} tanesi \"S�nanmal�d�r\"";
        }
        private double DersOrtalamaHesapla()
        {
            double genelOrtlama = 0;
            double dersOrtalama = 0;
            double toplamKredi = 0;
            foreach (var ders in db.Dersler)
            {
                toplamKredi += ders.Kredi;
                dersOrtalama += ders.HarfNotu.Katsayi * ders.Kredi;
            }
            genelOrtlama = dersOrtalama / toplamKredi;
            return genelOrtlama;
        }

        private void DersEkle()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtDersAdi.Text) || string.IsNullOrWhiteSpace(txtDersKodu.Text) || cobHarfNotu.SelectedItem == null)
                {
                    MessageBox.Show("L�tfen t�m gerekli alanlar� doldurunuz!", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Ders yeniDers = new Ders()
                {
                    Ad = txtDersAdi.Text.Trim(),
                    Kod = txtDersKodu.Text.Trim(),
                    HarfNotu = (HarfNotu)(cobHarfNotu.SelectedItem),
                    Kredi = (int)(nudDersKredisi.Value)
                };
                db.Dersler.Add(yeniDers);
                db.SaveChanges();
                GuncelVerileriYukle();
                Temizle();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ders eklenirken bir hata olu�tu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DersGuncelle()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtDersAdi.Text) || string.IsNullOrWhiteSpace(txtDersKodu.Text) || cobHarfNotu.SelectedItem == null)
                {
                    MessageBox.Show("L�tfen t�m gerekli alanlar� doldurunuz!", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (dgvDersler.SelectedRows.Count > 0)
                {
                    DataGridViewRow seciliSatir = dgvDersler.SelectedRows[0];
                    Ders guncellenecekDers = (Ders)seciliSatir.DataBoundItem;

                    if (guncellenecekDers != null)
                    {
                        guncellenecekDers.Ad = txtDersAdi.Text.Trim();
                        guncellenecekDers.Kod = txtDersKodu.Text.Trim();
                        guncellenecekDers.HarfNotu = (HarfNotu)cobHarfNotu.SelectedItem;
                        guncellenecekDers.Kredi = (int)(nudDersKredisi.Value);
                        db.SaveChanges();
                        GuncelVerileriYukle();
                        Temizle();
                    }
                }
                else
                {
                    MessageBox.Show("G�ncellemek i�in herhangi bir ders se�imi yapmad�n�z!", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ders g�ncellenirken bir hata olu�tu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DersKald�r()
        {
            try
            {
                if (dgvDersler.SelectedRows.Count > 0)
                {
                    DataGridViewRow seciliSatir = dgvDersler.SelectedRows[0];
                    Ders silinecekDers = (Ders)(seciliSatir).DataBoundItem;

                    if (silinecekDers != null)
                    {
                        silinecekDers = db.Dersler.FirstOrDefault(x => x.Id == silinecekDers.Id);
                        db.Dersler.Remove(silinecekDers);
                        db.SaveChanges();
                        GuncelVerileriYukle();
                        Temizle();
                    }
                }
                else
                {
                    MessageBox.Show("Silinmek i�in herhangi bir ders se�imi yapmad�n�z!", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ders silinirken bir hata olu�tu: {ex.Message}", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //EVENTLER
        private void btnEkle_Click(object sender, EventArgs e)
        {
            DersEkle();
            Temizle();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            DersGuncelle();
            Temizle();
        }

        private void btnKaldir_Click(object sender, EventArgs e)
        {
            DersKald�r();
            Temizle();
        }

        private void btnOrtalamaHesapla_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Genel Ortalama : {DersOrtalamaHesapla()} ", "Ortalama", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnIstatislikleriGoster_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"{db.Dersler.Count()} Dersten: \n {DersIstatisti�iHesapla()} ",
                "�statistik", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void dgvDersler_DoubleClick(object sender, EventArgs e)
        {
            GuncellecekDersBilgileriniAl();
        }
    }
}
















