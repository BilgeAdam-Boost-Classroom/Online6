
using System.CodeDom;

namespace Odev32
{
    public partial class Form1 : Form
    {
        UygulamaDbContext db;
        public Form1()
        {
            InitializeComponent();
            db = new UygulamaDbContext();
            VerileriYukle();
        }

        private void VerileriYukle()
        {
            dgvDersler.DataSource = db.Dersler.ToList();
        }
        private decimal HarfNotu(string harf)
        {
            harf = harf.ToUpper();

            if (harf == "A")
                return 4;
            else if (harf == "B")
                return 3.5m;
            else if (harf == "C")
                return 2;
            else if (harf == "D")
                return 1;
            else if (harf == "F")
                return 0;
            else
                throw new Exception("Harf notu hata");
        }

        private bool IdKontrolu(out Ders silinecek)
        {
            silinecek = null;

            string silTxt = txtDersId.Text.Trim();

            if (silTxt == "")
            {
                MessageBox.Show("Id b�l�m�n� doldurun");
                return false;
            }

            int sil;

            if (!int.TryParse(silTxt, out sil))
            {
                MessageBox.Show("Id b�l�m�ne tamsay� girin");
                return false;
            }

            silinecek = db.Dersler.FirstOrDefault(x => x.Id == sil);

            if (silinecek == null)
            {
                MessageBox.Show("Ge�erli bir Id girin");
                return false;
            }

            return true;
        }

        private bool VeriKontrolu(out string ad, out string kod, out string harf, out int kredi)
        {
            kredi = 0;
            ad = txtDersAd.Text.Trim();
            kod = txtDersKod.Text.Trim();
            harf = txtHarfNot.Text.Trim().ToUpper();
            string krediTxt = txtKredi.Text.Trim();

            if (new List<string>() { ad, kod, harf, krediTxt }.Contains(""))
            {
                MessageBox.Show("T�m alanlar� doldurun");
                return false;
            }

            if (harf.Length > 1)
            {
                MessageBox.Show("Harf notu hatal�");
                return false;
            }

            if (!new List<string> { "A", "B", "C", "D", "F" }.Contains(harf))
            {
                MessageBox.Show("Harf notu b�l�m�ne A , B , C , D , F  harflerinden birini girin");
                return false;
            }


            if (!int.TryParse(krediTxt, out kredi))
            {
                MessageBox.Show("Kredi b�l�m�ne tamsay� girin");
                return false;
            }

            return true;
        }

        private void btnOrtalamaHesapla_Click(object sender, EventArgs e)
        {
            decimal ort = 0;

            foreach (Ders x in db.Dersler)
                ort += HarfNotu(x.HarfNot) * x.Kredi;
            ort /= db.Dersler.Sum(x => x.Kredi);

            MessageBox.Show($"Genel Ortalaman�z: {ort:0.00}");
        }

        private void btnIstatistikleriGoster_Click(object sender, EventArgs e)
        {
            if (db.Dersler.ToList().Count == 0)
            {
                MessageBox.Show("Ders bulunamad�");
                return;
            }

            int basarili = 0, sinamali = 0, basarisiz = 0;

            foreach (Ders x in db.Dersler)
            {
                if (new List<string>() { "A", "B", "C" }.Contains(x.HarfNot))
                    basarili++;
                else if (x.HarfNot == "D")
                    sinamali++;
                else if (x.HarfNot == "F")
                    basarisiz++;
                else
                    throw new Exception("�statistik hatas�");
            }

            string ist = db.Dersler.Count() + " Dersten:";

            if (basarili > 0)
                ist += "\n" + basarili + " tanesi basar�l�";
            if (sinamali > 0)
                ist += "\n" + sinamali + " tanesi s�namal�";
            if (basarisiz > 0)
                ist += "\n" + basarisiz + " tanesi basaris�z";

            MessageBox.Show(ist);

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {

            if (!VeriKontrolu(out string ad, out string kod, out string harf, out int kredi))
                return;

            Ders yeni = new Ders()
            {
                Ad = ad,
                Kod = kod,
                HarfNot = harf,
                Kredi = kredi,
            };

            db.Add(yeni);
            db.SaveChanges();
            VerileriYukle();
        }


        private void btnKald�r_Click(object sender, EventArgs e)
        {
            if(!IdKontrolu(out Ders silinecek))
                return;

            db.Dersler.Remove(silinecek);
            db.SaveChanges();
            VerileriYukle();
        }


        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (!IdKontrolu(out Ders guncellenecek))
                return;
            if (!VeriKontrolu(out string ad, out string kod, out string harf, out int kredi))
                return;

            guncellenecek.Ad = ad;
            guncellenecek.Kod = kod;
            guncellenecek.HarfNot = harf;
            guncellenecek.Kredi = kredi;

            db.SaveChanges();
            VerileriYukle();
        }
    }
}
