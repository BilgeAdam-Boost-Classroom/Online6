
namespace Odev32
{
    public partial class Form1 : Form
    {
        UygulamaDbContext db = new UygulamaDbContext();
        public Form1()
        {
            InitializeComponent();
            VerileriYukle();
        }

        private void VerileriYukle()
        {
            dgvDersler.DataSource = db.Dersler.ToList();
            AlanlariTemizle();
        }

        private void AlanlariTemizle()
        {
            txtId.Clear();
            txtAd.Clear();
            txtKod.Clear();
            txtHarfNotu.Clear();
            nudKredi.Value = 0;
        }

        private void DersiSec(Ders ders)
        {
            foreach (DataGridViewRow satir in dgvDersler.Rows)
            {
                if (satir.DataBoundItem == ders)
                    satir.Selected = true;
            }
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtAd.Text) || string.IsNullOrEmpty(txtKod.Text) || string.IsNullOrEmpty(txtHarfNotu.Text) || nudKredi.Value == 0)
            {
                MessageBox.Show("L�tfen t�m alanlar� do�ru doldurdu�unuzdan emin olunuz.");
                return;
            }
            Ders ders = new Ders();
            ders.Ad = txtAd.Text.Trim();
            ders.Kod = txtKod.Text.Trim().ToUpper();
            if (txtHarfNotu.Text.Trim().ToUpper() != "A" && txtHarfNotu.Text.Trim().ToUpper() != "B" && txtHarfNotu.Text.Trim().ToUpper() != "C" && txtHarfNotu.Text.Trim().ToUpper() != "D" && txtHarfNotu.Text.Trim().ToUpper() != "F")
            {
                MessageBox.Show("Hatal� Harf Notu! Harf Notu Sadece A, B, C, D veya F olabilir.");
                return;
            }
            ders.HarfNotu = txtHarfNotu.Text.Trim().ToUpper();
            ders.Kredi = (int)nudKredi.Value;
            db.Dersler.Add(ders);
            db.SaveChanges();
            VerileriYukle();
            DersiSec(ders);
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim() == "")
            {
                MessageBox.Show("L�tfen g�ncellemek istedi�iniz Id'yi giriniz");
                return;
            }
            Ders? ders = db.Dersler.FirstOrDefault(d => d.Id == Convert.ToInt32(txtId.Text));
            if (ders == null)
            {
                MessageBox.Show("Girdi�iniz Id'ye sahip ders bulunamad�.");
                return;
            }
            ders.Ad = txtAd.Text.Trim();
            ders.Kod = txtKod.Text.Trim().ToUpper();
            if (txtHarfNotu.Text.Trim().ToUpper() != "A" && txtHarfNotu.Text.Trim().ToUpper() != "B" && txtHarfNotu.Text.Trim().ToUpper() != "C" && txtHarfNotu.Text.Trim().ToUpper() != "D" && txtHarfNotu.Text.Trim().ToUpper() != "F")
            {
                MessageBox.Show("Hatal� Harf Notu! Harf Notu Sadece A, B, C, D veya F olabilir.");
                return;
            }
            ders.HarfNotu = txtHarfNotu.Text.Trim().ToUpper();
            ders.Kredi = (int)nudKredi.Value;

            db.SaveChanges();
            VerileriYukle();
            DersiSec(ders);
            MessageBox.Show("Ders G�ncellendi.");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim() == "")
            {
                MessageBox.Show("Silmek i�in l�tfen Id giriniz.");
                return;
            }
            Ders? ders = db.Dersler.FirstOrDefault(d => d.Id == Convert.ToInt32(txtId.Text));
            if (ders == null)
            {
                MessageBox.Show("Girdi�iniz Id'ye sahip ders bulunamad�.");
                return;
            }
            db.Dersler.Remove(ders);
            db.SaveChanges();
            VerileriYukle();
            MessageBox.Show("Ders Silindi");
        }

        private void btnOrt_Click(object sender, EventArgs e)
        {
            double ortalama = 0;
            foreach (Ders ders in db.Dersler)
            {
                double harfNotuDegeri;
                switch (ders.HarfNotu)
                {
                    case "A":
                        harfNotuDegeri = 4;
                        break;
                    case "B":
                        harfNotuDegeri = 3.5;
                        break;
                    case "C":
                        harfNotuDegeri = 2;
                        break;
                    case "D":
                        harfNotuDegeri = 1;
                        break;
                    case "F":
                        harfNotuDegeri = 0;
                        break;
                    default:
                        harfNotuDegeri = 0;
                        break;
                }
                ortalama += harfNotuDegeri * ders.Kredi;
            }
            ortalama = ortalama / db.Dersler.Sum(d => d.Kredi);
            MessageBox.Show("Genel Ortalama: " + ortalama);
        }

        private void btnIstatistik_Click(object sender, EventArgs e)
        {
            int basarili = 0, basarisiz = 0, sinamali = 0;
            foreach (Ders ders in db.Dersler)
            {
                switch (ders.HarfNotu)
                {
                    case "A":
                    case "B":
                    case "C":
                        basarili++;
                        break;
                    case "D":
                        sinamali++;
                        break;
                    case "F":
                        basarisiz++;
                        break;
                }
            }
            MessageBox.Show($"{db.Dersler.Count()} dersten\n{basarili} tanesi ba�ar�l�\n{basarisiz} tanesi ba�ar�s�z\n{sinamali} tanesi s�namal�d�r.");
        }
    }
}
