﻿namespace Odev32
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtDersId = new TextBox();
            txtDersAd = new TextBox();
            label2 = new Label();
            txtHarfNot = new TextBox();
            txtHarfNotu = new Label();
            txtDersKod = new TextBox();
            label3 = new Label();
            txtKredi = new TextBox();
            label5 = new Label();
            btnEkle = new Button();
            btnGuncelle = new Button();
            btnKaldır = new Button();
            dgvDersler = new DataGridView();
            btnOrtalamaHesapla = new Button();
            btnIstatistikleriGoster = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 24);
            label1.Name = "label1";
            label1.Size = new Size(52, 20);
            label1.TabIndex = 0;
            label1.Text = "DersId";
            // 
            // txtDersId
            // 
            txtDersId.Location = new Point(111, 21);
            txtDersId.Name = "txtDersId";
            txtDersId.Size = new Size(143, 27);
            txtDersId.TabIndex = 1;
            // 
            // txtDersAd
            // 
            txtDersAd.Location = new Point(111, 66);
            txtDersAd.Name = "txtDersAd";
            txtDersAd.Size = new Size(143, 27);
            txtDersAd.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 69);
            label2.Name = "label2";
            label2.Size = new Size(62, 20);
            label2.TabIndex = 2;
            label2.Text = "DersAdı";
            // 
            // txtHarfNot
            // 
            txtHarfNot.Location = new Point(111, 155);
            txtHarfNot.Name = "txtHarfNot";
            txtHarfNot.Size = new Size(143, 27);
            txtHarfNot.TabIndex = 7;
            // 
            // txtHarfNotu
            // 
            txtHarfNotu.AutoSize = true;
            txtHarfNotu.Location = new Point(29, 158);
            txtHarfNotu.Name = "txtHarfNotu";
            txtHarfNotu.Size = new Size(75, 20);
            txtHarfNotu.TabIndex = 6;
            txtHarfNotu.Text = "Harf Notu";
            // 
            // txtDersKod
            // 
            txtDersKod.Location = new Point(111, 110);
            txtDersKod.Name = "txtDersKod";
            txtDersKod.Size = new Size(143, 27);
            txtDersKod.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 113);
            label3.Name = "label3";
            label3.Size = new Size(78, 20);
            label3.TabIndex = 4;
            label3.Text = "Ders Kodu";
            // 
            // txtKredi
            // 
            txtKredi.Location = new Point(111, 205);
            txtKredi.Name = "txtKredi";
            txtKredi.Size = new Size(143, 27);
            txtKredi.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(29, 208);
            label5.Name = "label5";
            label5.Size = new Size(44, 20);
            label5.TabIndex = 8;
            label5.Text = "Kredi";
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(31, 254);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 10;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(131, 254);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(94, 29);
            btnGuncelle.TabIndex = 11;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnKaldır
            // 
            btnKaldır.Location = new Point(31, 289);
            btnKaldır.Name = "btnKaldır";
            btnKaldır.Size = new Size(194, 29);
            btnKaldır.TabIndex = 12;
            btnKaldır.Text = "Kaldır";
            btnKaldır.UseVisualStyleBackColor = true;
            btnKaldır.Click += btnKaldır_Click;
            // 
            // dgvDersler
            // 
            dgvDersler.AllowUserToDeleteRows = false;
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Location = new Point(282, 22);
            dgvDersler.Name = "dgvDersler";
            dgvDersler.ReadOnly = true;
            dgvDersler.RowHeadersWidth = 51;
            dgvDersler.Size = new Size(681, 296);
            dgvDersler.TabIndex = 13;
            // 
            // btnOrtalamaHesapla
            // 
            btnOrtalamaHesapla.Location = new Point(969, 87);
            btnOrtalamaHesapla.Name = "btnOrtalamaHesapla";
            btnOrtalamaHesapla.Size = new Size(150, 73);
            btnOrtalamaHesapla.TabIndex = 14;
            btnOrtalamaHesapla.Text = "Ortalama Hesapla";
            btnOrtalamaHesapla.UseVisualStyleBackColor = true;
            btnOrtalamaHesapla.Click += btnOrtalamaHesapla_Click;
            // 
            // btnIstatistikleriGoster
            // 
            btnIstatistikleriGoster.Location = new Point(969, 166);
            btnIstatistikleriGoster.Name = "btnIstatistikleriGoster";
            btnIstatistikleriGoster.Size = new Size(150, 76);
            btnIstatistikleriGoster.TabIndex = 15;
            btnIstatistikleriGoster.Text = "İstatistikleri Göster";
            btnIstatistikleriGoster.UseVisualStyleBackColor = true;
            btnIstatistikleriGoster.Click += btnIstatistikleriGoster_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1140, 344);
            Controls.Add(btnIstatistikleriGoster);
            Controls.Add(btnOrtalamaHesapla);
            Controls.Add(dgvDersler);
            Controls.Add(btnKaldır);
            Controls.Add(btnGuncelle);
            Controls.Add(btnEkle);
            Controls.Add(txtKredi);
            Controls.Add(label5);
            Controls.Add(txtHarfNot);
            Controls.Add(txtHarfNotu);
            Controls.Add(txtDersKod);
            Controls.Add(label3);
            Controls.Add(txtDersAd);
            Controls.Add(label2);
            Controls.Add(txtDersId);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtDersId;
        private TextBox txtDersAd;
        private Label label2;
        private TextBox txtHarfNot;
        private Label txtHarfNotu;
        private TextBox txtDersKod;
        private Label label3;
        private TextBox txtKredi;
        private Label label5;
        private Button btnEkle;
        private Button btnGuncelle;
        private Button btnKaldır;
        private DataGridView dgvDersler;
        private Button btnOrtalamaHesapla;
        private Button btnIstatistikleriGoster;
    }
}
