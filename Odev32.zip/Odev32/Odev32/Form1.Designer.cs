﻿namespace Odev32
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtId = new TextBox();
            txtAd = new TextBox();
            label2 = new Label();
            txtKod = new TextBox();
            label3 = new Label();
            txtHarfNotu = new TextBox();
            label4 = new Label();
            label5 = new Label();
            btnGuncelle = new Button();
            btnSil = new Button();
            dgvDersler = new DataGridView();
            btnOrt = new Button();
            btnIstatistik = new Button();
            nudKredi = new NumericUpDown();
            btnEkle = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudKredi).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(55, 104);
            label1.Name = "label1";
            label1.Size = new Size(75, 25);
            label1.TabIndex = 0;
            label1.Text = "Ders ID:";
            // 
            // txtId
            // 
            txtId.Location = new Point(163, 98);
            txtId.Name = "txtId";
            txtId.Size = new Size(183, 31);
            txtId.TabIndex = 1;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(163, 187);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(183, 31);
            txtAd.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(55, 193);
            label2.Name = "label2";
            label2.Size = new Size(84, 25);
            label2.TabIndex = 2;
            label2.Text = "Ders Adı:";
            // 
            // txtKod
            // 
            txtKod.Location = new Point(163, 271);
            txtKod.Name = "txtKod";
            txtKod.Size = new Size(183, 31);
            txtKod.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(40, 277);
            label3.Name = "label3";
            label3.Size = new Size(99, 25);
            label3.TabIndex = 4;
            label3.Text = "Ders Kodu:";
            // 
            // txtHarfNotu
            // 
            txtHarfNotu.Location = new Point(163, 352);
            txtHarfNotu.Name = "txtHarfNotu";
            txtHarfNotu.Size = new Size(183, 31);
            txtHarfNotu.TabIndex = 7;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(44, 355);
            label4.Name = "label4";
            label4.Size = new Size(95, 25);
            label4.TabIndex = 6;
            label4.Text = "Harf Notu:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(71, 440);
            label5.Name = "label5";
            label5.Size = new Size(68, 25);
            label5.TabIndex = 8;
            label5.Text = "Kredisi:";
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(201, 530);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(145, 48);
            btnGuncelle.TabIndex = 11;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(40, 594);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(306, 48);
            btnSil.TabIndex = 12;
            btnSil.Text = "Kaldır";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // dgvDersler
            // 
            dgvDersler.AllowUserToAddRows = false;
            dgvDersler.AllowUserToDeleteRows = false;
            dgvDersler.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDersler.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Location = new Point(374, 30);
            dgvDersler.MultiSelect = false;
            dgvDersler.Name = "dgvDersler";
            dgvDersler.ReadOnly = true;
            dgvDersler.RowHeadersWidth = 62;
            dgvDersler.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDersler.Size = new Size(901, 676);
            dgvDersler.TabIndex = 13;
            // 
            // btnOrt
            // 
            btnOrt.Location = new Point(1281, 263);
            btnOrt.Name = "btnOrt";
            btnOrt.Size = new Size(236, 71);
            btnOrt.TabIndex = 14;
            btnOrt.Text = "Ortalama Hesapla";
            btnOrt.UseVisualStyleBackColor = true;
            btnOrt.Click += btnOrt_Click;
            // 
            // btnIstatistik
            // 
            btnIstatistik.Location = new Point(1281, 352);
            btnIstatistik.Name = "btnIstatistik";
            btnIstatistik.Size = new Size(236, 71);
            btnIstatistik.TabIndex = 15;
            btnIstatistik.Text = "İstatistikleri Göster";
            btnIstatistik.UseVisualStyleBackColor = true;
            btnIstatistik.Click += btnIstatistik_Click;
            // 
            // nudKredi
            // 
            nudKredi.Location = new Point(166, 438);
            nudKredi.Name = "nudKredi";
            nudKredi.Size = new Size(180, 31);
            nudKredi.TabIndex = 16;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(40, 530);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(145, 48);
            btnEkle.TabIndex = 17;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1529, 718);
            Controls.Add(btnEkle);
            Controls.Add(nudKredi);
            Controls.Add(btnIstatistik);
            Controls.Add(btnOrt);
            Controls.Add(dgvDersler);
            Controls.Add(btnSil);
            Controls.Add(btnGuncelle);
            Controls.Add(label5);
            Controls.Add(txtHarfNotu);
            Controls.Add(label4);
            Controls.Add(txtKod);
            Controls.Add(label3);
            Controls.Add(txtAd);
            Controls.Add(label2);
            Controls.Add(txtId);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudKredi).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtId;
        private TextBox txtAd;
        private Label label2;
        private TextBox txtKod;
        private Label label3;
        private TextBox txtHarfNotu;
        private Label label4;
        private TextBox txt;
        private Label label5;
        private Button button1;
        private Button btnGuncelle;
        private Button btnSil;
        private DataGridView dgvDersler;
        private Button btnOrt;
        private Button btnIstatistik;
        private NumericUpDown nudKredi;
        private Button btnEkle;
    }
}
