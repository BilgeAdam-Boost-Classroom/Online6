﻿namespace Odev32
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvDersler = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtDersId = new TextBox();
            panel1 = new Panel();
            nudDersKredisi = new NumericUpDown();
            cobHarfNotu = new ComboBox();
            txtDersKodu = new TextBox();
            txtDersAdi = new TextBox();
            btnKaldir = new Button();
            btnGuncelle = new Button();
            btnEkle = new Button();
            btnOrtalamaHesapla = new Button();
            btnIstatislikleriGoster = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudDersKredisi).BeginInit();
            SuspendLayout();
            // 
            // dgvDersler
            // 
            dgvDersler.AllowUserToAddRows = false;
            dgvDersler.AllowUserToDeleteRows = false;
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dgvDersler.Location = new Point(453, 41);
            dgvDersler.Name = "dgvDersler";
            dgvDersler.ReadOnly = true;
            dgvDersler.RowHeadersWidth = 62;
            dgvDersler.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvDersler.Size = new Size(608, 564);
            dgvDersler.TabIndex = 0;
            dgvDersler.DoubleClick += dgvDersler_DoubleClick;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Id";
            Column1.HeaderText = "Ders ID";
            Column1.MinimumWidth = 3;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 150;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Ad";
            Column2.HeaderText = "Ders Adı";
            Column2.MinimumWidth = 10;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 150;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Kod";
            Column3.HeaderText = "Ders Kodu";
            Column3.MinimumWidth = 8;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 150;
            // 
            // Column4
            // 
            Column4.DataPropertyName = "HarfNotu";
            Column4.HeaderText = "Harf Notu";
            Column4.MinimumWidth = 3;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            Column4.Width = 150;
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Kredi";
            Column5.HeaderText = "Kredi";
            Column5.MinimumWidth = 3;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            Column5.Width = 150;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(20, 76);
            label1.Name = "label1";
            label1.Size = new Size(82, 25);
            label1.TabIndex = 1;
            label1.Text = "Ders ID :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label2.Location = new Point(20, 335);
            label2.Name = "label2";
            label2.Size = new Size(78, 25);
            label2.TabIndex = 2;
            label2.Text = "Kredisi :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label3.Location = new Point(20, 271);
            label3.Name = "label3";
            label3.Size = new Size(104, 25);
            label3.TabIndex = 3;
            label3.Text = "Harf Notu :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label4.Location = new Point(20, 203);
            label4.Name = "label4";
            label4.Size = new Size(108, 25);
            label4.TabIndex = 4;
            label4.Text = "Ders Kodu :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label5.Location = new Point(20, 140);
            label5.Name = "label5";
            label5.Size = new Size(92, 25);
            label5.TabIndex = 5;
            label5.Text = "Ders Adı :";
            // 
            // txtDersId
            // 
            txtDersId.Location = new Point(145, 76);
            txtDersId.Name = "txtDersId";
            txtDersId.Size = new Size(234, 31);
            txtDersId.TabIndex = 6;
            // 
            // panel1
            // 
            panel1.Controls.Add(nudDersKredisi);
            panel1.Controls.Add(cobHarfNotu);
            panel1.Controls.Add(txtDersKodu);
            panel1.Controls.Add(txtDersAdi);
            panel1.Controls.Add(btnKaldir);
            panel1.Controls.Add(btnGuncelle);
            panel1.Controls.Add(btnEkle);
            panel1.Controls.Add(txtDersId);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label1);
            panel1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            panel1.Location = new Point(31, 41);
            panel1.Name = "panel1";
            panel1.Size = new Size(404, 564);
            panel1.TabIndex = 7;
            // 
            // nudDersKredisi
            // 
            nudDersKredisi.Location = new Point(145, 335);
            nudDersKredisi.Name = "nudDersKredisi";
            nudDersKredisi.Size = new Size(234, 31);
            nudDersKredisi.TabIndex = 15;
            // 
            // cobHarfNotu
            // 
            cobHarfNotu.DropDownStyle = ComboBoxStyle.DropDownList;
            cobHarfNotu.FormattingEnabled = true;
            cobHarfNotu.Location = new Point(145, 271);
            cobHarfNotu.Name = "cobHarfNotu";
            cobHarfNotu.Size = new Size(234, 33);
            cobHarfNotu.TabIndex = 14;
            // 
            // txtDersKodu
            // 
            txtDersKodu.Location = new Point(145, 197);
            txtDersKodu.Name = "txtDersKodu";
            txtDersKodu.Size = new Size(234, 31);
            txtDersKodu.TabIndex = 11;
            // 
            // txtDersAdi
            // 
            txtDersAdi.Location = new Point(145, 134);
            txtDersAdi.Name = "txtDersAdi";
            txtDersAdi.Size = new Size(234, 31);
            txtDersAdi.TabIndex = 10;
            // 
            // btnKaldir
            // 
            btnKaldir.BackColor = SystemColors.ControlLight;
            btnKaldir.Location = new Point(20, 450);
            btnKaldir.Name = "btnKaldir";
            btnKaldir.Size = new Size(359, 40);
            btnKaldir.TabIndex = 9;
            btnKaldir.Text = "Kaldır";
            btnKaldir.UseVisualStyleBackColor = false;
            btnKaldir.Click += btnKaldir_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.BackColor = SystemColors.ControlLight;
            btnGuncelle.Location = new Point(204, 399);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(175, 40);
            btnGuncelle.TabIndex = 8;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = false;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = SystemColors.ControlLight;
            btnEkle.Location = new Point(20, 399);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(178, 40);
            btnEkle.TabIndex = 7;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnOrtalamaHesapla
            // 
            btnOrtalamaHesapla.BackColor = SystemColors.ControlLight;
            btnOrtalamaHesapla.Location = new Point(660, 622);
            btnOrtalamaHesapla.Name = "btnOrtalamaHesapla";
            btnOrtalamaHesapla.Size = new Size(193, 45);
            btnOrtalamaHesapla.TabIndex = 10;
            btnOrtalamaHesapla.Text = "Ortalama Hesapla";
            btnOrtalamaHesapla.UseVisualStyleBackColor = false;
            btnOrtalamaHesapla.Click += btnOrtalamaHesapla_Click;
            // 
            // btnIstatislikleriGoster
            // 
            btnIstatislikleriGoster.BackColor = SystemColors.ControlLight;
            btnIstatislikleriGoster.Location = new Point(868, 622);
            btnIstatislikleriGoster.Name = "btnIstatislikleriGoster";
            btnIstatislikleriGoster.Size = new Size(193, 45);
            btnIstatislikleriGoster.TabIndex = 11;
            btnIstatislikleriGoster.Text = "İstatislikleri Göster";
            btnIstatislikleriGoster.UseVisualStyleBackColor = false;
            btnIstatislikleriGoster.Click += btnIstatislikleriGoster_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1078, 689);
            Controls.Add(btnIstatislikleriGoster);
            Controls.Add(btnOrtalamaHesapla);
            Controls.Add(panel1);
            Controls.Add(dgvDersler);
            MaximumSize = new Size(1100, 745);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Ders Bilgi Formu";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudDersKredisi).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgvDersler;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtDersId;
        private Panel panel1;
        private TextBox txtDersKodu;
        private TextBox txtDersAdi;
        private Button btnKaldir;
        private Button btnGuncelle;
        private Button btnEkle;
        private Button btnOrtalamaHesapla;
        private Button btnIstatislikleriGoster;
        private ComboBox cobHarfNotu;
        private NumericUpDown nudDersKredisi;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
    }
}
