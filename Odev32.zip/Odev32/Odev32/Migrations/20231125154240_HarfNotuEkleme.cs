﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev32.Migrations
{
    /// <inheritdoc />
    public partial class HarfNotuEkleme : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "HarfNotları",
                columns: new[] { "Id", "Katsayi", "NotAdi" },
                values: new object[,]
                {
                    { 1, 4.0, "A" },
                    { 2, 3.5, "B" },
                    { 3, 2.0, "C" },
                    { 4, 1.0, "D" },
                    { 5, 0.0, "F" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "HarfNotları",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "HarfNotları",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "HarfNotları",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "HarfNotları",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "HarfNotları",
                keyColumn: "Id",
                keyValue: 5);
        }
    }
}
