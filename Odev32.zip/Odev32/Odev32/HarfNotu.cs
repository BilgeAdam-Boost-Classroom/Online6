﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev32
{
   public class HarfNotu
    {
        public int Id { get; set; }

        [MaxLength(2)]
        public string NotAdi { get; set; } = null!;

        [Precision(18,2)]
        public double Katsayi { get; set; }
        public override string ToString()
        {
            return NotAdi;
        }

    }
}
