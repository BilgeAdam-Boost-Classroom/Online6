namespace Odev32
{
    public partial class Form1 : Form
    {
        DerslerDbContext db = new DerslerDbContext();
        public Form1()
        {
            InitializeComponent();
            VerileriYukle();
        }

        private void VerileriYukle()
        {
            dgvDersler.DataSource = db.Dersler.ToList();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            txtHarfNotu.Text.ToUpper();
            if (Enum.TryParse(txtHarfNotu.Text.ToUpper(), out HarfNotu harfNotu) && txtAd.Text != "" && DersKoduKontrol(txtKod.Text) && txtKredi.Text.Length == 1 && char.IsDigit(txtKredi.Text[0]))
            {
                Ders ders = new Ders();
                ders.Ad = txtAd.Text;
                ders.HarfNotu = harfNotu;
                ders.Kod = txtKod.Text;
                ders.Kredi = Convert.ToInt32(txtKredi.Text);
                db.Dersler.Add(ders);
                db.SaveChanges();
                VerileriYukle();

            }
            else
            {
                MessageBox.Show("Harf notu(A,B,C,D,F), ders ad�, ders kodu ve kredi zorunludur (kredi tek bir rakam olmal�!)");
            }

        }

        public bool DersKoduKontrol(string metin)
        {

            if (metin.Length == 6)
            {
                if (char.IsLetter(metin[0]) && char.IsLetter(metin[1]) && char.IsLetter(metin[2]))
                {

                    if (char.IsDigit(metin[3]) && char.IsDigit(metin[4]) && char.IsDigit(metin[5]))
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Ders Kodunun ilk �� karakter harf, sonraki �� karakter rakam olmal�.");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Ders Kodunun ilk 3 karakteri harf i�ermeli");
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Ders Kodu 6 karakterden olu�mal�d�r.");
                return false;
            }
        }
        private double HarfNotuKatsayisi(HarfNotu harfNotu)
        {
            switch (harfNotu)
            {
                case HarfNotu.A: return 4.0;
                case HarfNotu.B: return 3.5;
                case HarfNotu.C: return 2.0;
                case HarfNotu.D: return 1.0;
                case HarfNotu.F: return 0.0;
                default: return 0.0;
            }
        }

        private void btnKald�r_Click(object sender, EventArgs e)
        {
            if (txtId.Text != null)
            {
                int silinecekId = Convert.ToInt32(txtId.Text);

                var silinecekDers = db.Dersler.FirstOrDefault(a => a.Id == silinecekId);

                db.Dersler.Remove(silinecekDers);
                db.SaveChanges();
                VerileriYukle();
            }
            else
            {
                MessageBox.Show("ID giriniz!");
            }

        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            Ders ders;
            int guncellenecekId = Convert.ToInt32(txtId.Text);
            ders = db.Dersler.FirstOrDefault(d => d.Id == guncellenecekId)!;
            ders.Ad = txtAd.Text;
            ders.Kod = txtKod.Text;
            ders.Kredi = Convert.ToInt32(txtKredi.Text);
            if (Enum.TryParse(txtHarfNotu.Text, out HarfNotu harfNotu))
            {
                ders.HarfNotu = harfNotu;

            }
            else
            {
                MessageBox.Show("Harf notu A,B,C,D,F olmal�d�r");
            }
            db.SaveChanges();
            VerileriYukle();

        }

        private void btnOrtalamaHesapla_Click(object sender, EventArgs e)
        {
            var dersler = db.Dersler.ToList();

            if (dersler.Any())
            {
                double ortalama = dersler.Sum(d => d.Kredi * HarfNotuKatsayisi(d.HarfNotu)) / dersler.Sum(d => d.Kredi);
                MessageBox.Show($"Ortalama: {ortalama}");
            }
            else
            {
                MessageBox.Show("Hen�z ders eklenmemi�.");
            }
        }

        private void btnIstatistikler_Click(object sender, EventArgs e)
        {
            int toplamDersSayisi = db.Dersler.Count();
            int basariliDersSayisi = db.Dersler.Count(d => d.HarfNotu == HarfNotu.A || d.HarfNotu == HarfNotu.B || d.HarfNotu == HarfNotu.C);
            int basarisizDersSayisi = db.Dersler.Count(d => d.HarfNotu == HarfNotu.F);
            int sinamaliDersSayisi = db.Dersler.Count(d => d.HarfNotu == HarfNotu.D);

            MessageBox.Show($"Toplam Ders Say�s�: {toplamDersSayisi}\nBa�ar�l� Ders Say�s�: {basariliDersSayisi}\nBa�ar�s�z Ders Say�s�: {basarisizDersSayisi}\nS�namal� Ders Say�s�: {sinamaliDersSayisi}");
        }

        private void dgvDersler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDersler.Rows[e.RowIndex];

                txtId.Text = row.Cells["Id"].Value.ToString();
                txtAd.Text = row.Cells["Ad"].Value.ToString();
                txtHarfNotu.Text = row.Cells["Kod"].Value.ToString();
                txtKod.Text = row.Cells["HarfNotu"].Value.ToString();
                txtKredi.Text = row.Cells["Kredi"].Value.ToString();
            }
        }
    }
}

