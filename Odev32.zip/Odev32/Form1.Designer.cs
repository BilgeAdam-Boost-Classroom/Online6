﻿namespace Odev32
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtId = new TextBox();
            btnEkle = new Button();
            dgvDersler = new DataGridView();
            txtAd = new TextBox();
            label2 = new Label();
            txtKod = new TextBox();
            label3 = new Label();
            txtHarfNotu = new TextBox();
            label4 = new Label();
            txtKredi = new TextBox();
            label5 = new Label();
            btnGuncelle = new Button();
            btnKaldır = new Button();
            btnOrtalamaHesapla = new Button();
            btnIstatistikler = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 22);
            label1.Name = "label1";
            label1.Size = new Size(47, 15);
            label1.TabIndex = 0;
            label1.Text = "Ders ID:";
            // 
            // txtId
            // 
            txtId.Location = new Point(12, 40);
            txtId.Name = "txtId";
            txtId.Size = new Size(206, 23);
            txtId.TabIndex = 1;
            // 
            // btnEkle
            // 
            btnEkle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnEkle.Location = new Point(12, 273);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(100, 39);
            btnEkle.TabIndex = 2;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // dgvDersler
            // 
            dgvDersler.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDersler.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Location = new Point(224, 12);
            dgvDersler.Name = "dgvDersler";
            dgvDersler.Size = new Size(654, 525);
            dgvDersler.TabIndex = 3;
            dgvDersler.CellClick += dgvDersler_CellClick;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(12, 90);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(206, 23);
            txtAd.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 72);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 4;
            label2.Text = "Ders Adı:";
            // 
            // txtKod
            // 
            txtKod.Location = new Point(12, 144);
            txtKod.Name = "txtKod";
            txtKod.Size = new Size(206, 23);
            txtKod.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 126);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 6;
            label3.Text = "Ders Kodu:";
            // 
            // txtHarfNotu
            // 
            txtHarfNotu.Location = new Point(12, 194);
            txtHarfNotu.Name = "txtHarfNotu";
            txtHarfNotu.Size = new Size(206, 23);
            txtHarfNotu.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 176);
            label4.Name = "label4";
            label4.Size = new Size(60, 15);
            label4.TabIndex = 8;
            label4.Text = "Harf Notu";
            // 
            // txtKredi
            // 
            txtKredi.Location = new Point(12, 244);
            txtKredi.Name = "txtKredi";
            txtKredi.Size = new Size(206, 23);
            txtKredi.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 226);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 10;
            label5.Text = "Kredisi";
            // 
            // btnGuncelle
            // 
            btnGuncelle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnGuncelle.Location = new Point(118, 273);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(100, 39);
            btnGuncelle.TabIndex = 12;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnKaldır
            // 
            btnKaldır.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnKaldır.Location = new Point(67, 318);
            btnKaldır.Name = "btnKaldır";
            btnKaldır.Size = new Size(100, 39);
            btnKaldır.TabIndex = 13;
            btnKaldır.Text = "Kaldır";
            btnKaldır.UseVisualStyleBackColor = true;
            btnKaldır.Click += btnKaldır_Click;
            // 
            // btnOrtalamaHesapla
            // 
            btnOrtalamaHesapla.BackColor = Color.ForestGreen;
            btnOrtalamaHesapla.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnOrtalamaHesapla.ForeColor = SystemColors.Info;
            btnOrtalamaHesapla.Location = new Point(12, 376);
            btnOrtalamaHesapla.Name = "btnOrtalamaHesapla";
            btnOrtalamaHesapla.Size = new Size(206, 77);
            btnOrtalamaHesapla.TabIndex = 14;
            btnOrtalamaHesapla.Text = "Ortalama Hesapla";
            btnOrtalamaHesapla.UseVisualStyleBackColor = false;
            btnOrtalamaHesapla.Click += btnOrtalamaHesapla_Click;
            // 
            // btnIstatistikler
            // 
            btnIstatistikler.BackColor = Color.ForestGreen;
            btnIstatistikler.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnIstatistikler.ForeColor = SystemColors.Info;
            btnIstatistikler.Location = new Point(12, 459);
            btnIstatistikler.Name = "btnIstatistikler";
            btnIstatistikler.Size = new Size(206, 77);
            btnIstatistikler.TabIndex = 15;
            btnIstatistikler.Text = "İstatistikleri Göster";
            btnIstatistikler.UseVisualStyleBackColor = false;
            btnIstatistikler.Click += btnIstatistikler_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(890, 551);
            Controls.Add(btnIstatistikler);
            Controls.Add(btnOrtalamaHesapla);
            Controls.Add(btnKaldır);
            Controls.Add(btnGuncelle);
            Controls.Add(txtKredi);
            Controls.Add(label5);
            Controls.Add(txtHarfNotu);
            Controls.Add(label4);
            Controls.Add(txtKod);
            Controls.Add(label3);
            Controls.Add(txtAd);
            Controls.Add(label2);
            Controls.Add(dgvDersler);
            Controls.Add(btnEkle);
            Controls.Add(txtId);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtId;
        private Button btnEkle;
        private DataGridView dgvDersler;
        private TextBox txtAd;
        private Label label2;
        private TextBox txtKod;
        private Label label3;
        private TextBox txtHarfNotu;
        private Label label4;
        private TextBox txtKredi;
        private Label label5;
        private Button btnGuncelle;
        private Button btnKaldır;
        private Button btnOrtalamaHesapla;
        private Button btnIstatistikler;
    }
}
