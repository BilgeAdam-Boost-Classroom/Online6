using Odev31DBFirst.Models;

namespace Odev31DBFirst
{
    public partial class Form1 : Form
    {
        NorthwndContext db;

        public Form1()
        {
            InitializeComponent();
            db = new NorthwndContext();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            // Yeni bir territory nesnesi olustur
            Territory territory = new Territory();
            territory.TerritoryId = txtId.Text;
            territory.TerritoryDescription = txtAd.Text;
            territory.RegionId = Convert.ToInt32(txtRegionId.Text);

            // db'deki regions koleksiyonuna ekle
            db.Territories.Add(territory);

            // db'deki degisiklikleri kaydet
            db.SaveChanges();
            MessageBox.Show("Eklenmistir");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string silinecekId = txtId.Text;


            Territory silinecekTerritory = db.Territories.FirstOrDefault(x => x.TerritoryId == silinecekId);


            // sonra onu sil.
            db.Territories.Remove(silinecekTerritory);

            // en son degisiklikleri kaydet.
            db.SaveChanges();
            MessageBox.Show("Id silindi.");

        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            
            // yine �nce g�ncellenecek b�lge bulunur.
            string guncellenecekId = txtId.Text;

            // yine o b�lgeyi bul
            var guncellenecekBolge = db.Territories.FirstOrDefault(x => x.TerritoryId == guncellenecekId);



            // simdi o b�lgenin �zelliklerini al.
            guncellenecekBolge.TerritoryDescription = txtAd.Text;

            // son olarak da degisiklikleri kaydet
            db.SaveChanges();

            MessageBox.Show("G�ncellenmistir.");
        }
    }
}
