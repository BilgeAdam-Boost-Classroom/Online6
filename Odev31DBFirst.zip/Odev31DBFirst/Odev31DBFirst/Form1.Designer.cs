﻿namespace Odev31DBFirst
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGuncelle = new Button();
            btnSil = new Button();
            btnEkle = new Button();
            label2 = new Label();
            label1 = new Label();
            txtAd = new TextBox();
            txtId = new TextBox();
            label3 = new Label();
            txtRegionId = new TextBox();
            SuspendLayout();
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(256, 217);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(115, 29);
            btnGuncelle.TabIndex = 13;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(151, 217);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(99, 29);
            btnSil.TabIndex = 12;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(44, 217);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(101, 29);
            btnEkle.TabIndex = 11;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 110);
            label2.Name = "label2";
            label2.Size = new Size(114, 20);
            label2.TabIndex = 10;
            label2.Text = "Territory Tanimi:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(44, 53);
            label1.Name = "label1";
            label1.Size = new Size(84, 20);
            label1.TabIndex = 9;
            label1.Text = "Territory Id:";
            // 
            // txtAd
            // 
            txtAd.Location = new Point(139, 103);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(232, 27);
            txtAd.TabIndex = 8;
            // 
            // txtId
            // 
            txtId.Location = new Point(139, 50);
            txtId.Name = "txtId";
            txtId.Size = new Size(232, 27);
            txtId.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(44, 162);
            label3.Name = "label3";
            label3.Size = new Size(76, 20);
            label3.TabIndex = 15;
            label3.Text = "Region Id:";
            // 
            // txtRegionId
            // 
            txtRegionId.Location = new Point(139, 159);
            txtRegionId.Name = "txtRegionId";
            txtRegionId.Size = new Size(232, 27);
            txtRegionId.TabIndex = 14;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(410, 299);
            Controls.Add(label3);
            Controls.Add(txtRegionId);
            Controls.Add(btnGuncelle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtAd);
            Controls.Add(txtId);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuncelle;
        private Button btnSil;
        private Button btnEkle;
        private Label label2;
        private Label label1;
        private TextBox txtAd;
        private TextBox txtId;
        private Label label3;
        private TextBox txtRegionId;
    }
}
