﻿using System;
using System.Collections.Generic;

namespace Odev31DBFirst.Models;

public partial class CalisanAdSoyad
{
    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public DateTime? BirthDate { get; set; }
}
