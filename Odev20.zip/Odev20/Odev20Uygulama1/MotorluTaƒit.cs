﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev20Uygulama1
{
   public class MotorluTaşit
    {
        public virtual void Git()
        {
            Console.WriteLine("Motorlu Taşıt Gidiyor.");
        }
    }
}
