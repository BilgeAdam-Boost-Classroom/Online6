﻿namespace Odev20Uygulama1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MotorluTaşit motorluTaşit = new MotorluTaşit();
            motorluTaşit.Git();

            MotorluTaşit turetilmisTasit = new Araba();
            turetilmisTasit.Git();

            Araba araba = new Araba();
            araba.Git();


            Console.ReadKey();
        }
    }
}