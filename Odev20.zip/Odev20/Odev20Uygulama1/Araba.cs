﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev20Uygulama1
{
    public class Araba : MotorluTaşit
    {
        public override void Git()
        {
            Console.WriteLine("Araba Gidiyor.");
        }
    }
}
