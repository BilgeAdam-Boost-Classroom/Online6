﻿namespace _2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstAraba = new ListBox();
            lblOzellikler = new Label();
            SuspendLayout();
            // 
            // lstAraba
            // 
            lstAraba.FormattingEnabled = true;
            lstAraba.ItemHeight = 20;
            lstAraba.Location = new Point(12, 12);
            lstAraba.Name = "lstAraba";
            lstAraba.Size = new Size(300, 164);
            lstAraba.TabIndex = 0;
            lstAraba.SelectedIndexChanged += lstAraba_SelectedIndexChanged;
            // 
            // lblOzellikler
            // 
            lblOzellikler.BorderStyle = BorderStyle.FixedSingle;
            lblOzellikler.Location = new Point(12, 193);
            lblOzellikler.Name = "lblOzellikler";
            lblOzellikler.Size = new Size(300, 234);
            lblOzellikler.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(337, 450);
            Controls.Add(lblOzellikler);
            Controls.Add(lstAraba);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstAraba;
        private Label lblOzellikler;
    }
}