﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2
{
    public class Araba
    {
        public string Marka { get; set; }
        public string Model { get; set; }
        public string Renk { get; set; }
        public string UretimYili { get; set; }
        public string MarkaModel => Marka + "-" + Model;

        public string OzellikleriYaz()
        {
            return $"Marka: {Marka}\nModel: {Model}\nRenk: {Renk}\nÜretim Yılı: {UretimYili}";
        }
    }
}
