﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev20Uygulama2
{
    public class Araba : IComparable
    {
        public string Marka { get; set; }
        public string Model { get; set; }
        public string Renk { get; set; }
        public string UretimYili { get; set; }
        public override string ToString()
        {
            return Marka + " - " + Model;
        }
        public string OzellikleriYaz()
        {
            return "Marka: " + Marka + "\n" + "Modeli: " + Model + "\n" + "Renk: " + Renk + "\n" + "Üretim Yılı: " + UretimYili;
        }

        public int CompareTo(object? obj)
        {
            Araba digerAraba = obj as Araba;

            if (digerAraba == null)
            {
                return -1;
            }

            int markaKarsilastirmasi = this.Marka.CompareTo(digerAraba.Marka);
            if (markaKarsilastirmasi != 0)
                return markaKarsilastirmasi;

            int modelKarsilastirmasi = this.Model.CompareTo(digerAraba.Model);
            if (modelKarsilastirmasi != 0)
                return modelKarsilastirmasi;
            
            return 0;

        }
    }
}
