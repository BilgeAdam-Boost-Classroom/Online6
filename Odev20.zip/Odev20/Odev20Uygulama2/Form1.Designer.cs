﻿namespace Odev20Uygulama2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstModelMarka = new ListBox();
            lblTumOzellikler = new Label();
            SuspendLayout();
            // 
            // lstModelMarka
            // 
            lstModelMarka.FormattingEnabled = true;
            lstModelMarka.ItemHeight = 25;
            lstModelMarka.Location = new Point(12, 12);
            lstModelMarka.Name = "lstModelMarka";
            lstModelMarka.Size = new Size(529, 129);
            lstModelMarka.TabIndex = 0;
            lstModelMarka.SelectedIndexChanged += lstModelMarka_SelectedIndexChanged;
            // 
            // lblTumOzellikler
            // 
            lblTumOzellikler.BackColor = Color.White;
            lblTumOzellikler.Location = new Point(12, 167);
            lblTumOzellikler.Name = "lblTumOzellikler";
            lblTumOzellikler.Size = new Size(529, 166);
            lblTumOzellikler.TabIndex = 1;
            lblTumOzellikler.Text = "Özellikler";
            lblTumOzellikler.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblTumOzellikler);
            Controls.Add(lstModelMarka);
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private ListBox lstModelMarka;
        private Label lblTumOzellikler;
    }
}