namespace Odev20Uygulama2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Araba araba1 = new Araba();
            {
                araba1.Marka = "A";
                araba1.Model = "A1";
                araba1.Renk = "Siyah";
                araba1.UretimYili = "2010";
            }
            Araba araba2 = new Araba();
            {
                araba2.Marka = "B";
                araba2.Model = "B1";
                araba2.Renk = "Siyah";
                araba2.UretimYili = "2020";
            }
            Araba araba3 = new Araba();
            {
                araba3.Marka = "C";
                araba3.Model = "C1";
                araba3.Renk = "Mavi";
                araba3.UretimYili = "2016";
            }
            Araba araba4 = new Araba();
            {
                araba4.Marka = "D";
                araba4.Model = "D1";
                araba4.Renk = "Metalik Gri";
                araba4.UretimYili = "2018";
            }
            List<Araba> arabalar = new List<Araba>() { araba2, araba3, araba3, araba1 };
            arabalar.Sort();
            lstModelMarka.DataSource = arabalar;

        }
        private void lstModelMarka_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstModelMarka.SelectedItem != null)
                lblTumOzellikler.Text = ((Araba)lstModelMarka.SelectedItem).OzellikleriYaz();
            else
                MessageBox.Show("Listeden Bir Araba Se�iniz");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

