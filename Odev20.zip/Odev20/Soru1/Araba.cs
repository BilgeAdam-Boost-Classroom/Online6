﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soru1
{
    public class Araba : MotorluTasit
    {


        //public void Git()
        //{
        //    Console.WriteLine("Araba gidiyor..");
        //}

        public override void Git()
        {
            Console.WriteLine("Araba gidiyor..");
        }
    }
}
