﻿
using Soru1;

MotorluTasit motorluTasit = new MotorluTasit();
motorluTasit.Git();

Araba araba = new Araba();
araba.Git();


MotorluTasit tasit = new Araba();
tasit.Git();

Console.ReadKey();