﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru2
{
    public class Araba
    {
        public string Marka { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Renk { get; set; } = string.Empty;
        public string UretimYili { get; set; } = string.Empty;

        public string OzellikleriYaz()
        {
            return $"Markası: {Marka}, Modeli: {Model}, Rengi: {Renk}, Üretim Yılı: {UretimYili}";
        }

        public override string ToString()
        {
            return $"{Marka} - {Model}";
        }

    }
}
