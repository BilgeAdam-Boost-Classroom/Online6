﻿using _1;

Araba a1 = new Araba();
MotorluTasit m1= new MotorluTasit();

a1.Git();
m1.Git();

a1.GitIki();
m1.GitIki();

MotorluTasit a2=new Araba();
a2.Git();
a2.GitIki();



Console.ReadKey();