﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class Araba:MotorluTasit
    {
        public override void Git()
        {
            Console.WriteLine("Araba gidiyor");
        }
        public new void GitIki()
        {
            Console.WriteLine("Araba gidiyor 2 ");
        }
    }
}
