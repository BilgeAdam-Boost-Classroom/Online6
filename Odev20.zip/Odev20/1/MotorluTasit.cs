﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class MotorluTasit
    {
        public virtual void Git()
        {
            Console.WriteLine("Motorlu taşıt gidiyor");
        }
        public virtual void GitIki()
        {
            Console.WriteLine("Motorlu taşıt gidiyor 2");
        }
    }
}
