﻿using System.ComponentModel.DataAnnotations;

namespace Odev45.Models
{
    public class HayvanViewModel
    {
        [Display(Name = "Ad")]
        [Required(ErrorMessage = "{0} alanı zorunludur.")]
        public string Ad { get; set; } = null!;

        [Display(Name = "Resim")]
        [Required(ErrorMessage = "Lütfen bir {0} seçiniz.")]
        public IFormFile Resim { get; set; } = null!;
    }
}
