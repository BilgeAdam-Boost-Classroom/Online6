﻿using Microsoft.EntityFrameworkCore;

namespace Odev45.Data
{
    public class UygulamaDBContext : DbContext
    {
        public UygulamaDBContext(DbContextOptions<UygulamaDBContext> options) : base(options)
        {

        }

        public DbSet<Hayvan> Hayvanlar { get; set; }
    }
}
