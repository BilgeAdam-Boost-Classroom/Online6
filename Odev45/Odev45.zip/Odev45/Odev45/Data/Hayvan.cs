﻿using System.ComponentModel.DataAnnotations;

namespace Odev45.Data
{
    public class Hayvan
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "{0} alanı zorunludur.")]
        public string Ad { get; set; } = null!;

        [Required(ErrorMessage = "{0} alanı zorunludur.")]
        public string ResimIsmi { get; set; } = null!;
    }
}
