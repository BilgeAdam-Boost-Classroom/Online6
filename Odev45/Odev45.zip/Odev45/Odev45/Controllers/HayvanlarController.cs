﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev45.Data;
using Odev45.Models;

namespace Odev45.Controllers
{
    public class HayvanlarController : Controller
    {
        private readonly UygulamaDBContext _db;
        private readonly IWebHostEnvironment _env;

        public HayvanlarController(UygulamaDBContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }

        // GET: Hayvanlar
        public async Task<IActionResult> Index()
        {
            return View(await _db.Hayvanlar.ToListAsync());
        }

        // GET: Hayvanlar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _db.Hayvanlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        public IActionResult List()
        {
            return View();
        }


        // GET: Hayvanlar/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Hayvanlar/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(HayvanViewModel vm)
        {
            if (ModelState.IsValid)
            {
                string dosyaAdi = vm.Resim.FileName;
                string uzanti = Path.GetExtension(dosyaAdi);
                string yeniDosyaAdi = Guid.NewGuid() + uzanti;
                string yuklemeYeri = Path.Combine(_env.WebRootPath, "img", "upload", yeniDosyaAdi);

                using (var fs = new FileStream(yuklemeYeri, FileMode.CreateNew))
                {
                    await vm.Resim.CopyToAsync(fs);
                }

                Hayvan hayvan = new Hayvan
                {
                    Ad = vm.Ad,
                    ResimIsmi = yeniDosyaAdi
                };


                _db.Hayvanlar.Add(hayvan);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Hayvanlar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _db.Hayvanlar.FindAsync(id);
            if (hayvan == null)
            {
                return NotFound();
            }

            HayvanViewModel vm = new HayvanViewModel
            {
                Ad = hayvan.Ad
            };

            TempData["Id"] = hayvan.Id;



            return View(vm);
        }

        // POST: Hayvanlar/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(HayvanViewModel vm)
        {
            var guncellenecekHayvan = await _db.Hayvanlar.FindAsync(TempData["Id"]);
            try
            {
                if (vm.Resim != null && vm.Resim.FileName != guncellenecekHayvan.ResimIsmi)
                {
                    ResimSil(guncellenecekHayvan);

                    string dosyaAdi = vm.Resim.FileName;
                    string uzanti = Path.GetExtension(dosyaAdi);
                    string yeniDosyaAdi = Guid.NewGuid() + uzanti;
                    string yuklemeYeri = Path.Combine(_env.WebRootPath, "img", "upload", yeniDosyaAdi);

                    using (var fs = new FileStream(yuklemeYeri, FileMode.CreateNew))
                    {
                        await vm.Resim.CopyToAsync(fs);
                    }

                    guncellenecekHayvan.ResimIsmi = yeniDosyaAdi;
                }

                guncellenecekHayvan.Ad = vm.Ad;

                _db.Hayvanlar.Update(guncellenecekHayvan);
                await _db.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                TempData["Durum"] = "Hata oluştu! " + ex.Message;
                return View();
            }
        }

        // GET: Hayvanlar/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _db.Hayvanlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        // POST: Hayvanlar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Hayvan hayvan)
        {
           ResimSil(hayvan);

            _db.Hayvanlar.Remove(hayvan);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HayvanExists(int id)
        {
            return _db.Hayvanlar.Any(e => e.Id == id);
        }


        public void ResimSil(Hayvan hayvan)
        {
            var resmiKullananBaskaVarMi = _db.Hayvanlar.Any(g => g.ResimIsmi == hayvan.ResimIsmi && g.Id != hayvan.Id);

            if (hayvan.ResimIsmi != null && !resmiKullananBaskaVarMi)
            {
                string dosya = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/img/upload", hayvan.ResimIsmi);
                System.IO.File.Delete(dosya);
            }

        }
    }
}
