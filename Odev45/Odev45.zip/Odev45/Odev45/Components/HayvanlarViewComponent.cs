﻿using Microsoft.AspNetCore.Mvc;
using Odev45.Data;

namespace Odev45.Components
{
    public class HayvanlarViewComponent : ViewComponent
    {
        private readonly UygulamaDBContext _db;

        public HayvanlarViewComponent(UygulamaDBContext db)
        {
            _db = db;
        }

        public IViewComponentResult Invoke()
        {
            var hayvanlar = _db.Hayvanlar.ToList();
            return View(model: hayvanlar);
        }
    }
}
