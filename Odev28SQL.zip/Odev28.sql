﻿USE NORTHWND;
-- Odev28;

-- 1:
SELECT DISTINCT ProductID, UnitPrice
FROM [Order Details] 
WHERE UnitPrice < (SELECT AVG(UnitPrice) FROM [Order Details])
ORDER BY UnitPrice DESC;

-- 2:
SELECT r.RegionDescription, t.TerritoryDescription FROM Region r
JOIN Territories t ON r.RegionID = t.RegionID;

-- 3:
SELECT PostalCode FROM Customers WHERE LEN(PostalCode) > 5;

-- 4:
SELECT e.EmployeeID, e.FirstName, e.LastName
FROM Employees e
WHERE e.EmployeeID IN 
(
    SELECT e.EmployeeID
    FROM Employees e
    JOIN Categories c ON e.EmployeeID = c.CategoryID
    WHERE c.CategoryName = 'Seafood'
);

-- 5:
SELECT p.ProductName, c.CategoryName FROM Products p
JOIN Categories c ON p.CategoryID = c.CategoryID
ORDER BY p.ProductName DESC;

-- 6:
SELECT ProductName, CategoryName
FROM 
(
    SELECT p.ProductName, c.CategoryName, p.CategoryID
    FROM Products p
    JOIN Categories c ON p.CategoryID = c.CategoryID
) AS SubQueryAlias
ORDER BY ProductName DESC;

-- 7:
SELECT ProductName, UnitsInStock, UnitPrice
FROM Products
WHERE UnitsInStock > 50 AND UnitPrice > 50
ORDER BY UnitsInStock;

-- 8:
SELECT ProductName, UnitsInStock, UnitPrice
FROM (
    SELECT ProductName, UnitsInStock, UnitPrice
    FROM Products
    WHERE UnitsInStock > 50 AND UnitPrice > 50
) AS SubQueryAlias
ORDER BY UnitsInStock;

-- 9:
SELECT p.ProductName, c.CategoryName, s.CompanyName FROM Products p
JOIN Categories c ON p.CategoryID = c.CategoryID
JOIN Suppliers s ON p.SupplierID = s.SupplierID;
