﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace KucukUnluUyumu.TagHelpers
{
    
    public class KucukUnluTagHelper : TagHelper
    {
        public string Kelime { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            base.Process(context, output);
            if (KucukUnluyeUygunluk(Kelime))
            {
                output.Content.SetContent("Küçük ünlü uyumuna uyumludur.");
            }
            else output.Content.SetContent("Küçük ünlü uyumuna uyumlu değildir.");
        }
        public bool KucukUnluyeUygunluk(string k)
        {
            List<char> sesliHarfler = new List<char>() { 'a', 'e', 'ı', 'i','o','ö','u','ü' };

            List<char> duzUnluler = new List<char>() { 'a','e','ı','i'};

            List<char> yuvarlakUnlu = new List<char>() { 'o','ö','u','ü'};

            List<char> digerSonuclar = new List<char>() { 'a','e','u','ü'};

            List<char> kelimeninSesliHarfleri = new List<char>();

            foreach( var harf in k)
            {
                if(sesliHarfler.Contains(harf))
                    kelimeninSesliHarfleri.Add(harf);
            }
            for (int i = 0; i < kelimeninSesliHarfleri.Count; i++)
            {
                if (i < kelimeninSesliHarfleri.Count - 1 && duzUnluler.Contains(kelimeninSesliHarfleri[i]) && !duzUnluler.Contains(kelimeninSesliHarfleri[i + 1]))
                    return false;

                if (i < kelimeninSesliHarfleri.Count - 1 && yuvarlakUnlu.Contains(kelimeninSesliHarfleri[i]) && !digerSonuclar.Contains(kelimeninSesliHarfleri[i + 1]))
                    return false;
            }   
            return true;
        }

    }
}
