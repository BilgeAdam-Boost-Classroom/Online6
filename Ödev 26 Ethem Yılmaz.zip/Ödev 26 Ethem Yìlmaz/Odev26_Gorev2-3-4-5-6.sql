--GOREV 2  Order Details tablosu ile Products tablosunu inner join yaparak dicount'u s�f�rdan farkl� olanlar�n ProductName ve UnitPrice kolonlar�n� getiriniz.
SELECT ProductName , [Order Details].UnitPrice  FROM [Order Details] JOIN Products ON [Order Details].ProductID=Products.ProductID WHERE Discount != 0 ;

--G�REV 3 Products tablosu ile Suppliers tablosunu inner join yaparak Supplier'�n �ehri (city) New Orleans olanlar�n, city, companyname ve productname'lerini, productname'e g�re azalan s�rada s�ralayarak getiriniz.
SELECT City,CompanyName,ProductName FROM Products P JOIN Suppliers S ON P.SupplierID=S.SupplierID WHERE City='New Orleans' ORDER BY ProductName DESC 

--GOREV 4 TerritoryDescripttion'� Boston olan�n RegionDescription'�n�n bulunuz. (Inner join kullanarak)
SELECT r.RegionDescription FROM Region r INNER JOIN Territories t ON r.RegionID = t.RegionID WHERE t.TerritoryDescription = 'Boston';

--GOREV 5 CategoryName'i Seefood VEYA Cheeses olan VE discontinued de�eri 1 olanlar� ProductName,CategoryName ve Discontinued de�erlerini inner join ile getiriniz.
SELECT ProductName, CategoryName, Discontinued FROM Categories JOIN Products ON Categories.CategoryID=Products.CategoryID WHERE CategoryName IN ('Seefood','Cheeses') AND Discontinued = 1

--GOREV 6 Employees tablosundaki ki�ilerin adlar�n�, soyadlar�n�, rapor verdikleri �al��an�n adlar�n� ve soyadlar�n� getiriniz. (reports to kolonunu kullan�n�z). (Tabloyu kendisi ile inner join yap�n�z.)
SELECT E1.FirstName AS '�al��an Ad�',E1.LastName AS '�al��an Soyad�',E.FirstName AS 'Rapor Verilen Ad�', E.LastName AS 'Rapor Verilen Soyad�' FROM Employees E JOIN Employees E1 ON E.EmployeeID=E1.ReportsTo