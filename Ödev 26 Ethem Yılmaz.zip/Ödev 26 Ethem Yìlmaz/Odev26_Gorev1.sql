CREATE DATABASE Odev26Db
GO

USE Odev26Db
GO

CREATE TABLE Danismanlar
(
	Id INT PRIMARY KEY  IDENTITY,
	Ad NVARCHAR(50) NOT NULL,
	Soyad NVARCHAR(50) NOT NULL
)

CREATE TABLE Talebeler
(
	Id INT PRIMARY KEY IDENTITY,
	Ad NVARCHAR(50) NOT NULL,
	Soyad NVARCHAR(50)  NOT NULL,
	Dan�smanId INT FOREIGN KEY REFERENCES Danismanlar(Id)
)

INSERT INTO Danismanlar VALUES ('Ethem','Y�lmaz'),
('Beyza Nur','Y�lmaz'),
('Selma','Deliduman'),
('Neriman','�anak��');

INSERT INTO Talebeler
VALUES('Hasan','Y�lmaz',1),
('Ali','Kara',3),
('Ay�e','Y�ld�z',2),
('Mehmet','Demir',4),
('Veli','Y�ld�z',1),
('Ahmet','G�ne�',3),
('Fatma','G�l',NULL),
('Batuhan','Ate�',NULL),
('Murat','Bekta�',NULL),
('Hatice','Sa�lam',NULL)


SELECT * FROM Danismanlar JOIN Talebeler ON Danismanlar.Id=Talebeler.Dan�smanId