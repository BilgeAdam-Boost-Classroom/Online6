﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace soru2
{
    public partial class form2 : Form
    {
        List<Color> renkler = new List<Color>() { Color.AliceBlue, Color.Red, Color.Green, Color.Blue };

        public form2()
        {
            InitializeComponent();
            foreach (Color c in renkler)
            {
                cmbRenk.Items.Add(c);
            }
        }

        private void btnRenk_Click(object sender, EventArgs e)
        {
            ((Form1)Owner).BackColor = renkler[cmbRenk.SelectedIndex];
        }

        private void btnİptal_Click(object sender, EventArgs e)
        {
            Owner.BackColor = SystemColors.Control;
            Close();
        }
    }
}


