namespace soru2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRenkSec_Click(object sender, EventArgs e)
        {
            form2 form2 = new form2();
            form2.Show();
            form2.Owner = this;

        }
    }
}