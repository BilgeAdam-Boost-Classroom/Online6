﻿namespace soru2
{
    partial class form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnİptal = new Button();
            btnRenk = new Button();
            cmbRenk = new ComboBox();
            SuspendLayout();
            // 
            // btnİptal
            // 
            btnİptal.Location = new Point(196, 91);
            btnİptal.Margin = new Padding(7);
            btnİptal.Name = "btnİptal";
            btnİptal.Size = new Size(161, 57);
            btnİptal.TabIndex = 5;
            btnİptal.Text = "İPTAL";
            btnİptal.UseVisualStyleBackColor = true;
            btnİptal.Click += btnİptal_Click;
            // 
            // btnRenk
            // 
            btnRenk.Location = new Point(18, 91);
            btnRenk.Margin = new Padding(7);
            btnRenk.Name = "btnRenk";
            btnRenk.Size = new Size(164, 57);
            btnRenk.TabIndex = 4;
            btnRenk.Text = "TAMAM";
            btnRenk.UseVisualStyleBackColor = true;
            btnRenk.Click += btnRenk_Click;
            // 
            // cmbRenk
            // 
            cmbRenk.FormattingEnabled = true;
            cmbRenk.Location = new Point(18, 32);
            cmbRenk.Margin = new Padding(7);
            cmbRenk.Name = "cmbRenk";
            cmbRenk.Size = new Size(339, 45);
            cmbRenk.TabIndex = 3;
            // 
            // form2
            // 
            AutoScaleDimensions = new SizeF(16F, 37F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(379, 179);
            Controls.Add(btnİptal);
            Controls.Add(btnRenk);
            Controls.Add(cmbRenk);
            Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(7);
            Name = "form2";
            Text = "form2";
            ResumeLayout(false);
        }

        #endregion

        private Button btnİptal;
        private Button btnRenk;
        private ComboBox cmbRenk;
    }
}