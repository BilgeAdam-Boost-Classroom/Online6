﻿using Odev19;

Cihaz c1 = new Cihaz("IPHONE 15", 50000, new DateTime(2023,09,15));

c1.BilgileriGoster();



Console.ReadKey();