﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev19
{
    internal class Cihaz
    {
        Random rnd = new Random();

        public Cihaz(string ad, double fiyat, DateTime uretimTarihi)
        {

            Ad = ad;
            Fiyat = fiyat;
            UretimTarihi = uretimTarihi;


        }

        public string Ad { get; set; }
        public double Fiyat { get; set; }
        public int SeriNumarası { get { return rnd.Next(1000, 10000); } }
        public DateTime UretimTarihi {  get; set; }

        public void BilgileriGoster()
        {
            Console.WriteLine($"Ad: {Ad}");
            Console.WriteLine($"Fiyat: {Fiyat}");
            Console.WriteLine($"Üretim Tarihi: {UretimTarihi}");
            Console.WriteLine($"Seri numarası: {SeriNumarası}");
        }

    }
}
