﻿namespace Odev31
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtId = new TextBox();
            bntEkle = new Button();
            btnSil = new Button();
            txtDesc = new TextBox();
            label2 = new Label();
            label4 = new Label();
            txtRegionId = new TextBox();
            btnGnc = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 23);
            label1.Name = "label1";
            label1.Size = new Size(18, 15);
            label1.TabIndex = 0;
            label1.Text = "ID";
            // 
            // txtId
            // 
            txtId.Location = new Point(12, 41);
            txtId.Name = "txtId";
            txtId.Size = new Size(100, 23);
            txtId.TabIndex = 1;
            // 
            // bntEkle
            // 
            bntEkle.Location = new Point(136, 41);
            bntEkle.Name = "bntEkle";
            bntEkle.Size = new Size(75, 23);
            bntEkle.TabIndex = 2;
            bntEkle.Text = "Ekle";
            bntEkle.UseVisualStyleBackColor = true;
            bntEkle.Click += bntEkle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(136, 100);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(75, 23);
            btnSil.TabIndex = 3;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // txtDesc
            // 
            txtDesc.Location = new Point(12, 100);
            txtDesc.Name = "txtDesc";
            txtDesc.Size = new Size(100, 23);
            txtDesc.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 82);
            label2.Name = "label2";
            label2.Size = new Size(113, 15);
            label2.TabIndex = 7;
            label2.Text = "Territory Description";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 143);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 9;
            label4.Text = "Region ID";
            // 
            // txtRegionId
            // 
            txtRegionId.Location = new Point(12, 161);
            txtRegionId.Name = "txtRegionId";
            txtRegionId.Size = new Size(100, 23);
            txtRegionId.TabIndex = 8;
            // 
            // btnGnc
            // 
            btnGnc.Location = new Point(136, 161);
            btnGnc.Name = "btnGnc";
            btnGnc.Size = new Size(75, 23);
            btnGnc.TabIndex = 10;
            btnGnc.Text = "Guncelle";
            btnGnc.UseVisualStyleBackColor = true;
            btnGnc.Click += btnGnc_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(306, 303);
            Controls.Add(btnGnc);
            Controls.Add(label4);
            Controls.Add(txtRegionId);
            Controls.Add(label2);
            Controls.Add(txtDesc);
            Controls.Add(btnSil);
            Controls.Add(bntEkle);
            Controls.Add(txtId);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtId;
        private Button bntEkle;
        private Button btnSil;
        private Button btnGuncelle;
        private TextBox txtSoyad;
        private TextBox txtDesc;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtRegionId;
        private Button btnGnc;
    }
}
