using Odev31.Models;

namespace Odev31
{
    public partial class Form1 : Form
    {
        NorthwndContext db;
        public Form1()
        {
            InitializeComponent();
            db = new NorthwndContext();
        }

        private void bntEkle_Click(object sender, EventArgs e)
        {
            Territory territory = new Territory();
            territory.TerritoryId = txtId.Text;
            territory.RegionId = Convert.ToInt32(txtRegionId.Text);
            territory.TerritoryDescription = txtDesc.Text;

            db.Territories.Add(territory);
            db.SaveChanges();
            MessageBox.Show("Eklenmi�tir");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            int silinecekId = Convert.ToInt32(txtId.Text);

            var silinecekterritory = db.Territories.FirstOrDefault(bolge => bolge.TerritoryId == silinecekId.ToString());


            db.Territories.Remove(silinecekterritory);
            db.SaveChanges();
        }

        private void btnGnc_Click(object sender, EventArgs e)
        {

            int guncellenecekId = Convert.ToInt32(txtId.Text);

            var guncellenecekTerritory = db.Territories.FirstOrDefault(bolge => bolge.TerritoryId == guncellenecekId.ToString());

            guncellenecekTerritory.TerritoryDescription = txtDesc.Text;
            guncellenecekTerritory.RegionId = Convert.ToInt32(txtRegionId.Text);


            db.SaveChanges();

            MessageBox.Show("G�ncellenmi�tir");
        }
    }
}
