using Odev31.Models;

namespace Odev31
{
    public partial class Form1 : Form
    {
        NorthwndContext context = new NorthwndContext();
        public Form1()
        {
            InitializeComponent();
            LoadTerritories();
        }
        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            string territoryID = txtTerritoryID.Text.Trim();
            string territoryDescription = txtTerritoryDescription.Text.Trim();
            if (string.IsNullOrEmpty(territoryID) || string.IsNullOrEmpty(territoryDescription))
            {
                MessageBox.Show("Territory ID ve Territory Description alanlar� bo� olamaz.", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Territory newTerritory = new Territory
            {
                TerritoryId = territoryID,
                TerritoryDescription = territoryDescription
            };

            context.Territories.Add(newTerritory);
            context.SaveChanges();

            LoadTerritories();
            ClearForm();

        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {

            string territoryID = txtTerritoryID.Text.Trim();

            var territoryToDelete = context.Territories.FirstOrDefault(t => t.TerritoryId == territoryID);

            if (territoryToDelete != null)
            {
                context.Territories.Remove(territoryToDelete);
                context.SaveChanges();
                LoadTerritories();
                ClearForm();
            }
            else
            {
                MessageBox.Show("Silinecek Territory bulunamad�.", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string territoryID = txtTerritoryID.Text.Trim();
            string territoryDescription = txtTerritoryDescription.Text.Trim();

            if (string.IsNullOrEmpty(territoryID) || string.IsNullOrEmpty(territoryDescription))
            {
                MessageBox.Show("Territory ID ve Territory Description alanlar� bo� olamaz.", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var existingTerritory = context.Territories.FirstOrDefault(t => t.TerritoryId == territoryID);

            if (existingTerritory != null)
            {
                existingTerritory.TerritoryDescription = territoryDescription;
                context.SaveChanges();
                LoadTerritories();
                ClearForm();
            }
            else
            {
                MessageBox.Show("G�ncellenecek Territory bulunamad�.", "Uyar�", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LoadTerritories()
        {
            var territories = context.Territories.ToList();
            dgvTerritories.DataSource = territories;
        }

        private void ClearForm()
        {
            txtTerritoryID.Clear();
            txtTerritoryDescription.Clear();
        }

        private void dgvTerritories_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvTerritories.Rows[e.RowIndex];
                txtTerritoryID.Text = row.Cells["TerritoryID"].Value.ToString();
                txtTerritoryDescription.Text = row.Cells["TerritoryDescription"].Value.ToString();
            }
        }
    }
}


