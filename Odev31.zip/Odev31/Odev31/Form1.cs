using Odev31.Models;

namespace Odev31
{
    public partial class Form1 : Form
    {
        NorthwndContext db = new NorthwndContext();
        public Form1()
        {
            InitializeComponent();
        }


        private void btnEkle_Click(object sender, EventArgs e)
        {
            Territory territory = new Territory();
            territory.TerritoryId = txtTerritoryId.Text;
            territory.TerritoryDescription = txtTerritoryDescription.Text;
            territory.RegionId = (int)nudRegionId.Value;

            db.Territories.Add(territory);
            db.SaveChanges();
            MessageBox.Show("Territory eklenmi�tir.");
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            string id = txtTerritoryId.Text;
            Territory guncellenecekTerritory = db.Territories.FirstOrDefault(t => t.TerritoryId == id);

            guncellenecekTerritory.TerritoryDescription = txtTerritoryDescription.Text;
            guncellenecekTerritory.RegionId = (int)nudRegionId.Value;
            db.SaveChanges();
            MessageBox.Show("Territory g�ncellenmi�tir.");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            string id = txtTerritoryId.Text;
            Territory silinecekTerritory = db.Territories.FirstOrDefault(t => t.TerritoryId == id);
            db.Territories.Remove(silinecekTerritory);
            db.SaveChanges();
            MessageBox.Show("Territory silinmi�tir.");
        }
    }
}
