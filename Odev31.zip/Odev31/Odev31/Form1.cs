using Odev31.Models;

namespace Odev31
{
    public partial class Form1 : Form
    {
        NorthwndContext db;
        public Form1()
        {
            InitializeComponent();
            db = new NorthwndContext();
            VerileriYukle();
        }

        private void VerileriYukle()
        {
            dgvTerritories.DataSource = db.Territories.ToList();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text) || string.IsNullOrEmpty(txtAd.Text) || string.IsNullOrEmpty(txtBolgeId.Text))
            {
                MessageBox.Show("L�tfen t�m alanlar� uygun �ekilde doldurunuz.");
                return;
            }
            Territory territory = new Territory();
            territory.TerritoryId = txtId.Text;
            territory.TerritoryDescription = txtAd.Text;
            territory.RegionId = Convert.ToInt32(txtBolgeId.Text);

            db.Territories.Add(territory);
            db.SaveChanges();
            MessageBox.Show("Yeni Territory Eklendi.");
            VerileriYukle();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("L�tfen silmek istedi�iniz Id'yi giriniz.");
                return;
            }
            var territoryId = txtId.Text.Trim();
            var territory = db.Territories.FirstOrDefault(t => t.TerritoryId == territoryId);

            if (territory != null)
            {
                db.Territories.Remove(territory);
                MessageBox.Show("Territory Silindi.");
                db.SaveChanges();
            }
            VerileriYukle();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("L�tfen g�ncellemek istedi�iniz Id'yi giriniz.");
                return;
            }
            var territoryId = txtId.Text.Trim();
            var territory = db.Territories.FirstOrDefault(t => t.TerritoryId == territoryId);
            territory.TerritoryDescription = txtAd.Text;
            territory.RegionId = Convert.ToInt32(txtBolgeId.Text);
            db.SaveChanges();
            VerileriYukle();
        }
    }
}
