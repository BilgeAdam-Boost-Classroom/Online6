using Odev31.Models;
using System.Drawing;

namespace Odev31
{
    public partial class Form1 : Form
    {
        NorthwndContext db;
        //List<int> idList;
        string idListMessage;
        Territory territory;
        int regionId;
        public Form1()
        {
            InitializeComponent();
            db = new NorthwndContext();
        }
        private bool TerritoryIdVarMi(string id)
        {
            for (int i = 0; i < db.Territories.ToList().Count; i++)
            {
                if (id == db.Territories.ToList()[i].TerritoryId) 
                { 
                    territory= db.Territories.ToList()[i];
                    return true;
                }
            }
            return false;
        }


        private bool RegionIdVarMi(int regionId)
        {
            //idList = new List<int>();
            idListMessage = string.Empty;

            for (int i = 0; i < db.Regions.ToList().Count; i++)
            {
                if (regionId == db.Regions.ToList()[i].RegionId)
                    return true;
            }

            for (int i = 0; i < db.Regions.ToList().Count; i++)
            {
                idListMessage += $"{db.Regions.ToList()[i].RegionId,-3}{db.Regions.ToList()[i].RegionDescription}\n";
            }

            return false;
        }



        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim() == "" || txtDescription.Text.Trim() == "" || txtRegionId.Text == "" || txtId.Text.Trim().Length > 20 || txtDescription.Text.Trim().Length > 50)
            {
                MessageBox.Show("T�m alanlar� uygun �ekilde doldurunuz.");
                return;
            }

            int regionId;

            if (!int.TryParse(txtRegionId.Text, out regionId))
            {
                MessageBox.Show("RegionId b�l�m�ne say� girin");
                return;
            }



            if (TerritoryIdVarMi(txtId.Text.Trim()))
            {
                MessageBox.Show("Girilen TerritoryId mevcut.");
                return;
            }




            if (!RegionIdVarMi(regionId))
            {
                MessageBox.Show("Ge�ersiz RegionId girdiniz.\n\nRegions Listesi:\n" + idListMessage);
                return;
            }

            db.Territories.Add(new Territory() { TerritoryId = txtId.Text, TerritoryDescription = txtDescription.Text, RegionId = regionId });
            db.SaveChanges();
            MessageBox.Show("Eklenmi�tir");

        }


        private void btnSil_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim() == "" || txtId.Text.Trim().Length > 20)
            {
                MessageBox.Show("Id alan�n� doldurunuz.");
                return;
            }

            territory = db.Territories.Find(txtId.Text);

            if (territory == null)
            {
                MessageBox.Show("Bulunamad�");
                return;
            }

            db.Territories.Remove(territory);
            db.SaveChanges();
            MessageBox.Show("Silinmi�tir");
        }

        private void btnDuzenle_Click(object sender, EventArgs e)
        {
            if (txtId.Text.Trim() == "" || txtDescription.Text.Trim() == "" || txtRegionId.Text == "" || txtId.Text.Trim().Length > 20 || txtDescription.Text.Trim().Length > 50)
            {
                MessageBox.Show("T�m alanlar� uygun �ekilde doldurunuz.");
                return;
            }

            //int regionId;

            if (!int.TryParse(txtRegionId.Text, out regionId))
            {
                MessageBox.Show("RegionId b�l�m�ne say� girin");
                return;
            }

            if (!RegionIdVarMi(regionId))
            {
                MessageBox.Show("Ge�ersiz RegionId girdiniz.\n\nRegions Listesi:\n" + idListMessage);
                return;
            }

            territory = db.Territories.Find(txtId.Text);

            if (territory == null)
            {
                MessageBox.Show("Bulunamad�");
                return;
            }

            territory.TerritoryDescription = txtDescription.Text;
            territory.RegionId = regionId;
            db.SaveChanges();
            MessageBox.Show("D�zenlenmi�tir");
        }

        private void btnGetir_Click(object sender, EventArgs e)
        {
            if (!TerritoryIdVarMi(txtId.Text.Trim()))
            {
                MessageBox.Show("Girilen TerritoryId bulunamad�");
                return;
            }

            txtDescription.Text = territory.TerritoryDescription;
            txtRegionId.Text=territory.RegionId.ToString();
        }
    }
}
