﻿using System;
using System.Collections.Generic;

namespace Odev31.Models;

public partial class CondimentsOfTop5FindAndList
{
    public int ProductId { get; set; }

    public string UrunAdi { get; set; } = null!;

    public string TedarikciAdi { get; set; } = null!;
}
