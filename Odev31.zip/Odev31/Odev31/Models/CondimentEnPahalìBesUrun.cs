﻿using System;
using System.Collections.Generic;

namespace Odev31.Models;

public partial class CondimentEnPahalıBesUrun
{
    public string ProductName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }

    public string CompanyName { get; set; } = null!;
}
