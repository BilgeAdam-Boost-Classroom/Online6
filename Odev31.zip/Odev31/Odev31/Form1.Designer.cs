﻿namespace Odev31
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtTerritoryId = new TextBox();
            label2 = new Label();
            txtTerritoryDescription = new TextBox();
            label3 = new Label();
            btnEkle = new Button();
            btnGuncelle = new Button();
            btnSil = new Button();
            nudRegionId = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)nudRegionId).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(80, 20);
            label1.Name = "label1";
            label1.Size = new Size(103, 21);
            label1.TabIndex = 0;
            label1.Text = "Territory Id :";
            // 
            // txtTerritoryId
            // 
            txtTerritoryId.Location = new Point(189, 12);
            txtTerritoryId.Name = "txtTerritoryId";
            txtTerritoryId.Size = new Size(162, 29);
            txtTerritoryId.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 68);
            label2.Name = "label2";
            label2.Size = new Size(172, 21);
            label2.TabIndex = 0;
            label2.Text = "TerritoryDescription :";
            // 
            // txtTerritoryDescription
            // 
            txtTerritoryDescription.Location = new Point(189, 61);
            txtTerritoryDescription.Name = "txtTerritoryDescription";
            txtTerritoryDescription.Size = new Size(162, 29);
            txtTerritoryDescription.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(84, 120);
            label3.Name = "label3";
            label3.Size = new Size(89, 21);
            label3.TabIndex = 0;
            label3.Text = "RegionID :";
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(84, 182);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(222, 34);
            btnEkle.TabIndex = 2;
            btnEkle.Text = "Territory ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(84, 234);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(222, 34);
            btnGuncelle.TabIndex = 2;
            btnGuncelle.Text = "Territory güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(84, 292);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(222, 34);
            btnSil.TabIndex = 2;
            btnSil.Text = "Territory sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // nudRegionId
            // 
            nudRegionId.Location = new Point(189, 112);
            nudRegionId.Name = "nudRegionId";
            nudRegionId.Size = new Size(120, 29);
            nudRegionId.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(401, 391);
            Controls.Add(nudRegionId);
            Controls.Add(btnSil);
            Controls.Add(btnGuncelle);
            Controls.Add(btnEkle);
            Controls.Add(txtTerritoryDescription);
            Controls.Add(txtTerritoryId);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Territories";
            ((System.ComponentModel.ISupportInitialize)nudRegionId).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtTerritoryId;
        private Label label2;
        private TextBox txtTerritoryDescription;
        private Label label3;
        private Button btnEkle;
        private Button btnGuncelle;
        private Button btnSil;
        private NumericUpDown nudRegionId;
    }
}
