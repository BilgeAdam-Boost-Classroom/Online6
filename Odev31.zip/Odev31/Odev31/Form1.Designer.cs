﻿namespace Odev31
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtId = new TextBox();
            txtDescription = new TextBox();
            txtRegionId = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnEkle = new Button();
            btnSil = new Button();
            btnDuzenle = new Button();
            btnGetir = new Button();
            SuspendLayout();
            // 
            // txtId
            // 
            txtId.Location = new Point(190, 62);
            txtId.Name = "txtId";
            txtId.Size = new Size(125, 27);
            txtId.TabIndex = 0;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(190, 121);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(125, 27);
            txtDescription.TabIndex = 1;
            // 
            // txtRegionId
            // 
            txtRegionId.Location = new Point(190, 179);
            txtRegionId.Name = "txtRegionId";
            txtRegionId.Size = new Size(125, 27);
            txtRegionId.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(44, 69);
            label1.Name = "label1";
            label1.Size = new Size(77, 20);
            label1.TabIndex = 3;
            label1.Text = "TerritoryId";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(44, 128);
            label2.Name = "label2";
            label2.Size = new Size(140, 20);
            label2.TabIndex = 4;
            label2.Text = "TerritoryDescription";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(44, 186);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 5;
            label3.Text = "RegionId";
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(44, 253);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 6;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(144, 253);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(94, 29);
            btnSil.TabIndex = 7;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnDuzenle
            // 
            btnDuzenle.Location = new Point(244, 253);
            btnDuzenle.Name = "btnDuzenle";
            btnDuzenle.Size = new Size(94, 29);
            btnDuzenle.TabIndex = 8;
            btnDuzenle.Text = "Düzenle";
            btnDuzenle.UseVisualStyleBackColor = true;
            btnDuzenle.Click += btnDuzenle_Click;
            // 
            // btnGetir
            // 
            btnGetir.Location = new Point(344, 60);
            btnGetir.Name = "btnGetir";
            btnGetir.Size = new Size(94, 29);
            btnGetir.TabIndex = 9;
            btnGetir.Text = "Getir";
            btnGetir.UseVisualStyleBackColor = true;
            btnGetir.Click += btnGetir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(450, 363);
            Controls.Add(btnGetir);
            Controls.Add(btnDuzenle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtRegionId);
            Controls.Add(txtDescription);
            Controls.Add(txtId);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtId;
        private TextBox txtDescription;
        private TextBox txtRegionId;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnEkle;
        private Button btnSil;
        private Button btnDuzenle;
        private Button btnGetir;
    }
}
