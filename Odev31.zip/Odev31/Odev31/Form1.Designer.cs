﻿namespace Odev31
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtId = new TextBox();
            txtAd = new TextBox();
            txtBolgeId = new TextBox();
            label3 = new Label();
            btnEkle = new Button();
            btnSil = new Button();
            btnGuncelle = new Button();
            dgvTerritories = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvTerritories).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 104);
            label1.Name = "label1";
            label1.Size = new Size(92, 25);
            label1.TabIndex = 0;
            label1.Text = "TerritoryId";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 198);
            label2.Name = "label2";
            label2.Size = new Size(171, 25);
            label2.TabIndex = 1;
            label2.Text = "Territory Description";
            // 
            // txtId
            // 
            txtId.Location = new Point(24, 132);
            txtId.Name = "txtId";
            txtId.Size = new Size(270, 31);
            txtId.TabIndex = 2;
            // 
            // txtAd
            // 
            txtAd.Location = new Point(24, 226);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(270, 31);
            txtAd.TabIndex = 3;
            // 
            // txtBolgeId
            // 
            txtBolgeId.Location = new Point(24, 315);
            txtBolgeId.Name = "txtBolgeId";
            txtBolgeId.Size = new Size(270, 31);
            txtBolgeId.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 287);
            label3.Name = "label3";
            label3.Size = new Size(83, 25);
            label3.TabIndex = 4;
            label3.Text = "RegionId";
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(24, 392);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(270, 49);
            btnEkle.TabIndex = 6;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(24, 447);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(270, 49);
            btnSil.TabIndex = 7;
            btnSil.Text = "Sil";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(24, 502);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(270, 49);
            btnGuncelle.TabIndex = 8;
            btnGuncelle.Text = "Güncelle";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // dgvTerritories
            // 
            dgvTerritories.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTerritories.Location = new Point(369, 12);
            dgvTerritories.Name = "dgvTerritories";
            dgvTerritories.RowHeadersWidth = 62;
            dgvTerritories.Size = new Size(599, 684);
            dgvTerritories.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(980, 708);
            Controls.Add(dgvTerritories);
            Controls.Add(btnGuncelle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(txtBolgeId);
            Controls.Add(label3);
            Controls.Add(txtAd);
            Controls.Add(txtId);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvTerritories).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtId;
        private TextBox txtAd;
        private TextBox txtBolgeId;
        private Label label3;
        private Button btnEkle;
        private Button btnSil;
        private Button btnGuncelle;
        private DataGridView dgvTerritories;
    }
}
