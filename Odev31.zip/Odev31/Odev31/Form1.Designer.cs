﻿namespace Odev31
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvTerritories = new DataGridView();
            txtTerritoryID = new TextBox();
            txtTerritoryDescription = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btnAdd = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvTerritories).BeginInit();
            SuspendLayout();
            // 
            // dgvTerritories
            // 
            dgvTerritories.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTerritories.Location = new Point(45, 160);
            dgvTerritories.Name = "dgvTerritories";
            dgvTerritories.RowHeadersWidth = 62;
            dgvTerritories.Size = new Size(701, 474);
            dgvTerritories.TabIndex = 0;
            dgvTerritories.CellClick += dgvTerritories_CellClick;
            // 
            // txtTerritoryID
            // 
            txtTerritoryID.Location = new Point(224, 39);
            txtTerritoryID.Name = "txtTerritoryID";
            txtTerritoryID.Size = new Size(522, 31);
            txtTerritoryID.TabIndex = 1;
            // 
            // txtTerritoryDescription
            // 
            txtTerritoryDescription.Location = new Point(224, 91);
            txtTerritoryDescription.Multiline = true;
            txtTerritoryDescription.Name = "txtTerritoryDescription";
            txtTerritoryDescription.Size = new Size(522, 38);
            txtTerritoryDescription.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 45);
            label1.Name = "label1";
            label1.Size = new Size(111, 25);
            label1.TabIndex = 3;
            label1.Text = "Territories ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 104);
            label2.Name = "label2";
            label2.Size = new Size(183, 25);
            label2.TabIndex = 4;
            label2.Text = "Territories Description";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(396, 653);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(112, 34);
            btnAdd.TabIndex = 5;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click_1;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(514, 653);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(112, 34);
            btnDelete.TabIndex = 6;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click_1;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(632, 653);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(112, 34);
            btnUpdate.TabIndex = 7;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(939, 803);
            Controls.Add(btnUpdate);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtTerritoryDescription);
            Controls.Add(txtTerritoryID);
            Controls.Add(dgvTerritories);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvTerritories).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvTerritories;
        private TextBox txtTerritoryID;
        private TextBox txtTerritoryDescription;
        private Label label1;
        private Label label2;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnUpdate;
    }
}
