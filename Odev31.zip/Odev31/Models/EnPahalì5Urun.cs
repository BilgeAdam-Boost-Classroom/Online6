﻿using System;
using System.Collections.Generic;

namespace Odev31.Models;

public partial class EnPahalı5Urun
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;

    public string CompanyName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }
}
