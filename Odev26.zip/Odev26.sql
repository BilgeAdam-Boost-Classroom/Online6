--SORU 1-)
USE master;
GO

DROP DATABASE IF EXISTS Odev26Db;
GO

CREATE DATABASE Odev26Db;
GO

USE Odev26Db;
GO

CREATE TABLE Danismanlar
(
  Id INT PRIMARY KEY IDENTITY(1,1),
  Ad NVARCHAR(50) NOT NULL,
  Soyad NVARCHAR(50) NOT NULL,
);
GO

CREATE TABLE Talebeler
(
  Id INT PRIMARY KEY IDENTITY(1,1),
  Ad NVARCHAR(50) NOT NULL,
  Soyad NVARCHAR(50) NOT NULL,
  DanismanId INT FOREIGN KEY REFERENCES Danismanlar(Id) NULL
);
GO

INSERT INTO Danismanlar (Ad, Soyad) VALUES 
(N'Filiz', N'Umaro�ullar�'),
(N'Semiha', N'Kartal'),
(N'Hatice', N'K�ran �ak�r'),
(N'Ertan', N'Varl�'),
(N'Berk', N'Minez');

INSERT INTO Talebeler (Ad, Soyad, DanismanId) VALUES 
(N'�layda', N'Y�ld�z', 1),
(N'Selinay', N'Y�ld�z', NULL),
(N'Ahmet Berkay', N'Ak�n', 1),
(N'Tu�yan', N'Ok', 2),
(N'Cem', N'Do�ru', NULL),
(N'Kaan', N'Geni�', 4),
(N'Serenay', N'Kozuva', 5),
(N'Adem Hakan', N'Kozuva', NULL),
(N'Dilan', N'�ak�r', 2),
(N'G�lcan', N'K�eso�lu', 3);

SELECT * FROM Talebeler INNER JOIN Danismanlar ON Talebeler.DanismanId = Danismanlar.Id;

--SORU 2-)
USE NORTHWND;
GO

SELECT Products.ProductName , Products.UnitPrice  FROM [Order Details] INNER JOIN Products ON [Order Details].ProductID = Products.ProductID 
WHERE [Order Details].Discount <> 0;

--SORU 3-)
SELECT Suppliers.City, Suppliers.CompanyName, Products.ProductName
FROM Products
INNER JOIN Suppliers ON Products.SupplierID = Suppliers.SupplierID
WHERE Suppliers.City = N'New Orleans'
ORDER BY Products.ProductName;

--SORU 4-)
SELECT * FROM Territories INNER JOIN Region ON Territories.RegionID = Region.RegionID
WHERE TerritoryDescription = 'Boston';

--SORU 5-)
SELECT Products.ProductName, Categories.CategoryName, Products.Discontinued FROM Products
INNER JOIN Categories ON Products.CategoryID = Categories.CategoryID
WHERE (Categories.CategoryName = 'Seefood' OR Categories.CategoryName = 'Cheeses') AND Products.Discontinued = 1;

--SORU 6-)
SELECT [Calisanlar].FirstName, [Calisanlar].LastName, [Sorumlular].FirstName, [Sorumlular].LastName  FROM Employees[Calisanlar] INNER JOIN Employees[Sorumlular] ON[Sorumlular].ReportsTo = [Calisanlar].EmployeeID 