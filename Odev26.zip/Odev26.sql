-- 1 -----------
use master

drop database if exists Odev25Db
go
create database Odev25Db
go
use Odev25Db

create table Danismanlar(
Id int primary key identity(1,1),
Ad nvarchar(50) not null,
Soyad nvarchar(50) not null)


create table Talebeler(
Id int primary key identity(1,1),
Ad nvarchar(50) not null,
Soyad nvarchar(50) not null,
DanismanId int foreign key references Danismanlar(Id) null )

insert into Danismanlar(Ad,Soyad)
values ('D1Ad','D1Soyad'),('D2Ad','D2Soyad'),('D3Ad','D3Soyad'),('D4Ad','D4Soyad'),('D5Ad','D5Soyad')

insert into Talebeler(Ad,Soyad,DanismanId)
values ('T1Ad','T1Soyad',2),('T2Ad','T2Soyad',null),('T3Ad','T3Soyad',3),('T4Ad','T4Soyad',1),('T5Ad','T5Soyad',null),
	   ('T6Ad','T6Soyad',null),('T7Ad','T7Soyad',null),('T8Ad','T8Soyad',5),('T9Ad','T9Soyad',4),('T10Ad','T10Soyad',null)

select t.Ad,t.Soyad,d.Ad,d.Soyad
from Talebeler t
join Danismanlar d on DanismanId=d.Id
where DanismanId is not null


--  2  ----------

select ProductName, o.UnitPrice,p.UnitPrice
from [Order Details] o
join Products p on o.ProductID=p.ProductID
where Discount !=0


--  3  ----------

select City,CompanyName,ProductName 
from Products p
join Suppliers s on p.SupplierID=s.SupplierID
where s.City='new orleans'
order by ProductName desc

--  4  -----------

select RegionDescription
from Territories t
join Region r on t.RegionID=r.RegionID
where TerritoryDescription='boston'

--  5  --------------

select ProductName,CategoryName,Discontinued
from Products p
join Categories c on p.CategoryID=c.CategoryID
where CategoryName in('seafood' , 'dairy products') and Discontinued=1


--  6  --------------

select e1.FirstName,e1.LastName,e2.FirstName,e2.LastName
from Employees e1
join Employees e2 on e1.ReportsTo= e2.EmployeeID 
