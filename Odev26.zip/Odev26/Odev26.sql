﻿-- SORU 1
USE master;
GO
DROP DATABASE IF EXISTS Odev26;

CREATE DATABASE Odev26;
GO

USE Odev26;
GO

CREATE TABLE Danismanlar
(
	Id INT PRIMARY KEY IDENTITY,
	Ad NVARCHAR(50) NOT NULL,
	Soyad NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Talebeler
(
	Id INT PRIMARY KEY IDENTITY,
	Ad NVARCHAR(50) NOT NULL,
	Soyad NVARCHAR(50) NOT NULL,
	DanismanId INT FOREIGN KEY REFERENCES Danismanlar(Id) NULL
);
GO

INSERT INTO Danismanlar(Ad, Soyad) VALUES
(N'Ali', N'Yıldız'),
(N'Ahmet', N'Yılmaz'),
(N'Veli', N'Yücel'),
(N'Ayşe', N'Doğan');


INSERT INTO Talebeler(Ad, Soyad, DanismanId) VALUES
(N'Can', N'Şahin', 1),
(N'Cem', N'Kara', NULL),
(N'Hasan', N'Balta', 4),
(N'Hüseyin', N'Yaşar', 2),
(N'Eda', N'Gül', NULL),
(N'Gül', N'Çiçek', 2),
(N'Çiğdem', N'Ertürk', NULL),
(N'Furkan', N'Çiftçi' , 3),
(N'Kutay', N'Şahin', 1),
(N'Mehmet', N'Aydemir', 1);

SELECT Talebeler.Ad, Talebeler.Soyad, Danismanlar.Ad, Danismanlar.Soyad FROM Talebeler RIGHT JOIN Danismanlar ON Talebeler.DanismanId = Danismanlar.Id

-- SORU 2
USE NORTHWND;

SELECT ProductName,Products.UnitPrice FROM [Order Details] JOIN Products ON [Order Details].ProductID = Products.ProductID WHERE Discount != 0

-- SORU 3
SELECT City, CompanyName, ProductName, UnitPrice 
FROM Products JOIN Suppliers 
ON Products.SupplierID = Suppliers.SupplierID 
WHERE Suppliers.City = 'New Orleans'

-- SORU 4
SELECT RegionDescription FROM Territories JOIN Region ON Territories.RegionID = Region.RegionID WHERE TerritoryDescription = 'Boston'

-- SORU 5
SELECT ProductName, CategoryName, Discontinued, Description FROM Products JOIN Categories ON Products.CategoryID = Categories.CategoryID WHERE CategoryName = 'Seafood' OR CAST(Description AS NVARCHAR(50)) = 'Cheeses' AND Discontinued = 1

-- SORU 6
SELECT CONCAT(E1.FirstName,' ', E1.LastName) [Çalışan], CONCAT(E2.FirstName,' ', E2.LastName) [Rapor Verdiği Kişi] FROM Employees E1 LEFT JOIN Employees E2 ON E1.ReportsTo = E2.EmployeeID