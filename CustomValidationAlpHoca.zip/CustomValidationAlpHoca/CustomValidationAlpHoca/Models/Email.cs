﻿using CustomValidationAlpHoca.Attributes;
using System.ComponentModel.DataAnnotations;

namespace CustomValidationAlpHoca.Models
{
    public class Email
    {
        [Required(ErrorMessage = "Alan boş kalamaz , Lütfen email adresinizi giriniz!")]
        [GecersizEmail]
        public string EmailAdresi { get; set; } = null!;
    }
}
