﻿using CustomValidationAlpHoca.Attributes;
using System.ComponentModel.DataAnnotations;

namespace CustomValidationAlpHoca.Models
{
    public class Kullanici
    {
        [Required(ErrorMessage = "Kullanıcı adı boş bırakılamaz!")]
        public string Ad { get; set; } = null!;

        [Required(ErrorMessage = "Sicil Numarası boş bırakılamaz!")]
        [MaxLength(8, ErrorMessage = "Sicil numarası 8 karakterden oluşmalıdır!")]
        [GecersizSicil]
        public string SicilNo { get; set; } = null!;
    }
}
