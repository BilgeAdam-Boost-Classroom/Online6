﻿using CustomValidationAlpHoca.Models;
using Microsoft.AspNetCore.Mvc;

namespace CustomValidationAlpHoca.Controllers
{
    public class KisiController : Controller
    {
        public IActionResult Kaydet()
        {
            return View();
        }
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Kaydet(Kullanici kullanici)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Index", "Home",new {islem = "basarili"});
            }
            return View();
        }
    }
}
