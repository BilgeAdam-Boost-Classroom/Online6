﻿using System.ComponentModel.DataAnnotations;

namespace CustomValidationAlpHoca.Attributes
{
    public class GecersizSicil : ValidationAttribute
    {
        public GecersizSicil()
        {
            ErrorMessage = "Geçersiz Sicil Numarasi";
        }

        public override bool IsValid(object? value)
        {
            //if (value == null)
            //    return false;

            string sicilNo = value.ToString();

            if (sicilNo.Length != 8)
                return false;

            if (sicilNo[0] != 'A' || sicilNo[0] != 'a')
                return false;

            string sonIkiBasamak = sicilNo.Substring(6, 2);
            if (!int.TryParse(sonIkiBasamak, out int ikiBasamakliSayi))
                return false;

            return ikiBasamakliSayi % 5 == 0;
        }
    }
}
