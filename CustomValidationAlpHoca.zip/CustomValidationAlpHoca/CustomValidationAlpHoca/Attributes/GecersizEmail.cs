﻿using System.ComponentModel.DataAnnotations;

namespace CustomValidationAlpHoca.Attributes
{
    public class GecersizEmail:ValidationAttribute
    {
        public GecersizEmail()
        {
            ErrorMessage = "Geçerli bir email adresi giriniz, E-posta adresi @bilgeadam.com ile bitmelidir.";
        }

        public override bool IsValid(object? value)
        {
            if (value == null)
            {
                return false;
            }
            string email = value.ToString();
            return email.EndsWith("@bilgeadam.com");
        }
    }
}
