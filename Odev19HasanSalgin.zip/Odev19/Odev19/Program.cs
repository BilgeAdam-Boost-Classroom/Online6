﻿
using Odev19;

Cihaz c1 = new Cihaz("Acer gaming laptop AN-515",29.999m,DateTime.Now);

// c1.SeriNumarasi = -999; //işleyiş nasıl?

c1.SeriNumarasiUret();  // yoruma al
c1.BilgileriniGoster();




















Console.ReadKey();
