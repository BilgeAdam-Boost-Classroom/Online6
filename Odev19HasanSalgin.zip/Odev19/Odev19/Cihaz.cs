﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev19
{
    public class Cihaz
    {
        public Cihaz(string isim,decimal fiyatim,DateTime uT) 
        {
            Console.WriteLine("YENİ BİR CİHAZ OLUŞUYOR...");
            Ad = isim;
            Fiyat=fiyatim;
            UretimTarihi = uT;
        }
        public string Ad { get; set; }

        public decimal Fiyat { get; set; }

        public DateTime UretimTarihi { get; set; }

        private int _seriNumarasi;

        //public int SeriNumarasi
        //{
        //    get { return _seriNumarasi; }
        //    set
        //    {
        //        Random rnd = new Random();
        //        value = rnd.Next(1000, 10000);
        //        _seriNumarasi = value;
        //    }
        //}

        public void BilgileriniGoster()
        {
            Console.WriteLine("cihaz adı: " + Ad);
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine($"cihaz fiyatı: {Fiyat:c3}" );
            Console.WriteLine("cihaz üretim tarihi: " + UretimTarihi);
            Console.WriteLine("cihaz seri numarası: " + _seriNumarasi);
        }

        public void SeriNumarasiUret()
        {
            Random rnd = new Random();
            _seriNumarasi = rnd.Next(1000, 10000);
        }

    }
}
