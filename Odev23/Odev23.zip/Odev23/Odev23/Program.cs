﻿namespace Odev23
{
    internal class Program
    {

        static void Main(string[] args)
        {

            int calisanSayisi = 5;

            for (int i = 0; i < calisanSayisi; i++)
            {
                Calisan a = new Calisan();
                a.AnahtarlikKazandiMi += KazandiMi;

                Console.WriteLine((i + 1) + ". Çalışanın ilk çektiği anahtarlık");
                Console.WriteLine("Malzemesi: " + a.secilen1);
                Console.WriteLine((i + 1) + ". Çalışan ikinci anahtarlığı çekti");
                a.Kontrol();
                Console.WriteLine("İkinci çekdiğinin malzemesi: " + a.secilen2);
                Console.WriteLine("--------------------------------------------------");
            }

            Console.ReadLine();
        }

        private static void KazandiMi(Calisan calisan)
        {
            if (calisan.secilen1 != calisan.secilen2)
            {
                Console.WriteLine("Malzeme Değişti! " + calisan.secilen1 + " ==> " + calisan.secilen2);
                Console.WriteLine("Hediyeyi Kazandınız :)");
            }
        }
    }
}