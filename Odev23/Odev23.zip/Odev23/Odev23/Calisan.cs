﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 Anahtarlık üreten bir fabrikanın sahibi yılın bazı aylarında çalışanlarına hediye vermektedir. Hediye vereceği çalışana şu şekilde karar vermektedir:
Cam ve seramik olmak üzere 2 adet anahtarlıktan birisini bakmadan çekmesini istemektedir. Sonra yine bakmadan başka 2 adet cam ve seramik olan anahtarlardan birisini çekmesini istemektedir. İlk çektiği anahtarlığın malzemesi ikinci çektiği anahtarlığın malzemesinden farklı ise hediyeyi alma hakkına sahip olmaktadır.
Bu bilgilere göre 5 adet çalışan için çektikleri anahtarlıkların malzemelerini yazdıran, hediye kazandıysa kazandığını yazdıran bir console uygulaması yazınız.
NOT: Sınıf, enum, delegate ve event tasarımları size aittir.
 */


namespace Odev23
{
    public delegate void AnahtarlikKazanan(Calisan calisan);
    public class Calisan
    {
        public event AnahtarlikKazanan? AnahtarlikKazandiMi;

        public Calisan()
        {
            AnahtarlikSec();
        }

        public Malzeme secilen1;
        public Malzeme secilen2;

        public void AnahtarlikSec()
        {
            Random rnd = new Random();
            secilen1 = (Malzeme)rnd.Next(2);
            secilen2 = (Malzeme)rnd.Next(2);
        }

        public void Kontrol()
        {
            AnahtarlikKazandiMi(this);
        }


    }
}
