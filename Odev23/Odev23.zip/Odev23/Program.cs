﻿using Odev23;

class Program
{
    static void Main()
    {
        for (int i = 1; i <= 5; i++)
        {
            Calisan calisan = new Calisan($"Çalışan {i}");

            calisan.AnahtarlikCekildi += (malzeme) =>
            {
                Console.WriteLine($"{calisan.Ad} adlı çalışan {malzeme} malzemeli anahtarlık çekti.");
            };

            calisan.AnahtarlikCek();
            Console.WriteLine();
        }

        Console.ReadKey();
    }
}