﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev23
{
    public delegate void AnahtarlikCekildiHandler(Malzeme malzeme);
    public class Calisan
    {
        public string Ad { get; set; }
        public event AnahtarlikCekildiHandler AnahtarlikCekildi;

        public Calisan(string ad)
        {
            Ad = ad;
        }

        public void AnahtarlikCek()
        {
            Random random = new Random();
            Malzeme ilkAnahtarlik = (Malzeme)random.Next(0, 2);
            Malzeme ikinciAnahtarlik = (Malzeme)random.Next(0, 2);

            OnAnahtarlikCekildi(ilkAnahtarlik);
            OnAnahtarlikCekildi(ikinciAnahtarlik);

            if (ilkAnahtarlik != ikinciAnahtarlik)
            {
                Console.WriteLine($"{Ad} adlı çalışan hediye kazandı!");
            }
            else
            {
                Console.WriteLine($"{Ad} adlı çalışan hediye kazanamadı.");
            }
        }

        protected virtual void OnAnahtarlikCekildi(Malzeme malzeme)
        {
            AnahtarlikCekildi?.Invoke(malzeme);
        }
    }
}
