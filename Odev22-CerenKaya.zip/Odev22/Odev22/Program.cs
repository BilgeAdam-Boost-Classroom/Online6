﻿namespace Odev22
{
    delegate double Calculate(params double[] numbers);
    internal class Program
    {
        static void Main(string[] args)
        {
            //Calculate delege = new Calculate(Toplama);   //deneme
            //Console.WriteLine(delege(2, 3, 4, 5, 7));

            //delege += Carpim;
            //Console.WriteLine(delege(2, 3, 4));


            Console.WriteLine(Islem(Toplama, 2, 3, 4, 5, 6, 7));
            Console.WriteLine(Islem(Cikarma, 10, 2, 5, 1));
            Console.WriteLine(Islem(Carpim, 2, 2, 4));
            Console.ReadKey();

        }

        static double Toplama(params double[] sayilar)
        {
            double toplam = 0;
            foreach (var sayi in sayilar)
            {
                toplam += sayi;
            }
            return toplam;
        }

        static double Cikarma(params double[] sayilar)
        {

            for (int i = 1; i < sayilar.Length; i++)
            {
                sayilar[0] -= sayilar[i];
            }
            return sayilar[0];

        }

        static double Carpim(params double[] sayilar)
        {
            double carpim = 1;
            for (int i = 0; i < sayilar.Length; i++)
            {
                carpim *= sayilar[i];
            }

            return carpim;
        }

        static double Islem(Calculate YerineGececekMetot, params double[] sayilar) // işlem adında metot ile delege kullanarak istenilen                                                                               metot için istenilen kadar sayi girişi tek bir metot                                                                             ile sağlandı. 
        {
            return YerineGececekMetot(sayilar);


        }

    }
}
