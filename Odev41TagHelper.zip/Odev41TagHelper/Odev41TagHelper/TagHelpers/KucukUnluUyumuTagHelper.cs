﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Odev41TagHelper.TagHelpers
{
    public class KucukUnluUyumuTagHelper : TagHelper
    {
        public string Kelime { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Content.SetContent(KucukUnluUyumu() ? "Kelime küçük ünlü uyumuna uygundur." : "Kelime küçük ünlü uyumuna uymamaktadır.");
        }

        private bool KucukUnluUyumu()
        {
            if (string.IsNullOrEmpty(Kelime) || Kelime.Length < 2)
                return false;

            string harflerAeiI = "aeıi";
            string harflerOeuU = "oöeuü";

            string sesli = new string(Kelime.Where(x => (harflerAeiI + harflerOeuU).Contains(x)).ToArray());

            for (int i = 0; i < sesli.Length - 1; i++)
            {
                if (harflerAeiI.Contains(sesli[i]) && harflerAeiI.Contains(sesli[i + 1]))
                    return true;

                if (harflerOeuU.Contains(sesli[i]) && "aeuü".Contains(sesli[i + 1]))
                    return true;
            }
            return false;
        }
    }
}
