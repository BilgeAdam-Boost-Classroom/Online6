﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace Odev41TagHelper.TagHelpers
{
    public class KucukUnluUyumuTagHelper : TagHelper
    {
        public string Kelime { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            if (KucukUnluUyumu(Kelime))
            {
                output.Content.SetContent("Kelime küçük ünlü uyumuna uygundur.");
            }
            else
                output.Content.SetContent("Kelime küçük ünlü uyumuna uymaz.");
        }

        private bool KucukUnluUyumu(string k)
        {
            List<char> sesliHarfler = new List<char>() { 'a', 'e', 'ı', 'i', 'o', 'ö', 'u', 'ü' };
            List<char> duzUnluler = new List<char>() { 'a', 'e', 'ı', 'i' };
            List<char> yuvarlakUnluler = new List<char>() { 'o', 'ö', 'u', 'ü' };

            List<char> digerSonuclar = new List<char>() { 'a', 'e', 'u', 'ü' };

            List<char> kelimeninSesliHarfleri = new List<char>();

            k = k.Replace('I', 'ı').ToLower();

            foreach (var harf in k)
            {
                if (sesliHarfler.Contains(harf))
                    kelimeninSesliHarfleri.Add(harf);
            }

            for (int i = 0; i < kelimeninSesliHarfleri.Count; i++)
            {
                if (i < kelimeninSesliHarfleri.Count - 1 && duzUnluler.Contains(kelimeninSesliHarfleri[i]) && !duzUnluler.Contains(kelimeninSesliHarfleri[i + 1]))
                    return false;

                if (i < kelimeninSesliHarfleri.Count - 1 && yuvarlakUnluler.Contains(kelimeninSesliHarfleri[i]) && !digerSonuclar.Contains(kelimeninSesliHarfleri[i + 1]))
                    return false;
            }

            return true;

        }
    }
}
