﻿namespace Odev41TagHelper.Models
{
    public class KelimeViewModel
    {
        public string Kelime { get; set; }

    }
}
