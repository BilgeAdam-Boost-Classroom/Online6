﻿namespace Odev42Mvc.Models
{
    public class Araba
    {
        public int Model { get; set; }
        public string Renk { get; set; } = null!;
    }
}
