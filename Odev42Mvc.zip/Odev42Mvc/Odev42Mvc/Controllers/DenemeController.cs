﻿using Microsoft.AspNetCore.Mvc;
using Odev42Mvc.Models;

namespace Odev42Mvc.Controllers
{
    public class DenemeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public ViewResult Calisma()
        {
            // çalışır çünkü actiona'a ait view var.
            return View();
        }

        public PartialViewResult Calisma2()
        {
            // PartialViewResult: Bu, ASP.NET MVC framework'ünde bir ActionResult türüdür. Bu metod yeni bir PartialView'i geri döndürür.
            // ve bu partial view boş bir html dosyasıdır.
            return new PartialViewResult();
        }

        public JsonResult Calisma3()
        {
            // burda json dosyası geri döndürür. arabanın proplarını görürüz.
            Araba araba = new Araba()
            {
                Model = 2022,
                Renk = "Kırmızı"
            };

            return new JsonResult(araba);
        }

        public EmptyResult Calisma4()
        {
            // bu action için view oluşturmamıza gerek yok, boş result döndürür.
            return new EmptyResult();
        }

        public RedirectToActionResult Calisma5()
        {
            // burada index actionuna yonlendirme yapılır.  ve /deneme/index adresi çalışır.
            return RedirectToAction("Index");
        }

        public StatusCodeResult Calisma6()
        {
            // StatusCodeResult: Bu, ASP.NET MVC framework'ün bir ActionResult türüdür. Bu metod HTTP durum kodunu geri döndürür.
            return new StatusCodeResult(404);
            // 404 durum kodu, not found durum kodudur.
            // bu çıktıyı alırız : HTTP ERROR 404
        }

        public ContentResult Calisma7()
        {
            return Content("merhaba ben hasan, geliyorum.");
            // content ' aynen geri döndürür fakat bu bir text/plain yani düz metin dosyasıdır.
        }
        public NotFoundResult Calisma8()
        {
            return new NotFoundResult();
        }
        //public NotFoundResult Calisma9()
        //{
        //    return View();   
            // tür uyuşmazlığı vardır
        //}

        //public PartialViewResult Calisma10()
        //{
        //    return View();
        //}
        public IActionResult Calisma11()
        {
            Araba araba = new Araba()
            {
                Model = 2022,
                Renk = "yellow"
            };
            return new JsonResult(araba);
            // IActionResult => json dosya tipine çevrildi
            // application/json; charset=utf-8
        }

        //public JsonResult Calisma12()
        //{
        //    return new EmptyResult();
        //}

        //public StatusCodeResult Calisma13()
        //{
        //    return RedirectToAction("Index");
        //}

        //public JsonResult Calisma14()
        //{
        //    return new StatusCodeResult(404);
        //}

        //public JsonResult Calisma15()
        //{
        //    return Content("merhaba ben hasan, geliyorum.");
        //}

        public IActionResult Calisma16()
        {
            return new NotFoundResult();
        }

        public IActionResult DotNet()
        {
            return View();
        }
    }
}
