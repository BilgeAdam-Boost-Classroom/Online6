﻿namespace WFASayiTahminEtme
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnBaslat = new Button();
            lblSayi = new Label();
            txtSayiGirisi = new TextBox();
            btnTahmin = new Button();
            lblBilgi = new Label();
            progressBar = new ProgressBar();
            lblMesaj = new Label();
            oyunTimer = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // btnBaslat
            // 
            btnBaslat.BackColor = Color.Aquamarine;
            btnBaslat.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnBaslat.Location = new Point(29, 47);
            btnBaslat.Margin = new Padding(4);
            btnBaslat.Name = "btnBaslat";
            btnBaslat.Size = new Size(613, 102);
            btnBaslat.TabIndex = 0;
            btnBaslat.Text = "OYUNU BASLAT";
            btnBaslat.UseVisualStyleBackColor = false;
            btnBaslat.Click += btnBaslat_Click;
            // 
            // lblSayi
            // 
            lblSayi.AutoSize = true;
            lblSayi.Location = new Point(29, 206);
            lblSayi.Margin = new Padding(4, 0, 4, 0);
            lblSayi.Name = "lblSayi";
            lblSayi.Size = new Size(329, 28);
            lblSayi.TabIndex = 1;
            lblSayi.Text = "[1-100] araliginda bir sayi giriniz:";
            // 
            // txtSayiGirisi
            // 
            txtSayiGirisi.Location = new Point(365, 192);
            txtSayiGirisi.Multiline = true;
            txtSayiGirisi.Name = "txtSayiGirisi";
            txtSayiGirisi.Size = new Size(277, 55);
            txtSayiGirisi.TabIndex = 2;
            txtSayiGirisi.TextChanged += txtSayiGirisi_TextChanged;
            // 
            // btnTahmin
            // 
            btnTahmin.BackColor = Color.Aquamarine;
            btnTahmin.Enabled = false;
            btnTahmin.Location = new Point(37, 327);
            btnTahmin.Name = "btnTahmin";
            btnTahmin.Size = new Size(605, 57);
            btnTahmin.TabIndex = 3;
            btnTahmin.Text = "TAHMIN ET";
            btnTahmin.UseVisualStyleBackColor = false;
            btnTahmin.Click += btnTahmin_Click;
            // 
            // lblBilgi
            // 
            lblBilgi.BackColor = Color.MintCream;
            lblBilgi.BorderStyle = BorderStyle.FixedSingle;
            lblBilgi.Location = new Point(37, 435);
            lblBilgi.Name = "lblBilgi";
            lblBilgi.Size = new Size(605, 36);
            lblBilgi.TabIndex = 4;
            lblBilgi.Click += lblBilgi_Click;
            // 
            // progressBar
            // 
            progressBar.Location = new Point(37, 501);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(605, 29);
            progressBar.TabIndex = 5;
            // 
            // lblMesaj
            // 
            lblMesaj.BackColor = Color.MintCream;
            lblMesaj.BorderStyle = BorderStyle.FixedSingle;
            lblMesaj.Location = new Point(37, 560);
            lblMesaj.Name = "lblMesaj";
            lblMesaj.Size = new Size(605, 55);
            lblMesaj.TabIndex = 6;
            // 
            // oyunTimer
            // 
            oyunTimer.Interval = 1000;
            oyunTimer.Tick += oyunTimer_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(12F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(684, 673);
            Controls.Add(lblMesaj);
            Controls.Add(progressBar);
            Controls.Add(lblBilgi);
            Controls.Add(btnTahmin);
            Controls.Add(txtSayiGirisi);
            Controls.Add(lblSayi);
            Controls.Add(btnBaslat);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnBaslat;
        private Label lblSayi;
        private TextBox txtSayiGirisi;
        private Button btnTahmin;
        private Label lblBilgi;
        private ProgressBar progressBar;
        private Label lblMesaj;
        private System.Windows.Forms.Timer oyunTimer;
    }
}