﻿namespace WFASayiTahminEtme
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int uretilenSayi, tahminEdilen;
        bool oyunSuruyorMu = false;
        int kalanSure = 60;
        int zorlukDerecesi = 3;



        public Form1()
        {
            InitializeComponent();
            progressBar.Maximum = 60;
        }

        private void btnBaslat_Click(object sender, EventArgs e)
        {

            // oyunun basladigini belirten degiskene true ata.
            oyunSuruyorMu = true;

            // kendisini kapat.
            btnBaslat.Enabled = false;

            // oyun basladigi zaman önce timer'i baslatalim
            oyunTimer.Start();

            // program random sayi üretecek
            uretilenSayi = rnd.Next(1, 101);

            // progress bar'in durumunu ayarlayalim. Yani doluluk oranini en tepeye alalim. O da 100 olacak. Cünkü oyun basladiginda progress bar en basta olmali (süre yeni basliyor).
            progressBar.Value = progressBar.Maximum;

            // Sayi kutusunu ac.
            txtSayiGirisi.Enabled = true;

            kalanSure = rnd.Next(30, 51); // 30-50 arasında rastgele bir süre
            zorlukDerecesi = 3; // Başlangıçta "Süre daha var :)" mesajını göster


        }

        private void txtSayiGirisi_TextChanged(object sender, EventArgs e)
        {
            // metni her degistiginde buraya gelir.
            // eger tahmin butonu aktif degilse aktif et.

            //if (txtSayiGirisi.Text == "" || !int.TryParse(txtSayiGirisi.Text, out int anlikYazilanSayi)
            //   || (txtSayiGirisi.Text.Contains(" ") && btnTahmin.Enabled))
            //    btnTahmin.Enabled = false;

            //else if (!btnTahmin.Enabled && !txtSayiGirisi.Text.Contains(" "))
            //    btnTahmin.Enabled = true;

            if (txtSayiGirisi.Text == "" || !int.TryParse(txtSayiGirisi.Text, out int anlikYazilanSayi) || (txtSayiGirisi.Text.Contains(" ") && btnTahmin.Enabled))
            {
                btnTahmin.Enabled = false;
            }
            else
            {
                if (!btnTahmin.Enabled) // Tahmin butonu devre dışı ise
                {
                    btnTahmin.Enabled = true; // Tahmin butonunu etkinleştir
                }
            }

        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            if (oyunSuruyorMu)
            {
                // Tahmin edilen sayıyı al
                tahminEdilen = Convert.ToInt32(txtSayiGirisi.Text);

                // Tahmin kontrolü
                if (tahminEdilen == uretilenSayi)
                {
                    // Doğru tahmin
                    oyunTimer.Stop();
                    MessageBox.Show("KAZANDINIZ!");
                    ResetOyun();
                }
                else
                {
                    // Yanlış tahmin
                    string mesaj = tahminEdilen > uretilenSayi ? "Daha küçük bir sayı deneyin." : "Daha büyük bir sayı deneyin.";
                    MessageBox.Show(mesaj);
                    txtSayiGirisi.Clear();
                }
            }
            else
            {
                MessageBox.Show("Oyuna başlamadan tahminde bulunamazsınız.");
            }
        }

        private void oyunTimer_Tick(object sender, EventArgs e)
        {
            // Burasi yani timer her saniyede calisacak.
            // Cünkü timer'in interval'ini 1000 ms yaptik. O da 1 sn'ye denk gelir.
            // progress bar'in degerini azalt.
            progressBar.Value--;

            // progressbar'in degeri 0 oldugu zaman yani süre bittigi zaman timer'i durdur.

            if (progressBar.Value == 0)
            {
                oyunTimer.Stop();
                btnBaslat.Enabled = false;
                MessageBox.Show("SÜRE BİTTİ. KAYBETTİNİZ!");
                ResetOyun();

                // Zorluk derecesini belirle ve mesajı güncelle
                if (kalanSure >= 30)
                {
                    lblMesaj.Text = "Süre daha var :)";
                    zorlukDerecesi = 3;
                }
                else if (kalanSure >= 20)
                {
                    lblMesaj.Text = "Süre yavaş yavaş azalıyor.";
                    zorlukDerecesi = 2;
                }
                else
                {
                    lblMesaj.Text = "Süre çok az kaldı.";
                    zorlukDerecesi = 1;
                }

                // Süreyi azalt
                kalanSure--;

                // Progress bar rengini zorluk derecesine göre ayarla
                switch (zorlukDerecesi)
                {
                    case 1:
                        progressBar.ForeColor = System.Drawing.Color.Red;
                        break;
                    case 2:
                        progressBar.ForeColor = System.Drawing.Color.Orange;
                        break;
                    case 3:
                        progressBar.ForeColor = System.Drawing.Color.Green;
                        break;
                }

                // Süreyi progress bara yaz
                progressBar.Text = kalanSure.ToString() + " sn";
            }
        }

        private void ResetOyun()
        {
            oyunSuruyorMu = false;
            btnBaslat.Enabled = true;
            txtSayiGirisi.Enabled = false;
            txtSayiGirisi.Clear();
            progressBar.Value = progressBar.Maximum;
            lblMesaj.Text = "";
            progressBar.ForeColor = System.Drawing.Color.Green;
        }

        private void lblBilgi_Click(object sender, EventArgs e)
        {

        }
    }
}