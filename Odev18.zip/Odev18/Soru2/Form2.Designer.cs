﻿namespace Soru2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbRenk = new ComboBox();
            btnTamam = new Button();
            btnIptal = new Button();
            SuspendLayout();
            // 
            // cmbRenk
            // 
            cmbRenk.FormattingEnabled = true;
            cmbRenk.Location = new Point(12, 62);
            cmbRenk.Name = "cmbRenk";
            cmbRenk.Size = new Size(332, 28);
            cmbRenk.TabIndex = 0;
            cmbRenk.SelectedIndexChanged += cmbRenk_SelectedIndexChanged;
            // 
            // btnTamam
            // 
            btnTamam.Location = new Point(18, 151);
            btnTamam.Name = "btnTamam";
            btnTamam.Size = new Size(158, 29);
            btnTamam.TabIndex = 1;
            btnTamam.Text = "TAMAM";
            btnTamam.UseVisualStyleBackColor = true;
            btnTamam.Click += btnTamam_Click;
            // 
            // btnIptal
            // 
            btnIptal.Location = new Point(182, 151);
            btnIptal.Name = "btnIptal";
            btnIptal.Size = new Size(162, 29);
            btnIptal.TabIndex = 2;
            btnIptal.Text = "IPTAL";
            btnIptal.UseVisualStyleBackColor = true;
            btnIptal.Click += btnIptal_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(356, 238);
            Controls.Add(btnIptal);
            Controls.Add(btnTamam);
            Controls.Add(cmbRenk);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbRenk;
        private Button btnTamam;
        private Button btnIptal;
    }
}