namespace Soru2
{
    public partial class Form1 : Form
    {
        private Form2 form2;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnRenkSec_Click(object sender, EventArgs e)
        {
            form2 = new Form2();

            form2.ShowDialog();

            
            this.BackColor = form2.SecilenRenk;
        }
    }
}