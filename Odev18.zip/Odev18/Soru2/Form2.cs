﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Soru2
{
    public partial class Form2 : Form
    {
        public Color SecilenRenk { get; private set; }

        public Form2()
        {
            InitializeComponent();

            cmbRenk.Items.Add("AliceBlue");
            cmbRenk.Items.Add("Red");
            cmbRenk.Items.Add("Green");
            cmbRenk.Items.Add("Blue");
        }

        private void cmbRenk_SelectedIndexChanged(object sender, EventArgs e)
        {

            string secilenRenkAdi = cmbRenk.SelectedItem.ToString();
            Color secilenRenk = Color.FromName(secilenRenkAdi);

            SecilenRenk = secilenRenk;
        }

        private void btnTamam_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnIptal_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
