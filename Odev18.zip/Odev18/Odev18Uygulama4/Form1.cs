namespace Odev18Uygulama4
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int do�ruTahmin;
        double programTahmin;
        public Form1()
        {
            InitializeComponent();

            progressBar.Maximum = 60;
            progressBar.Minimum = 0;
            progressBar.Value = 60;
        }

        private void btnOyunuBaslat_Click(object sender, EventArgs e)
        {
            programTahmin = rnd.Next(1, 101);
            tmrZaman.Start();
            btnOyunuBaslat.Enabled = false;
        }
        private void txtTahminEdilen_TextChanged(object sender, EventArgs e)
        {
            //if (txtTahminEdilen.Text.Contains(" ") && double.TryParse(txtTahminEdilen.Text,out sayi)&& )
            //{

            //}

        }
        private void btnTahminEt_Click(object sender, EventArgs e)
        {
            if (btnOyunuBaslat.Enabled == false)
            {
                do�ruTahmin = 0;
                double kullaniciTahmin = Convert.ToDouble(txtTahminEdilen.Text);
                if (kullaniciTahmin > 0 && kullaniciTahmin < 101)
                {
                    if (programTahmin == kullaniciTahmin)
                    {
                        lblKazanmaBilgisi.Text = "Tebrikler. Do�ru tahmin.";
                        lblZamanBilgisi.TextAlign = ContentAlignment.MiddleCenter;
                        do�ruTahmin++;
                        programTahmin = rnd.Next(1, 101);
                    }
                    else if (programTahmin > kullaniciTahmin)
                    {
                        lblKazanmaBilgisi.Text = "Sonuca �ok Yakla�t�n�z. Tahminizi Artt�r�n.";
                        lblZamanBilgisi.TextAlign = ContentAlignment.MiddleCenter;
                    }
                    else if (programTahmin < kullaniciTahmin)
                    {
                        lblKazanmaBilgisi.Text = "Sonuca �ok Yakla�t�n�z. Tahminizi Azalt�n.";
                        lblZamanBilgisi.TextAlign = ContentAlignment.MiddleCenter;
                    }
                }
                else
                {
                    lblKazanmaBilgisi.Text = "Tahmininiz 1 ile 100 aras�nda olmal�d�r.";
                    return;
                }
            }
        }
        private void tmrZaman_Tick(object sender, EventArgs e)
        {
            if (progressBar.Value > 0)
            {
                progressBar.Value--;
                if (progressBar.Value >= 30 && progressBar.Value <= 50)
                {
                    lblZamanBilgisi.Text = "S�re Daha Var :)";
                    lblZamanBilgisi.ForeColor = Color.Green;
                    lblZamanBilgisi.TextAlign = ContentAlignment.MiddleCenter;
                }
                else if (progressBar.Value >= 20 && progressBar.Value <= 29)
                {
                    lblZamanBilgisi.Text = "S�re Yava� Yava� Azal�yor:)";
                    lblZamanBilgisi.ForeColor = Color.Yellow;
                    lblZamanBilgisi.TextAlign = ContentAlignment.MiddleCenter;
                }
                else if (progressBar.Value >= 1 && progressBar.Value <= 19)
                {
                    lblZamanBilgisi.Text = "S�re �ok Azald�:)";
                    lblZamanBilgisi.ForeColor = Color.DarkRed;
                    lblZamanBilgisi.TextAlign = ContentAlignment.MiddleCenter;
                }
            }
            else if (progressBar.Value == 0)
            {
                if (rdbKolay.Checked == true)
                {
                    if (do�ruTahmin >= 1)
                        lblZamanBilgisi.Text = "Oyun Bitti.Kazand�n�z.";
                    else
                        lblZamanBilgisi.Text = "Oyun Bitti.Kaybettiniz";
                }


                tmrZaman.Stop();
                btnOyunuBaslat.Enabled = true;
                txtTahminEdilen.Clear();
            }
        }
    }
}














