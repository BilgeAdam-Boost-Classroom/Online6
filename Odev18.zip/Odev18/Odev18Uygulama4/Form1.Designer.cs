﻿namespace Odev18Uygulama4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnOyunuBaslat = new Button();
            label1 = new Label();
            txtTahminEdilen = new TextBox();
            btnTahminEt = new Button();
            progressBar = new ProgressBar();
            lblZamanBilgisi = new Label();
            lblKazanmaBilgisi = new Label();
            tmrZaman = new System.Windows.Forms.Timer(components);
            oyunPanel = new Panel();
            rdbKolay = new RadioButton();
            button1 = new Button();
            rdbOrta = new RadioButton();
            rdbZor = new RadioButton();
            oyunPanel.SuspendLayout();
            SuspendLayout();
            // 
            // btnOyunuBaslat
            // 
            btnOyunuBaslat.Location = new Point(47, 77);
            btnOyunuBaslat.Margin = new Padding(4);
            btnOyunuBaslat.Name = "btnOyunuBaslat";
            btnOyunuBaslat.Size = new Size(780, 82);
            btnOyunuBaslat.TabIndex = 0;
            btnOyunuBaslat.Text = "OYUNU BAŞLAT";
            btnOyunuBaslat.UseVisualStyleBackColor = true;
            btnOyunuBaslat.Click += btnOyunuBaslat_Click;
            // 
            // label1
            // 
            label1.Location = new Point(47, 184);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(437, 66);
            label1.TabIndex = 1;
            label1.Text = "[1-100] Arasında Bir Sayı Tahmin Ediniz \r\n\r\n";
            // 
            // txtTahminEdilen
            // 
            txtTahminEdilen.Location = new Point(469, 184);
            txtTahminEdilen.Margin = new Padding(4);
            txtTahminEdilen.Name = "txtTahminEdilen";
            txtTahminEdilen.Size = new Size(358, 37);
            txtTahminEdilen.TabIndex = 2;
            txtTahminEdilen.TextChanged += txtTahminEdilen_TextChanged;
            // 
            // btnTahminEt
            // 
            btnTahminEt.Location = new Point(47, 254);
            btnTahminEt.Margin = new Padding(4);
            btnTahminEt.Name = "btnTahminEt";
            btnTahminEt.Size = new Size(780, 49);
            btnTahminEt.TabIndex = 3;
            btnTahminEt.Text = "TAHMİN ET";
            btnTahminEt.UseVisualStyleBackColor = true;
            btnTahminEt.Click += btnTahminEt_Click;
            // 
            // progressBar
            // 
            progressBar.Location = new Point(47, 407);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(780, 46);
            progressBar.TabIndex = 4;
            // 
            // lblZamanBilgisi
            // 
            lblZamanBilgisi.BorderStyle = BorderStyle.FixedSingle;
            lblZamanBilgisi.Location = new Point(47, 329);
            lblZamanBilgisi.Name = "lblZamanBilgisi";
            lblZamanBilgisi.Size = new Size(780, 58);
            lblZamanBilgisi.TabIndex = 5;
            // 
            // lblKazanmaBilgisi
            // 
            lblKazanmaBilgisi.BorderStyle = BorderStyle.FixedSingle;
            lblKazanmaBilgisi.Location = new Point(47, 490);
            lblKazanmaBilgisi.Name = "lblKazanmaBilgisi";
            lblKazanmaBilgisi.Size = new Size(780, 58);
            lblKazanmaBilgisi.TabIndex = 6;
            // 
            // tmrZaman
            // 
            tmrZaman.Interval = 1000;
            tmrZaman.Tick += tmrZaman_Tick;
            // 
            // oyunPanel
            // 
            oyunPanel.Controls.Add(rdbKolay);
            oyunPanel.Controls.Add(button1);
            oyunPanel.Controls.Add(rdbOrta);
            oyunPanel.Controls.Add(rdbZor);
            oyunPanel.Location = new Point(856, 77);
            oyunPanel.Name = "oyunPanel";
            oyunPanel.Size = new Size(205, 471);
            oyunPanel.TabIndex = 7;
            // 
            // rdbKolay
            // 
            rdbKolay.AutoSize = true;
            rdbKolay.Location = new Point(44, 82);
            rdbKolay.Name = "rdbKolay";
            rdbKolay.Size = new Size(92, 34);
            rdbKolay.TabIndex = 5;
            rdbKolay.Text = "Kolay";
            rdbKolay.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(33, 271);
            button1.Name = "button1";
            button1.Size = new Size(144, 57);
            button1.TabIndex = 4;
            button1.Text = "Seç";
            button1.UseVisualStyleBackColor = true;
            // 
            // rdbOrta
            // 
            rdbOrta.AutoSize = true;
            rdbOrta.Location = new Point(44, 146);
            rdbOrta.Name = "rdbOrta";
            rdbOrta.Size = new Size(83, 34);
            rdbOrta.TabIndex = 6;
            rdbOrta.Text = "Orta";
            rdbOrta.UseVisualStyleBackColor = true;
            // 
            // rdbZor
            // 
            rdbZor.AutoSize = true;
            rdbZor.Location = new Point(44, 207);
            rdbZor.Name = "rdbZor";
            rdbZor.Size = new Size(72, 34);
            rdbZor.TabIndex = 7;
            rdbZor.Text = "Zor";
            rdbZor.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 30F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1128, 806);
            Controls.Add(oyunPanel);
            Controls.Add(lblKazanmaBilgisi);
            Controls.Add(lblZamanBilgisi);
            Controls.Add(progressBar);
            Controls.Add(btnTahminEt);
            Controls.Add(txtTahminEdilen);
            Controls.Add(label1);
            Controls.Add(btnOyunuBaslat);
            Font = new Font("Segoe UI Semibold", 11F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            oyunPanel.ResumeLayout(false);
            oyunPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOyunuBaslat;
        private Label label1;
        private TextBox txtTahminEdilen;
        private Button btnTahminEt;
        private ProgressBar progressBar;
        private Label lblZamanBilgisi;
        private Label lblKazanmaBilgisi;
        private System.Windows.Forms.Timer tmrZaman;
        private Panel oyunPanel;
        private RadioButton rdbKolay;
        private Button button1;
        private RadioButton rdbOrta;
        private RadioButton rdbZor;
    }
}