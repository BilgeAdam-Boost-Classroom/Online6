namespace _1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            lblZorluk.Text = "";
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            if (txtSifre.Text.Length == 0 || AykiriMi())
                lblZorluk.Text = "";

            else if (txtSifre.Text.Length < 7 || TekCinsMi())
            {
                lblZorluk.Text = "D���k";
                lblZorluk.ForeColor = Color.Red;
            }
            else if (txtSifre.Text.Length == 7 && !TekCinsMi())
            {
                lblZorluk.Text = "Orta";
                lblZorluk.ForeColor = Color.Orange;

            }
            else if (txtSifre.Text.Length > 7 && !TekCinsMi())
            {
                lblZorluk.Text = "Y�ksek";
                lblZorluk.ForeColor = Color.Green;
            }
        }

        private bool AykiriMi()
        {
            for (int i = 0; i < txtSifre.Text.Length; i++)
                if (!(Char.IsDigit(txtSifre.Text[i]) || Char.IsLetter(txtSifre.Text[i])))
                    return true;
            return false;
        }

        private bool TekCinsMi()
        {
            for (int i = 0; i < txtSifre.Text.Length; i++)
                if (Char.IsDigit(txtSifre.Text[0]) != Char.IsDigit(txtSifre.Text[i]))
                    return false;
            return true;
        }
    }
}