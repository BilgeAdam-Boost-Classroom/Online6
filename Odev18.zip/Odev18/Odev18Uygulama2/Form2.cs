﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Odev18Uygulama2
{
    public partial class Form2 : Form
    {
        List<Color> renkler = new List<Color>() { Color.AliceBlue, Color.Red, Color.Green, Color.Blue };
        public Form2()
        {
            InitializeComponent();
            foreach (Color renk in renkler)
            {
                cmbRenkler.Items.Add(renk);
            }
        }
        private void btnTamam_Click(object sender, EventArgs e)
        {
            Owner.BackColor = renkler[cmbRenkler.SelectedIndex];
        }
        private void btnIptal_Click(object sender, EventArgs e)
        {
            Owner.BackColor = Color.White;
        }
    }
}

            




