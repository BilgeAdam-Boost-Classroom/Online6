namespace Odev18Uygulama2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRenkSec_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Owner = this;
            form.StartPosition = FormStartPosition.CenterParent;
            form.Show();
        }
    }
}
           
            
            