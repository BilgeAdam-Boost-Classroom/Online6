﻿namespace Odev18Uygulama2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRenkSec = new Button();
            SuspendLayout();
            // 
            // btnRenkSec
            // 
            btnRenkSec.Location = new Point(138, 167);
            btnRenkSec.Name = "btnRenkSec";
            btnRenkSec.Size = new Size(176, 58);
            btnRenkSec.TabIndex = 3;
            btnRenkSec.Text = "Renk Seç";
            btnRenkSec.UseVisualStyleBackColor = true;
            btnRenkSec.Click += btnRenkSec_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(482, 384);
            Controls.Add(btnRenkSec);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnRenkSec;
    }
}