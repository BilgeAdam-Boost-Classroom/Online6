﻿namespace Odev18Uygulama2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnTamam = new Button();
            btnIptal = new Button();
            cmbRenkler = new ComboBox();
            SuspendLayout();
            // 
            // btnTamam
            // 
            btnTamam.Location = new Point(52, 165);
            btnTamam.Name = "btnTamam";
            btnTamam.Size = new Size(195, 66);
            btnTamam.TabIndex = 0;
            btnTamam.Text = "TAMAM";
            btnTamam.UseVisualStyleBackColor = true;
            btnTamam.Click += btnTamam_Click;
            // 
            // btnIptal
            // 
            btnIptal.Location = new Point(268, 165);
            btnIptal.Name = "btnIptal";
            btnIptal.Size = new Size(186, 66);
            btnIptal.TabIndex = 1;
            btnIptal.Text = "İPTAL";
            btnIptal.UseVisualStyleBackColor = true;
            btnIptal.Click += btnIptal_Click;
            // 
            // cmbRenkler
            // 
            cmbRenkler.FormattingEnabled = true;
            cmbRenkler.Location = new Point(52, 77);
            cmbRenkler.Name = "cmbRenkler";
            cmbRenkler.Size = new Size(402, 33);
            cmbRenkler.TabIndex = 2;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(527, 324);
            Controls.Add(cmbRenkler);
            Controls.Add(btnIptal);
            Controls.Add(btnTamam);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
        }

        #endregion

        private Button btnTamam;
        private Button btnIptal;
        private ComboBox cmbRenkler;
    }
}