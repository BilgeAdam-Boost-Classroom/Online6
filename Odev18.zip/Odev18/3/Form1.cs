namespace _3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            if (txtAd.Text == "admin" && txtParola.Text == "1234")
            {
                Form2 form2 = new Form2();
                form2.ShowDialog();
            }
            else
                MessageBox.Show("Kullan�c� ad� veya parola hatal�.","Uyar� Mesaj�",MessageBoxButtons.OKCancel,MessageBoxIcon.Exclamation);
        }
    }
}