using System;

namespace Odev18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            string parola = txtSifre.Text;
            parola = SifreDuzenle(parola);

            if (parola.Length <= 6)
            {
                lblSifreZorluk.Text = "�ifre g�venli�iniz zay�f";
                lblSifreZorluk.ForeColor = Color.Red;
            }
            else if (parola.Length == 7)
            {
                if (HarfVarMi(parola) && RakamVarMi(parola))
                {
                    lblSifreZorluk.Text = "�ifre g�venli�iniz orta";
                    lblSifreZorluk.ForeColor = Color.Orange;
                }
                else
                {
                    lblSifreZorluk.Text = "�ifre g�venli�iniz zay�f";
                    lblSifreZorluk.ForeColor = Color.Red;
                }
            }
            else if (parola.Length >= 8)
            {
                if (HarfVarMi(parola) && RakamVarMi(parola))
                {
                    lblSifreZorluk.Text = "�ifre g�venli�iniz y�ksek";
                    lblSifreZorluk.ForeColor = Color.Green;
                }
                else
                {
                    lblSifreZorluk.Text = "�ifre g�venli�iniz zay�f";
                    lblSifreZorluk.ForeColor = Color.Red;
                }
            }

        }
        string SifreDuzenle(string parola)
        {
            parola = parola.ToUpper();
            char[] parolaHarfleri = parola.ToCharArray();
            for (int i = 0; i < parolaHarfleri.Length; i++)
            {
                switch (parolaHarfleri[i])
                {
                    case '�':
                        parolaHarfleri[i] = 'C';
                        break;
                    case '�':
                        parolaHarfleri[i] = 'G';
                        break;
                    case '�':
                        parolaHarfleri[i] = 'I';
                        break;
                    case '�':
                        parolaHarfleri[i] = 'O';
                        break;
                    case '�':
                        parolaHarfleri[i] = 'S';
                        break;
                    case '�':
                        parolaHarfleri[i] = 'U';
                        break;
                }
            }
            string duzenlenmisParola = string.Join("", parolaHarfleri);
            return duzenlenmisParola;
        }
        bool HarfVarMi(string parola)
        {
            parola = SifreDuzenle(parola);
            foreach (char harf in parola)
            {
                if (Char.IsLetter(harf))
                {
                    return true;
                }
            }
            return false;
        }
        bool RakamVarMi(string parola)
        {
            parola = SifreDuzenle(parola);
            foreach (char rakam in parola)
            {
                if (Char.IsDigit(rakam))
                {
                    return true;
                }
            }
            return false;
        }

    }
}













