namespace _2
{
    public delegate void Renk(string renkBilgisi);
    public partial class Form1 : Form
    {
        public Renk renk;
        public Form1()
        {
            InitializeComponent();
            renk = new Renk(FormIkiTamam);
        }


        private void  FormIkiTamam(string renkBilgisi)
        {
            if (renkBilgisi == "AliceBlue")
                BackColor = Color.AliceBlue;
            else if (renkBilgisi == "Red")
                BackColor = Color.Red;
            else if (renkBilgisi == "Green")
                BackColor = Color.Green;
            else if (renkBilgisi == "Blue")
                BackColor = Color.Blue;
        }

        private void btnRenkSec_Click(object sender, EventArgs e)
        {
            Form form = new Form2(renk);
            form.ShowDialog();
            
        }
    }
}
