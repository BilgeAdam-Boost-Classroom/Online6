﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2
{
    public partial class Form2 : Form
    {
        Renk renkForm2;
        public Form2(Renk renkBilgisi)
        {
            InitializeComponent();
            cmbRenkler.Items.AddRange(new string[] { "AliceBlue", "Red", "Green", "Blue" });
            cmbRenkler.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRenkler.SelectedIndex = 0;
            renkForm2 = renkBilgisi;

        }

        private void btnTamam_Click(object sender, EventArgs e)
        {

            renkForm2.Invoke(cmbRenkler.SelectedItem.ToString());
            Close();
        }

        private void btnIptal_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
