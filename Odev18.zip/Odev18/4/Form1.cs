namespace _4
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int uretilenSayi;
        bool oyun = false;

        public Form1()
        {
            InitializeComponent();
            pbarSure.Maximum = 60;

            btnTahmin.Enabled = false;
            txtSayi.Enabled = false;
            AcceptButton = btnTahmin;

        }

        private void YeniOyun()
        {
            txtSayi.Enabled = false;
            txtSayi.Clear();
            lblMesaj.Text = "";
            btnTahmin.Enabled = false;
            btnBaslat.Text = "YEN� OYUN";
            oyun = !oyun;
            timer1.Stop();
        }

        private void btnBaslat_Click(object sender, EventArgs e)
        {
            if (oyun)
            {
                btnBaslat.Text = "OYUNU BA�LAT";
                timer1.Stop();
                btnTahmin.Enabled = false;
                txtSayi.Enabled = false;
                pbarSure.Value = 0;

            }
            else
            {
                pbarSure.Value = pbarSure.Maximum;
                btnBaslat.Text = "OYUNU DURDUR";
                uretilenSayi = rnd.Next(1, 101);
                timer1.Start();
                txtSayi.Enabled = true;
                lblBilgi.Enabled = true;
                lblBilgi.Text = "";
                lblMesaj.Text = "";
                lblMesaj.BackColor = Color.White;

            }
            oyun = !oyun;


        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            if (uretilenSayi > Convert.ToInt32(txtSayi.Text))
                lblBilgi.Text = txtSayi.Text + "=> K���k say� girdin";

            else if (uretilenSayi < Convert.ToInt32(txtSayi.Text))
                lblBilgi.Text = txtSayi.Text + "=> B�y�k say� girdin";

            else
            {
                lblBilgi.Text = "TEBR�KLER! KAZANDINIZ.";
                YeniOyun();
            }
            txtSayi.Clear();


        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pbarSure.Value > 0)
            {
                pbarSure.Value--;
                btnTahmin.Text = "TAHM�N ET (" + pbarSure.Value + ")";
                if (pbarSure.Value < 20)
                    lblMesaj.Text = "S�re �ok az kald�";
                else if (pbarSure.Value < 30)
                    lblMesaj.Text = "S�re yava� yava� azal�yor";
                else if (pbarSure.Value < 50)
                    lblMesaj.Text = "S�re daha var";

            }
            else
            {
                lblBilgi.Text = "KAYBETT�N�Z!";
                YeniOyun();

            }


        }

        private void txtSayi_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtSayi.Text, out int a) && !txtSayi.Text.Contains(" "))
                btnTahmin.Enabled = true;
            else
                btnTahmin.Enabled = false;

        }
    }
}