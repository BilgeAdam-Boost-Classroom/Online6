﻿namespace _4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtSayi = new TextBox();
            btnBaslat = new Button();
            label2 = new Label();
            lblBilgi = new Label();
            lblMesaj = new Label();
            btnTahmin = new Button();
            pbarSure = new ProgressBar();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // txtSayi
            // 
            txtSayi.Location = new Point(291, 96);
            txtSayi.Name = "txtSayi";
            txtSayi.Size = new Size(125, 27);
            txtSayi.TabIndex = 2;
            txtSayi.TextChanged += txtSayi_TextChanged;
            // 
            // btnBaslat
            // 
            btnBaslat.Location = new Point(64, 12);
            btnBaslat.Name = "btnBaslat";
            btnBaslat.Size = new Size(352, 70);
            btnBaslat.TabIndex = 3;
            btnBaslat.Text = "OYUNU BAŞLAT";
            btnBaslat.UseVisualStyleBackColor = true;
            btnBaslat.Click += btnBaslat_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(64, 103);
            label2.Name = "label2";
            label2.Size = new Size(211, 20);
            label2.TabIndex = 4;
            label2.Text = "1-100 aralığında bir sayı girim:";
            // 
            // lblBilgi
            // 
            lblBilgi.BackColor = SystemColors.ControlLightLight;
            lblBilgi.Location = new Point(64, 202);
            lblBilgi.Name = "lblBilgi";
            lblBilgi.Size = new Size(352, 31);
            lblBilgi.TabIndex = 5;
            // 
            // lblMesaj
            // 
            lblMesaj.BackColor = SystemColors.ControlLightLight;
            lblMesaj.Location = new Point(64, 303);
            lblMesaj.Name = "lblMesaj";
            lblMesaj.Size = new Size(352, 47);
            lblMesaj.TabIndex = 6;
            // 
            // btnTahmin
            // 
            btnTahmin.Location = new Point(64, 141);
            btnTahmin.Name = "btnTahmin";
            btnTahmin.Size = new Size(352, 44);
            btnTahmin.TabIndex = 7;
            btnTahmin.Text = "TAHMİN ET";
            btnTahmin.UseVisualStyleBackColor = true;
            btnTahmin.Click += btnTahmin_Click;
            // 
            // pbarSure
            // 
            pbarSure.Location = new Point(64, 251);
            pbarSure.Name = "pbarSure";
            pbarSure.Size = new Size(352, 29);
            pbarSure.TabIndex = 8;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(473, 394);
            Controls.Add(pbarSure);
            Controls.Add(btnTahmin);
            Controls.Add(lblMesaj);
            Controls.Add(lblBilgi);
            Controls.Add(label2);
            Controls.Add(btnBaslat);
            Controls.Add(txtSayi);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private TextBox txtSayi;
        private Button btnBaslat;
        private Label label2;
        private Label lblBilgi;
        private Label lblMesaj;
        private Button btnTahmin;
        private ProgressBar pbarSure;
        private System.Windows.Forms.Timer timer1;
    }
}