﻿namespace Soru1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtSifreGirisi_TextChanged(object sender, EventArgs e)
        {
            string sifre = txtSifreGirisi.Text;
            int uzunluk = sifre.Length;

            string zorlukSeviyesi = "Düşük";
            Color renk = Color.Red;

            if (uzunluk > 6)
            {

                if (IsSadeceRakam(sifre) || IsSadeceHarf(sifre))
                {
                    zorlukSeviyesi = "Düşük";
                    renk = Color.Red;
                }

                else if (IsRakamVeHarf(sifre))
                {
                    zorlukSeviyesi = uzunluk >= 8 ? "Yüksek" : "Orta";
                    renk = uzunluk >= 8 ? Color.Green : Color.Orange;
                }
            }

            lblDerece.Text = zorlukSeviyesi;
            lblDerece.ForeColor = renk;
        }

        private bool IsSadeceRakam(string metin)
        {
            foreach (char karakter in metin)
            {
                if (!char.IsDigit(karakter))
                {
                    return false;
                }
            }
            return true;
        }

        private bool IsSadeceHarf(string metin)
        {
            foreach (char karakter in metin)
            {
                if (!char.IsLetter(karakter))
                {
                    return false;
                }
            }
            return true;
        }

        private bool IsRakamVeHarf(string metin)
        {
            return metin.Any(char.IsDigit) && metin.Any(char.IsLetter);
        }
    }
}
