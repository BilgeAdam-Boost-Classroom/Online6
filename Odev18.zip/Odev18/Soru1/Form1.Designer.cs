﻿namespace Soru1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSifreGirisi = new TextBox();
            lblZorlukDerecesi = new Label();
            lblDerece = new Label();
            SuspendLayout();
            // 
            // txtSifreGirisi
            // 
            txtSifreGirisi.Location = new Point(12, 37);
            txtSifreGirisi.Name = "txtSifreGirisi";
            txtSifreGirisi.Size = new Size(290, 27);
            txtSifreGirisi.TabIndex = 0;
            txtSifreGirisi.TextChanged += txtSifreGirisi_TextChanged;
            // 
            // lblZorlukDerecesi
            // 
            lblZorlukDerecesi.AutoSize = true;
            lblZorlukDerecesi.Location = new Point(12, 109);
            lblZorlukDerecesi.Name = "lblZorlukDerecesi";
            lblZorlukDerecesi.Size = new Size(149, 20);
            lblZorlukDerecesi.TabIndex = 1;
            lblZorlukDerecesi.Text = "Sifre Zorluk Derecesi:";
            // 
            // lblDerece
            // 
            lblDerece.Location = new Point(167, 109);
            lblDerece.Name = "lblDerece";
            lblDerece.Size = new Size(135, 31);
            lblDerece.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(314, 197);
            Controls.Add(lblDerece);
            Controls.Add(lblZorlukDerecesi);
            Controls.Add(txtSifreGirisi);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSifreGirisi;
        private Label lblZorlukDerecesi;
        private Label lblDerece;
    }
}