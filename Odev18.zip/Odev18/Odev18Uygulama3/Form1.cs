namespace Odev18Uygulama3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            string kullaniciAdi = txtKullaniciAdi.Text;
            kullaniciAdi = kullaniciAdi.Trim();
            string sifre = txtSifre.Text;
            sifre = sifre.Trim();
            if (kullaniciAdi == "admin" && sifre == "1234")
            {
                Form2 form = new Form2();
                form.Owner = this;
                this.Hide();
                form.Show();
                form.StartPosition = FormStartPosition.CenterScreen;
            }
            else
            {
                MessageBox.Show("Kullan�c� Ad� veya Parola Hatal� ! Tekrar deneyiniz.");
            }
        }

    }
}