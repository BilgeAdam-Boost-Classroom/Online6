namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            cmbEkle.Items.Add("Se�iniz");
            cmbEkle.SelectedIndex = 0;
        }
        private void btnEkle_Click(object sender, EventArgs e)
        {
            string metin = txtYaz.Text;
            if (!string.IsNullOrWhiteSpace(metin))
            {
                cmbEkle.Items.Add(metin);
                lstEkle.Items.Add(metin);
                txtYaz.Clear();
            }
            else
            {
                MessageBox.Show("L�tfen bir metin girin.");
            }
        }

        private void cmbEkle_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbEkle.SelectedItem is string)
            {
                string secilenMetin = (string)cmbEkle.SelectedItem;
                if (cmbEkle.SelectedIndex > 0)
                {
                    lstEkle.SelectedItem = cmbEkle.SelectedItem;
                    MessageBox.Show($"Se�ilen Ders: {secilenMetin}");
                }
            }
            else
            {
                MessageBox.Show("L�tfen bir metin se�in.");
            }
        }

        private void btnHicBirSeySecme_Click(object sender, EventArgs e)
        {
            cmbEkle.SelectedIndex = -1;
            lstEkle.SelectedIndex = -1;
        }
    }
}


