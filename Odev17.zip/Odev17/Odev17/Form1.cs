namespace Odev17
{
    public partial class Form1 : Form
    {
        List<Ders> dersler = new List<Ders>(); 

        public Form1()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
           
            if (!string.IsNullOrEmpty(txtDersGirisi.Text))
            {
                Ders yeniDers = new Ders(txtDersGirisi.Text);

                // Ders nesnesini listeye ekleyin
                dersler.Add(yeniDers);

                lbDersler.Items.Add(yeniDers);

                cmbDersler.Items.Add(yeniDers);

                txtDersGirisi.Clear();
            }
        }

        private void cmbDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbDersler.SelectedIndex != -1)
            {
                Ders secilenDers = (Ders)cmbDersler.SelectedItem;
                MessageBox.Show("combobox'tan se�ilen ders:" + secilenDers.Ad);
            }
        }

        private void lbDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbDersler.SelectedIndex != -1)
            {
                Ders secilenDers = (Ders)lbDersler.SelectedItem;
                MessageBox.Show("ListBox'tan se�ilen ders:" + secilenDers.Ad);
            }
        }

        private void btnBirSeySecme_Click(object sender, EventArgs e)
        {
            if (lbDersler.SelectedIndex == -1 && cmbDersler.SelectedIndex == -1)
                MessageBox.Show("Bir sey secilmedi");
        }
    }
}