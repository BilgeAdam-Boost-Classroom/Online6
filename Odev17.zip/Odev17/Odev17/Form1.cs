namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtDersler.Text)) //!((txtDersler.Text == null || txtDersler.Text == ""))
                {
                    MessageBox.Show("Ders alan� bo� b�rak�lamaz.");
                    return;
                }

                List<string> dersler = new List<string>();
                string ders = txtDersler.Text;
                string orjinalDers = ders;
                ders = ders.ToUpper().Replace(" ", "").Trim();
                dersler.Add(ders);
                foreach (string d in dersler)
                {
                    if (!cmbDersler.Items.Contains(d))
                    {

                        cmbDersler.Items.Add(orjinalDers);
                    }
                }
                foreach (string d in dersler)
                {
                    if (!cmbDersler.Items.Contains(d))
                    {
                        lstDersler.Items.Add(orjinalDers);
                    }
                }
                txtDersler.Clear();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Hata Olu�tu!" +ex.Message);
                return;
            }
            
        }
        private void lstDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(lstDersler.Text);
        }

        private void btn_HicbirSeySecme_Click(object sender, EventArgs e)
        {
            cmbDersler.SelectedIndex = -1;
            lstDersler.SelectedIndex = -1;
            lstDersler.Items.Clear();
        }



    }
}
