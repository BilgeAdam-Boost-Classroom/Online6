namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            lstListe.Items.Add(txtGiris.Text);
            cbxListe.Items.Add(txtGiris.Text);
            txtGiris.Clear();
        }

        private void lstListe_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Listboxtan se�ilen: " + (lstListe.SelectedIndex > -1 ? lstListe.Text : lstListe.SelectedIndex));
        }

        private void cbxListe_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Comboboxtan se�ilen: " + (cbxListe.SelectedIndex > -1 ? cbxListe.Text : cbxListe.SelectedIndex));
        }

        private void btnSecme_Click(object sender, EventArgs e)
        {
            lstListe.SelectedIndex = cbxListe.SelectedIndex = -1;
        }


    }
}