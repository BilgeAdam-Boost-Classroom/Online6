﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev17
{
    internal class Ders
    {
        public string Ad { get; }

        public Ders(string ad)
        {
            Ad = ad;
        }

        public override string ToString()
        {
            return Ad;
        }

    }
}
