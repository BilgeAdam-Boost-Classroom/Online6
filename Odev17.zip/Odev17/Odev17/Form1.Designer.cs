﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDersler = new TextBox();
            btnEkle = new Button();
            cmbDersler = new ComboBox();
            lstDersler = new ListBox();
            btn_HicbirSeySecme = new Button();
            SuspendLayout();
            // 
            // txtDersler
            // 
            txtDersler.Location = new Point(12, 39);
            txtDersler.Name = "txtDersler";
            txtDersler.Size = new Size(369, 31);
            txtDersler.TabIndex = 0;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Silver;
            btnEkle.Location = new Point(405, 32);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(146, 45);
            btnEkle.TabIndex = 1;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnEkle_Click;
            // 
            // cmbDersler
            // 
            cmbDersler.FormattingEnabled = true;
            cmbDersler.Location = new Point(12, 93);
            cmbDersler.Name = "cmbDersler";
            cmbDersler.Size = new Size(539, 33);
            cmbDersler.TabIndex = 2;
            // 
            // lstDersler
            // 
            lstDersler.FormattingEnabled = true;
            lstDersler.ItemHeight = 25;
            lstDersler.Location = new Point(12, 149);
            lstDersler.Name = "lstDersler";
            lstDersler.Size = new Size(539, 429);
            lstDersler.TabIndex = 3;
            lstDersler.SelectedIndexChanged += lstDersler_SelectedIndexChanged;
            // 
            // btn_HicbirSeySecme
            // 
            btn_HicbirSeySecme.BackColor = Color.Silver;
            btn_HicbirSeySecme.Location = new Point(12, 599);
            btn_HicbirSeySecme.Name = "btn_HicbirSeySecme";
            btn_HicbirSeySecme.Size = new Size(539, 52);
            btn_HicbirSeySecme.TabIndex = 4;
            btn_HicbirSeySecme.Text = "HİÇBİR ŞEY SEÇME";
            btn_HicbirSeySecme.UseVisualStyleBackColor = false;
            btn_HicbirSeySecme.Click += btn_HicbirSeySecme_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 853);
            Controls.Add(btn_HicbirSeySecme);
            Controls.Add(lstDersler);
            Controls.Add(cmbDersler);
            Controls.Add(btnEkle);
            Controls.Add(txtDersler);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDersler;
        private Button btnEkle;
        private ComboBox cmbDersler;
        private ListBox lstDersler;
        private Button btn_HicbirSeySecme;
    }
}