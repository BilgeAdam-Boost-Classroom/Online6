﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEkle = new Button();
            txtGiris = new TextBox();
            cbxListe = new ComboBox();
            lstListe = new ListBox();
            btnSecme = new Button();
            lblCombobox = new Label();
            lblListbox = new Label();
            SuspendLayout();
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(310, 26);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 0;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // txtGiris
            // 
            txtGiris.Location = new Point(39, 26);
            txtGiris.Name = "txtGiris";
            txtGiris.Size = new Size(244, 27);
            txtGiris.TabIndex = 1;
            // 
            // cbxListe
            // 
            cbxListe.FormattingEnabled = true;
            cbxListe.Location = new Point(39, 70);
            cbxListe.Name = "cbxListe";
            cbxListe.Size = new Size(365, 28);
            cbxListe.TabIndex = 2;
            cbxListe.SelectedIndexChanged += cbxListe_SelectedIndexChanged;
            // 
            // lstListe
            // 
            lstListe.FormattingEnabled = true;
            lstListe.ItemHeight = 20;
            lstListe.Location = new Point(39, 113);
            lstListe.Name = "lstListe";
            lstListe.Size = new Size(365, 244);
            lstListe.TabIndex = 3;
            lstListe.SelectedIndexChanged += lstListe_SelectedIndexChanged;
            // 
            // btnSecme
            // 
            btnSecme.Location = new Point(39, 373);
            btnSecme.Name = "btnSecme";
            btnSecme.Size = new Size(250, 53);
            btnSecme.TabIndex = 4;
            btnSecme.Text = "HİÇBİR ŞEY SEÇME";
            btnSecme.UseVisualStyleBackColor = true;
            btnSecme.Click += btnSecme_Click;
            // 
            // lblCombobox
            // 
            lblCombobox.AutoSize = true;
            lblCombobox.Location = new Point(421, 78);
            lblCombobox.Name = "lblCombobox";
            lblCombobox.Size = new Size(0, 20);
            lblCombobox.TabIndex = 5;
            // 
            // lblListbox
            // 
            lblListbox.AutoSize = true;
            lblListbox.Location = new Point(421, 113);
            lblListbox.Name = "lblListbox";
            lblListbox.Size = new Size(0, 20);
            lblListbox.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(483, 450);
            Controls.Add(lblListbox);
            Controls.Add(lblCombobox);
            Controls.Add(btnSecme);
            Controls.Add(lstListe);
            Controls.Add(cbxListe);
            Controls.Add(txtGiris);
            Controls.Add(btnEkle);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEkle;
        private TextBox txtGiris;
        private ComboBox cbxListe;
        private ListBox lstListe;
        private Button btnSecme;
        private Label lblCombobox;
        private Label lblListbox;
    }
}