﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbDersler = new ComboBox();
            txtDersGirisi = new TextBox();
            btnEkle = new Button();
            lbDersler = new ListBox();
            btnBirSeySecme = new Button();
            SuspendLayout();
            // 
            // cmbDersler
            // 
            cmbDersler.FormattingEnabled = true;
            cmbDersler.Location = new Point(14, 82);
            cmbDersler.Name = "cmbDersler";
            cmbDersler.Size = new Size(563, 28);
            cmbDersler.TabIndex = 0;
            cmbDersler.SelectedIndexChanged += cmbDersler_SelectedIndexChanged;
            // 
            // txtDersGirisi
            // 
            txtDersGirisi.Location = new Point(14, 24);
            txtDersGirisi.Name = "txtDersGirisi";
            txtDersGirisi.Size = new Size(444, 27);
            txtDersGirisi.TabIndex = 1;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(483, 7);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 61);
            btnEkle.TabIndex = 2;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // lbDersler
            // 
            lbDersler.FormattingEnabled = true;
            lbDersler.ItemHeight = 20;
            lbDersler.Location = new Point(16, 136);
            lbDersler.Name = "lbDersler";
            lbDersler.Size = new Size(561, 284);
            lbDersler.TabIndex = 3;
            lbDersler.SelectedIndexChanged += lbDersler_SelectedIndexChanged;
            // 
            // btnBirSeySecme
            // 
            btnBirSeySecme.Location = new Point(18, 438);
            btnBirSeySecme.Name = "btnBirSeySecme";
            btnBirSeySecme.Size = new Size(559, 46);
            btnBirSeySecme.TabIndex = 4;
            btnBirSeySecme.Text = "HICBIR SEY SECME!";
            btnBirSeySecme.UseVisualStyleBackColor = true;
            btnBirSeySecme.Click += btnBirSeySecme_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(600, 496);
            Controls.Add(btnBirSeySecme);
            Controls.Add(lbDersler);
            Controls.Add(btnEkle);
            Controls.Add(txtDersGirisi);
            Controls.Add(cmbDersler);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbDersler;
        private TextBox txtDersGirisi;
        private Button btnEkle;
        private ListBox lbDersler;
        private Button btnBirSeySecme;
    }
}