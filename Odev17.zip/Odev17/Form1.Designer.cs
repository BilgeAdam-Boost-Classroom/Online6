﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEkle = new Button();
            btnBiseYapma = new Button();
            txt1 = new TextBox();
            cbDersler = new ComboBox();
            lbDersler = new ListBox();
            SuspendLayout();
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(275, 3);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(112, 36);
            btnEkle.TabIndex = 0;
            btnEkle.Text = "Ekle";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnBiseYapma
            // 
            btnBiseYapma.Location = new Point(3, 409);
            btnBiseYapma.Name = "btnBiseYapma";
            btnBiseYapma.Size = new Size(384, 37);
            btnBiseYapma.TabIndex = 1;
            btnBiseYapma.Text = "Hiçbir Şey Yapma";
            btnBiseYapma.UseVisualStyleBackColor = true;
            btnBiseYapma.Click += btnBiseYapma_Click;
            // 
            // txt1
            // 
            txt1.Location = new Point(3, 11);
            txt1.Name = "txt1";
            txt1.Size = new Size(266, 23);
            txt1.TabIndex = 2;
            txt1.TextChanged += textBox1_TextChanged;
            // 
            // cbDersler
            // 
            cbDersler.FormattingEnabled = true;
            cbDersler.Location = new Point(3, 40);
            cbDersler.Name = "cbDersler";
            cbDersler.Size = new Size(384, 23);
            cbDersler.TabIndex = 3;
            cbDersler.SelectedIndexChanged += cbDersler_SelectedIndexChanged;
            // 
            // lbDersler
            // 
            lbDersler.FormattingEnabled = true;
            lbDersler.ItemHeight = 15;
            lbDersler.Location = new Point(3, 69);
            lbDersler.Name = "lbDersler";
            lbDersler.Size = new Size(384, 334);
            lbDersler.TabIndex = 4;
            lbDersler.SelectedIndexChanged += lbDersler_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(394, 459);
            Controls.Add(lbDersler);
            Controls.Add(cbDersler);
            Controls.Add(txt1);
            Controls.Add(btnBiseYapma);
            Controls.Add(btnEkle);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEkle;
        private Button btnBiseYapma;
        private TextBox txt1;
        private ComboBox cbDersler;
        private ListBox lbDersler;
    }
}