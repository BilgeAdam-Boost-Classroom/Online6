namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            string ders = txt1.Text;
            cbDersler.Items.Add(ders);
            lbDersler.Items.Add(ders);
        }

        private void lbDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("listboxtan se�ilen eleman: " + lbDersler.Text);
        }



        private void btnBiseYapma_Click(object sender, EventArgs e)
        {
            cbDersler.SelectedIndex = -1;
            lbDersler.SelectedIndex = -1;
        }

        private void cbDersler_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("listboxtan se�ilen eleman:" + cbDersler.Text);
        }
    }
}