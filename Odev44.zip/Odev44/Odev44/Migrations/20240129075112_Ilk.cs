﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev44.Migrations
{
    /// <inheritdoc />
    public partial class Ilk : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Arabalar",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Plaka = table.Column<string>(type: "nvarchar(25)", maxLength: 25, nullable: false),
                    Marka = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Model = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ModelYili = table.Column<int>(type: "int", nullable: false),
                    Renk = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Arabalar", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Arabalar",
                columns: new[] { "Id", "Marka", "Model", "ModelYili", "Plaka", "Renk" },
                values: new object[,]
                {
                    { 1, "Toyota", "Corolla", 2022, "34ABC01", "Siyah" },
                    { 2, "Honda", "Civic", 2021, "06XYZ99", "Beyaz" },
                    { 3, "Ford", "Focus", 2020, "07LMN22", "Gri" },
                    { 4, "Volkswagen", "Golf", 2023, "41DEF15", "Kırmızı" },
                    { 5, "Renault", "Megane", 2022, "55HIJ33", "Mavi" },
                    { 6, "Chevrolet", "Cruze", 2021, "20OPQ11", "Sarı" },
                    { 7, "Hyundai", "i20", 2020, "39RST88", "Yeşil" },
                    { 8, "Mercedes", "A-Class", 2023, "09UVW44", "Bordo" },
                    { 9, "BMW", "3 Serisi", 2022, "63XYZ66", "Turuncu" },
                    { 10, "Audi", "A3", 2021, "12ABC88", "Mor" },
                    { 11, "Peugeot", "208", 2022, "35DEF03", "Gri" },
                    { 12, "Fiat", "Egea", 2021, "08GHI22", "Beyaz" },
                    { 13, "Opel", "Corsa", 2020, "53JKL99", "Kırmızı" },
                    { 14, "Kia", "Rio", 2023, "19MNO11", "Siyah" },
                    { 15, "Skoda", "Octavia", 2022, "40PQR44", "Beyaz" },
                    { 16, "Seat", "Leon", 2021, "27STU77", "Mavi" },
                    { 17, "Mazda", "3", 2020, "14VWX88", "Siyah" },
                    { 18, "Citroen", "C3", 2023, "56YZA22", "Kırmızı" },
                    { 19, "Volvo", "S60", 2022, "21BCD66", "Gri" },
                    { 20, "Jaguar", "XE", 2021, "49DEF11", "Bordo" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Arabalar");
        }
    }
}
