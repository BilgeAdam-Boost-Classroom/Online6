﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Odev44.Data;

namespace Odev44.Areas.Musteri.Controllers
{
    [Area("Musteri")]
    public class ArabasController : Controller
    {
        private readonly UygulamaDbContext _context;

        public ArabasController(UygulamaDbContext context)
        {
            _context = context;
        }

        // GET: Musteri/Arabas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Arabalar.ToListAsync());
        }

        // GET: Musteri/Arabas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var araba = await _context.Arabalar
                .FirstOrDefaultAsync(m => m.Id == id);

            if (araba == null)
            {
                return NotFound();
            }

            return View(araba);
        }
    }
}