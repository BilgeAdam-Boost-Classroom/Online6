﻿using Microsoft.EntityFrameworkCore;

namespace Odev44.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options) { }

        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(
                new Araba() { Id = 1, Marka = "Nissan", Model = "R34 Skyline", Yil = 1997, IkinciElMi = true },
                new Araba() { Id = 2, Marka = "BMW", Model = "M4", Yil = 2023, IkinciElMi = false },
                new Araba() { Id = 3, Marka = "Volvo", Model = "XC-90", Yil = 2023, IkinciElMi = false },
                new Araba() { Id = 4, Marka = "Tesle", Model = "Model Y", Yil = 2022, IkinciElMi = true }
                );
        }
    }
}
