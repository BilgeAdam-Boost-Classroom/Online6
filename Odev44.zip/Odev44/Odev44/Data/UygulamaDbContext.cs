﻿using Microsoft.EntityFrameworkCore;

namespace Odev44.Data
{
    public class UygulamaDbContext : DbContext
    { 
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {
        }

        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(
                new Araba() { Id = 1, Plaka = "34ABC01", Marka = "Toyota", Model = "Corolla", ModelYili = 2022, Renk = "Siyah" },
                new Araba() { Id = 2, Plaka = "06XYZ99", Marka = "Honda", Model = "Civic", ModelYili = 2021, Renk = "Beyaz" },
                new Araba() { Id = 3, Plaka = "07LMN22", Marka = "Ford", Model = "Focus", ModelYili = 2020, Renk = "Gri" },
                new Araba() { Id = 4, Plaka = "41DEF15", Marka = "Volkswagen", Model = "Golf", ModelYili = 2023, Renk = "Kırmızı" },
                new Araba() { Id = 5, Plaka = "55HIJ33", Marka = "Renault", Model = "Megane", ModelYili = 2022, Renk = "Mavi" },
                new Araba() { Id = 6, Plaka = "20OPQ11", Marka = "Chevrolet", Model = "Cruze", ModelYili = 2021, Renk = "Sarı" },
                new Araba() { Id = 7, Plaka = "39RST88", Marka = "Hyundai", Model = "i20", ModelYili = 2020, Renk = "Yeşil" },
                new Araba() { Id = 8, Plaka = "09UVW44", Marka = "Mercedes", Model = "A-Class", ModelYili = 2023, Renk = "Bordo" },
                new Araba() { Id = 9, Plaka = "63XYZ66", Marka = "BMW", Model = "3 Serisi", ModelYili = 2022, Renk = "Turuncu" },
                new Araba() { Id = 10, Plaka = "12ABC88", Marka = "Audi", Model = "A3", ModelYili = 2021, Renk = "Mor" },
                new Araba() { Id = 11, Plaka = "35DEF03", Marka = "Peugeot", Model = "208", ModelYili = 2022, Renk = "Gri" },
                new Araba() { Id = 12, Plaka = "08GHI22", Marka = "Fiat", Model = "Egea", ModelYili = 2021, Renk = "Beyaz" },
                new Araba() { Id = 13, Plaka = "53JKL99", Marka = "Opel", Model = "Corsa", ModelYili = 2020, Renk = "Kırmızı" },
                new Araba() { Id = 14, Plaka = "19MNO11", Marka = "Kia", Model = "Rio", ModelYili = 2023, Renk = "Siyah" },
                new Araba() { Id = 15, Plaka = "40PQR44", Marka = "Skoda", Model = "Octavia", ModelYili = 2022, Renk = "Beyaz" },
                new Araba() { Id = 16, Plaka = "27STU77", Marka = "Seat", Model = "Leon", ModelYili = 2021, Renk = "Mavi" },
                new Araba() { Id = 17, Plaka = "14VWX88", Marka = "Mazda", Model = "3", ModelYili = 2020, Renk = "Siyah" },
                new Araba() { Id = 18, Plaka = "56YZA22", Marka = "Citroen", Model = "C3", ModelYili = 2023, Renk = "Kırmızı" },
                new Araba() { Id = 19, Plaka = "21BCD66", Marka = "Volvo", Model = "S60", ModelYili = 2022, Renk = "Gri" },
                new Araba() { Id = 20, Plaka = "49DEF11", Marka = "Jaguar", Model = "XE", ModelYili = 2021, Renk = "Bordo" }
                );
        }
    }  
}
