﻿using Microsoft.EntityFrameworkCore;
using Odev44.Data;

namespace Odev44.Data
{
    public class UygulamaDbContext:DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {

        }
        public DbSet<Araba> Arabalar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Araba>().HasData(
                new Araba() { Id=1,Marka="Opel",Model=2020,Fiyat=100},
                new Araba() { Id=2,Marka="Ford",Model=2012,Fiyat=200},
                new Araba() { Id=3,Marka="Toyota",Model=2023,Fiyat=300}
                );
        }
    }
}
