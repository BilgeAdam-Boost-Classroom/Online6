﻿using System.ComponentModel.DataAnnotations;

namespace Odev44.Data
{
    public class Araba
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(25)]
        [Display(Name ="Plaka")]
        public string Plaka { get; set; } = null!;

        [Required]
        [MaxLength(50)]
        [Display(Name = "Marka")]
        public string Marka { get; set; } = null!;

        [Required]
        [MaxLength(50)]
        [Display(Name = "Model")]
        public string Model { get; set; } = null!;

        public int ModelYili { get; set; }

        [Required]
        [MaxLength(50)]
        [Display(Name = "Renk")]
        public string Renk { get; set; } = null!;
    }
}
