﻿using Microsoft.EntityFrameworkCore;

namespace Odev44.Data
{
    public class Araba
    {
        public int Id { get; set; }
        public string Marka { get; set; } = null!;
        public int Model { get; set; }

        [Precision(18,2)]
        public decimal Fiyat { get; set; }
    }
}
