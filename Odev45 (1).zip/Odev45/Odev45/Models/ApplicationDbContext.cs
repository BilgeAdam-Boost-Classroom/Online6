﻿using Microsoft.EntityFrameworkCore;
using Odev45.Models;

namespace Odev45.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Hayvan> Hayvanlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Hayvan>().HasData(

                new Hayvan()
                {
                    Id = 1,
                    Ad = "Maymun",
                    Resim = "monkey-2790452_1280.jpg"
                }
                ); 
            ; 
        }
    }
}