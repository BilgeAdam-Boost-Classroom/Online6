﻿using Microsoft.AspNetCore.Mvc;
using Odev45.Data;

namespace Odev45.Component
{
    public class ListelemeViewComponent : ViewComponent
    {
        private readonly ApplicationDbContext _context;
       
        public ListelemeViewComponent(ApplicationDbContext dbContext)
        {
                _context = dbContext;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
           
            return View( _context.Hayvanlar.ToList());
        }
    }
}
