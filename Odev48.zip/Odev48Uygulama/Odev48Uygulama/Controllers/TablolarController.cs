﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev48Uygulama.Data;

namespace Odev48Uygulama.Controllers
{
    public class TablolarController : Controller
    {
        private readonly DbContext _context;
        private readonly HttpClient _httpClient;

        public TablolarController(DbContext context, HttpClient httpClient)
        {
            _context = context;
            _httpClient = httpClient;
        }

        // GET: Tablolar
        public async Task<IActionResult> Index()
        {
            return View(await _httpClient.GetFromJsonAsync<List<Tablo>>("https://localhost:7157/Tablo"));
        }

        // GET: Tablolar/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>("https://localhost:7157/Tablo/" + id);
            if (tablo == null)
            {
                return NotFound();
            }

            return View(tablo);
        }

        // GET: Tablolar/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tablolar/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Ad,Ressam,YapimTarihi")] Tablo tablo)
        {
            if (ModelState.IsValid)
            {
                await _httpClient.PostAsJsonAsync("https://localhost:7157/Tablo", tablo);
                return RedirectToAction(nameof(Index));
            }
            return View(tablo);
        }

        // GET: Tablolar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>($"https://localhost:7157/Tablo/{id}");
            if (tablo == null)
            {
                return NotFound();
            }
            return View(tablo);
        }

        // POST: Tablolar/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Ad,Ressam,YapimTarihi")] Tablo tablo)
        {
            if (id != tablo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _httpClient.PutAsJsonAsync($"https://localhost:7157/Tablo/Guncelle/{id}", tablo);
                }
                catch (DbUpdateConcurrencyException)
                {
                    
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tablo);
        }

        // GET: Tablolar/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tablo = await _httpClient.GetFromJsonAsync<Tablo>($"https://localhost:7157/Tablo/{id}");
            if (tablo == null)
            {
                return NotFound();
            }

            return View(tablo);
        }

        // POST: Tablolar/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tablo = await _httpClient.GetFromJsonAsync<Tablo>($"https://localhost:7157/Tablo/{id}");
            if (tablo != null)
            {
                await _httpClient.DeleteAsync($"https://localhost:7157/Tablo/Sil/{id}");
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
