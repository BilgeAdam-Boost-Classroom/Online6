﻿namespace Odev48Uygulama.Data
{
    public class Tablo
    {
        public int Id { get; set; }

        public string Ad { get; set; } = null!;

        public string Ressam { get; set; } = null!;

        public DateTime YapimTarihi { get; set; }
    }
}
