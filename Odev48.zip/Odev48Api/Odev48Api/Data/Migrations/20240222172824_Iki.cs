﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev48Api.Data.Migrations
{
    /// <inheritdoc />
    public partial class Iki : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Tablolar",
                columns: new[] { "Id", "Ad", "Ressam", "YapimTarihi" },
                values: new object[,]
                {
                    { 1, "Mona Lisa", "Leonardo da Vinci", new DateTime(1503, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, "Starry Night", "Vincent van Gogh", new DateTime(1889, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, "The Persistence of Memory", "Salvador Dali", new DateTime(1931, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, "The Scream", "Edvard Munch", new DateTime(1893, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 5, "The Last Supper", "Leonardo da Vinci", new DateTime(1498, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Tablolar",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Tablolar",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Tablolar",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Tablolar",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Tablolar",
                keyColumn: "Id",
                keyValue: 5);
        }
    }
}
