﻿using Microsoft.EntityFrameworkCore;

namespace Odev48Api.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options) { }

        public DbSet<Tablo> Tablolar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tablo>().HasData(
                new Tablo { Id = 1, Ad = "Mona Lisa", Ressam = "Leonardo da Vinci", YapimTarihi = new DateTime(1503, 1, 1) },
                new Tablo { Id = 2, Ad = "Starry Night", Ressam = "Vincent van Gogh", YapimTarihi = new DateTime(1889, 1, 1) },
                new Tablo { Id = 3, Ad = "The Persistence of Memory", Ressam = "Salvador Dali", YapimTarihi = new DateTime(1931, 1, 1) },
                new Tablo { Id = 4, Ad = "The Scream", Ressam = "Edvard Munch", YapimTarihi = new DateTime(1893, 1, 1) },
                new Tablo { Id = 5, Ad = "The Last Supper", Ressam = "Leonardo da Vinci", YapimTarihi = new DateTime(1498, 1, 1) }
                );
        }
    }
}
