﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Odev48Api.Data;

namespace Odev48Api.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TabloController : ControllerBase
    {
        private readonly UygulamaDbContext _db;

        public TabloController(UygulamaDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public ActionResult<List<Tablo>> HepsiniGetir()
        {
            return _db.Tablolar.ToList();
        }

        [HttpGet("{id:int}")]
        public ActionResult<Tablo> TabloGetir(int id)
        {
            if (id == 0)
                return BadRequest();
            var tablo = _db.Tablolar.FirstOrDefault(x => x.Id == id);
            if (tablo == null)
                return NotFound();

            return tablo;
        }

        [HttpPost]
        public ActionResult<Tablo> TabloEkle(Tablo tablo)
        {
            if (ModelState.IsValid)
            {
                var yeniTablo = new Tablo()
                {
                    Ad = tablo.Ad,
                    Ressam = tablo.Ressam,
                    YapimTarihi = tablo.YapimTarihi,
                };
                _db.Tablolar.Add(yeniTablo);
                _db.SaveChanges();
                return CreatedAtAction(nameof(TabloGetir), new { id = yeniTablo.Id }, yeniTablo);
            }
            return BadRequest(ModelState);
        }

        [HttpDelete("/Tablo/Sil/{id:int}")]
        public IActionResult TabloSil(int id)
        {
            if (id == 0)
                return BadRequest();
            var tablo = _db.Tablolar.FirstOrDefault(x => x.Id == id);

            if (tablo == null)
                return NotFound();
            _db.Tablolar.Remove(tablo);
            _db.SaveChanges();
            return Ok("Tablo başarıyla silindi");
        }

        [HttpPut("/Tablo/Guncelle/{id:int}")]
        public ActionResult<Tablo> TabloGuncelle(int id, Tablo tablo)
        {
            if (id != tablo.Id)
                return BadRequest();
            

            if (!_db.Tablolar.Any(x => x.Id == id))
                return NotFound();

            if (ModelState.IsValid)
            {
                _db.Tablolar.Update(tablo);
                _db.SaveChanges();
                return CreatedAtAction(nameof(TabloGetir), new { id = tablo.Id }, tablo);
            }

            return BadRequest(ModelState);
        }
    }
}
