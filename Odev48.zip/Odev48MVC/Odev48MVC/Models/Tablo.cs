﻿namespace Odev48MVC.Models
{
	public class Tablo
	{
		public int Id { get; set; }
		public string Ressam { get; set; } = null!;

		public DateOnly Tarih { get; set; }
	}
}
