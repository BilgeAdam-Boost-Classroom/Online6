﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Odev48API.Data;

namespace Odev48API.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class TabloController : ControllerBase
	{
		private readonly TabloDbContext _db;

		public TabloController(TabloDbContext db)
        {
			_db = db;
		}
        [HttpGet]
		public IActionResult GetItem()
		{
			return Ok(_db.Tablolar.ToList());
		}
	}
}
