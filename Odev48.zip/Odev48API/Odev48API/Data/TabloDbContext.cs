﻿using Microsoft.EntityFrameworkCore;

namespace Odev48API.Data
{
	public class TabloDbContext:DbContext
	{
		public TabloDbContext(DbContextOptions<TabloDbContext> options) : base(options)
		{

		}

        public DbSet<Tablo> Tablolar { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Tablo>().HasData(
				new Tablo() { Id=1,Ressam="Ressam1",Tarih=new DateOnly(1965,4,5)},
				new Tablo() { Id=2,Ressam="Ressam2",Tarih=new DateOnly(1966,7,19)},
				new Tablo() { Id=3,Ressam="Ressam2",Tarih=new DateOnly(1970,12,1)},
				new Tablo() { Id=4,Ressam="Ressam3",Tarih=new DateOnly(1955,6,18)},
				new Tablo() { Id=5,Ressam="Ressam1",Tarih=new DateOnly(1977,3,28)}
				);
		}
	}
}
