﻿namespace Odev48Mvc.Data
{
    public class YagliBoyaTablo
    {
        public int Id { get; set; }

        public string Ressam { get; set; } = null!;

        public DateTime ResminYapilmaTarihi { get; set; }
    }
}
