﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Odev48Mvc.Data;

    public class Odev48MvcContext : DbContext
    {
        public Odev48MvcContext (DbContextOptions<Odev48MvcContext> options)
            : base(options)
        {
        }

        public DbSet<Odev48Mvc.Data.YagliBoyaTablo> YagliBoyaTablo { get; set; } = default!;
    }
