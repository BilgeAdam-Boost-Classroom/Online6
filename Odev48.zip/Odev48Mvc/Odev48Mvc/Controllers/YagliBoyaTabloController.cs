﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev48Mvc.Data;

namespace Odev48Mvc.Controllers
{
    public class YagliBoyaTabloController : Controller
    {
        private readonly Odev48MvcContext _context;
        private readonly HttpClient _httpClient;

        public YagliBoyaTabloController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // GET: YagliBoyaTablo
        public async Task<IActionResult> Index()
        {
            return View(await _httpClient.GetFromJsonAsync<List<YagliBoyaTablo>>("https://localhost:7208/api/YagliBoyaTablo/TumTablolar"));
        }

        // GET: YagliBoyaTablo/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var yagliBoyaTablo = await _httpClient.GetFromJsonAsync<YagliBoyaTablo>($"https://localhost:7208/api/YagliBoyaTablo/IdYeGoreGetir?id=" + id);

            if (yagliBoyaTablo == null)
            {
                return NotFound();
            }

            return View(yagliBoyaTablo);
        }

        // GET: YagliBoyaTablo/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: YagliBoyaTablo/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Ressam,ResminYapilmaTarihi")] YagliBoyaTablo yagliBoyaTablo)
        {
            if (ModelState.IsValid)
            {
                await _httpClient.PostAsJsonAsync("https://localhost:7208/api/YagliBoyaTablo/TabloEkle", yagliBoyaTablo);

                return RedirectToAction(nameof(Index));
            }
            return View(yagliBoyaTablo);
        }

        // GET: YagliBoyaTablo/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var yagliBoyaTablo = await _httpClient.GetFromJsonAsync<YagliBoyaTablo>($"https://localhost:7208/api/YagliBoyaTablo/IdYeGoreGetir?id=" + id);

            if (yagliBoyaTablo == null)
            {
                return NotFound();
            }
            return View(yagliBoyaTablo);
        }

        // POST: YagliBoyaTablo/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Ressam,ResminYapilmaTarihi")] YagliBoyaTablo yagliBoyaTablo)
        {
            if (id != yagliBoyaTablo.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _httpClient.PutAsJsonAsync("https://localhost:7208/api/YagliBoyaTablo/TabloGuncelle?id=" + id, yagliBoyaTablo);
                }
                catch (DbUpdateConcurrencyException)
                {
                   
                }
                return RedirectToAction(nameof(Index));
            }
            return View(yagliBoyaTablo);
        }

        // GET: YagliBoyaTablo/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var yagliBoyaTablo = await _httpClient.GetFromJsonAsync<YagliBoyaTablo>($"https://localhost:7208/api/YagliBoyaTablo/IdYeGoreGetir?id=" + id);

            if (yagliBoyaTablo == null)
            {
                return NotFound();
            }

            return View(yagliBoyaTablo);
        }

        // POST: YagliBoyaTablo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var yagliBoyaTablo = await _httpClient.GetFromJsonAsync<YagliBoyaTablo>($"https://localhost:7208/api/YagliBoyaTablo/IdYeGoreGetir?id=" + id);


            if (yagliBoyaTablo != null)
            {
                // API'deki silmeyi kullanacagiz.
                await _httpClient.DeleteAsync($"https://localhost:7208/api/YagliBoyaTablo/TabloSil?id=" + id);
            }

            return RedirectToAction(nameof(Index));
        }

       
    }
}
