﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev48Mvc.Data;

namespace Odev48Mvc.Controllers
{
    public class OilPaintingsController : Controller
    {
        private readonly OilPaintingGaleriDbContext _context;
        private readonly HttpClient _httpClient;

        public OilPaintingsController(OilPaintingGaleriDbContext context, HttpClient httpClient)
        {
            _context = context;
            _httpClient = httpClient;
        }

        // GET: OilPaintings
        public async Task<IActionResult> Index()
        {
            return View(await _httpClient.GetFromJsonAsync<List<OilPainting>>("https://localhost:7196/api/OilPaintings"));
        }

        // GET: OilPaintings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oilPainting = await _httpClient.GetFromJsonAsync<OilPainting>($"https://localhost:7196/api/OilPaintings/{id}");
            if (oilPainting == null)
            {
                return NotFound();
            }

            return View(oilPainting);
        }

        // GET: OilPaintings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: OilPaintings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Artist,CreationDate")] OilPainting oilPainting)
        {
            if (ModelState.IsValid)
            {
                await _httpClient.PostAsJsonAsync("https://localhost:7196/api/OilPaintings", oilPainting);
                    return RedirectToAction(nameof(Index));
            }
            return View(oilPainting);
        }

        // GET: OilPaintings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oilPainting = await _httpClient.GetFromJsonAsync<OilPainting>($"https://localhost:7196/api/OilPaintings/{id}");
            if (oilPainting == null)
            {
                return NotFound();
            }
            return View(oilPainting);
        }

        // POST: OilPaintings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Artist,CreationDate")] OilPainting oilPainting)
        {
            if (id != oilPainting.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _httpClient.PutAsJsonAsync<OilPainting>($"https://localhost:7196/api/OilPaintings/{id}", oilPainting);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OilPaintingExists(oilPainting.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oilPainting);
        }

        // GET: OilPaintings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oilPainting = await _httpClient.GetFromJsonAsync<OilPainting>($"https://localhost:7196/api/OilPaintings/{id}");
            if (oilPainting == null)
            {
                return NotFound();
            }

            return View(oilPainting);
        }

        // POST: OilPaintings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oilPainting = await _httpClient.GetFromJsonAsync<OilPainting>($"https://localhost:7196/api/OilPaintings/{id}");
            if (oilPainting != null)
            {
                await _httpClient.DeleteAsync($"https://localhost:7196/api/OilPaintings/{id}");
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OilPaintingExists(int id)
        {
            return _context.OilPainting.Any(e => e.Id == id);
        }
    }
}
