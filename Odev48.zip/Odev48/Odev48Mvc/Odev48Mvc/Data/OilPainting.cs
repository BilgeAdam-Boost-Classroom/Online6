﻿namespace Odev48Mvc.Data
{
    public class OilPainting
    {
        public int Id { get; set; }
        public string Artist { get; set; } = null!;
        public DateTime CreationDate { get; set; }
    }
}
