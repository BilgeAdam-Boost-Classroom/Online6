﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Odev48Mvc.Data;

    public class OilPaintingGaleriDbContext : DbContext
    {
        public OilPaintingGaleriDbContext (DbContextOptions<OilPaintingGaleriDbContext> options)
            : base(options)
        {
        }

        public DbSet<Odev48Mvc.Data.OilPainting> OilPainting { get; set; } = default!;
    }
