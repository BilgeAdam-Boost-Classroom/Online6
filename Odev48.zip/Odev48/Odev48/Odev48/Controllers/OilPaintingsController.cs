﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Odev48.Data;

namespace Odev48.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OilPaintingsController : ControllerBase
    {
        private readonly OilPaintingDbContext _context;

        public OilPaintingsController(OilPaintingDbContext context)
        {
            _context = context;
        }

        // GET: api/OilPaintings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OilPainting>>> GetOilPainting()
        {
            return await _context.OilPainting.ToListAsync();
        }

        // GET: api/OilPaintings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OilPainting>> GetOilPainting(int id)
        {
            var oilPainting = await _context.OilPainting.FindAsync(id);

            if (oilPainting == null)
            {
                return NotFound();
            }

            return oilPainting;
        }

        // PUT: api/OilPaintings/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOilPainting(int id, OilPainting oilPainting)
        {
            if (id != oilPainting.Id)
            {
                return BadRequest();
            }

            _context.Entry(oilPainting).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OilPaintingExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/OilPaintings
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<OilPainting>> PostOilPainting(OilPainting oilPainting)
        {
            _context.OilPainting.Add(oilPainting);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOilPainting", new { id = oilPainting.Id }, oilPainting);
        }

        // DELETE: api/OilPaintings/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOilPainting(int id)
        {
            var oilPainting = await _context.OilPainting.FindAsync(id);
            if (oilPainting == null)
            {
                return NotFound();
            }

            _context.OilPainting.Remove(oilPainting);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OilPaintingExists(int id)
        {
            return _context.OilPainting.Any(e => e.Id == id);
        }
    }
}
