﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Odev48.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OilPainting",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Artist = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreationDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OilPainting", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "OilPainting",
                columns: new[] { "Id", "Artist", "CreationDate" },
                values: new object[,]
                {
                    { 1, "Leonardo da Vinci", new DateTime(1503, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, "Vincent van Gogh", new DateTime(1889, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, "Pablo Picasso", new DateTime(1907, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, "Claude Monet", new DateTime(1872, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OilPainting");
        }
    }
}
