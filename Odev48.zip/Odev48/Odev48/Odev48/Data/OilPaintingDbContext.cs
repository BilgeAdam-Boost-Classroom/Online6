﻿using Microsoft.EntityFrameworkCore;
using Odev48.Data;

namespace Odev48.Data
{
    public class OilPaintingDbContext : DbContext
    {
        public OilPaintingDbContext(DbContextOptions<OilPaintingDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<OilPainting>().HasData(
                new OilPainting { Id = 1, Artist = "Leonardo da Vinci", CreationDate = new DateTime(1503, 1, 1) },
                new OilPainting { Id = 2, Artist = "Vincent van Gogh", CreationDate = new DateTime(1889, 1, 1) },
                new OilPainting { Id = 3, Artist = "Pablo Picasso", CreationDate = new DateTime(1907, 1, 1) },
                new OilPainting { Id = 4, Artist = "Claude Monet", CreationDate = new DateTime(1872, 1, 1) }
            );
        }
        public DbSet<Odev48.Data.OilPainting> OilPainting { get; set; } = default!;
    }
}
