﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Odev48WebApi.Data;
using Odev48WebApi.DTOs;

namespace Odev48WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class YagliBoyaTabloController : ControllerBase
    {
        private readonly UygulamaDbContext _db;

        public YagliBoyaTabloController(UygulamaDbContext db)
        {
            _db = db;
        }


        // tüm tablolar
        [HttpGet("TumTablolar")]
        public IActionResult TumTablolar()
        {
            return Ok(_db.YagliBoyaTablolar.ToList());
        }

        // id'ye göre tablo
        [HttpGet("IdYeGoreGetir")]
        public IActionResult GetById(int id)
        {
            var tablo = _db.YagliBoyaTablolar.FirstOrDefault(t => t.Id == id);

            if (tablo == null)
            {
                return NotFound();
            }

            return Ok(tablo);
        }

        [HttpPost("TabloEkle")]
        public IActionResult PostTablo(PostYagliBoyaTabloDto tablo)
        {
            if (ModelState.IsValid)
            {
                var yeni = new YagliBoyaTablo()
                {
                    Ressam = tablo.Ressam,
                    ResminYapilmaTarihi = tablo.ResminYapilmaTarihi
                };

                _db.YagliBoyaTablolar.Add(yeni);
                _db.SaveChanges();
                return CreatedAtAction("TumTablolar", new { id = yeni.Id }, yeni);
                // return Ok("Eklendi!!");
                // return Ok(araba);
            }

            return BadRequest(ModelState);
        }


        [HttpPut("TabloGuncelle")] // güncelleme
        public IActionResult PutTablo(int id, YagliBoyaTablo tablo)
        {
            if (id != tablo.Id)
            {
                return BadRequest();
            }

            if (!_db.YagliBoyaTablolar.Any(x => x.Id == id))
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _db.YagliBoyaTablolar.Update(tablo);
                _db.SaveChanges();
                return NoContent();
            }

            return BadRequest(ModelState);
        }

        [HttpDelete("TabloSil")] // sil
        public IActionResult DeleteAraba(int id)
        {
            var item = _db.YagliBoyaTablolar.Find(id);

            if (item == null)
            {
                return NotFound();
            }

            _db.YagliBoyaTablolar.Remove(item);
            _db.SaveChanges();
            return NoContent();
        }
    }
}
