﻿using Microsoft.EntityFrameworkCore;

namespace Odev48WebApi.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {

        }
        public DbSet<YagliBoyaTablo> YagliBoyaTablolar { get; set; }
    }
}
