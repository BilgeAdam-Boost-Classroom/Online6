﻿namespace Odev48WebApi.DTOs
{
    public class PostYagliBoyaTabloDto
    {
        public string Ressam { get; set; } = null!;

        public DateTime ResminYapilmaTarihi { get; set; }
    }
}
