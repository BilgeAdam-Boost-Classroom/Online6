﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Odev46.Data.Migrations
{
    /// <inheritdoc />
    public partial class Iki : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Oyunlar_BarkodNo",
                table: "Oyunlar",
                column: "BarkodNo",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Oyunlar_BarkodNo",
                table: "Oyunlar");
        }
    }
}
