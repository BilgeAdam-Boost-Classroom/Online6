﻿using Microsoft.EntityFrameworkCore;

namespace Odev46.Data
{
    public class UygulamaDBContext : DbContext
    {
        public UygulamaDBContext(DbContextOptions<UygulamaDBContext> options) : base(options)
        {

        }

        public DbSet<Oyun> Oyunlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Oyun>().HasIndex(g => g.BarkodNo).IsUnique();

        }
    }
}
