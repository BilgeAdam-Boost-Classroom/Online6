﻿using System.ComponentModel;

namespace Odev46.Data
{
    public class Oyun
    {
        /*
         Bir oyun dükkanındaki video oyunlarının listesinin tutulduğu bir veritabanı oluşturunuz.
        Oyunların adı, fiyatı, platformu, barkod numarası ve tek platform olup olmadığı bilgilerini tutunuz.
        platform kavramı bilgisayar veya başka bir oyun konsolu olabilir. (Yani oyunun bilgisayar ve/veya 
        başka bir oyun konsolu için piyasada olup olmadığı bilgisini tutunuz.)

        Eğer oyun tek platform ise aynı oyun isminden başka olmamalıdır. Tek platform değilse aynı isimde
        farklı platformlarda oyun olabilir. (ekleme ve güncelleme işlemlerinde bu kurala dikkat ediniz.)

        oyun eklerken barkod numarası otomatik olarak oluşturulmalıdır. (Barkod numarası rastgele oluşturulmalı ve 
        13 basamaklı olmalıdır.)

        oyun eklerken rastgele olarak üretilen barkod numarası daha önceden üretilmiş olmamalıdır.

        (veritabanında barkod numarası unique olmalıdır.)
        güncelleme yaparken barkod numarası ile ilgili bir işlem yapılmamalıdır.

        */

        public int Id { get; set; }

        [DisplayName("Oyun Adı")]
        public string OyunAdi { get; set; }

        [DisplayName("Fiyat")]
        public int Fiyati { get; set; }

        [DisplayName("Platformu")]
        public string Platform { get; set; }

        [DisplayName("Barkod Numarası")]
        public long BarkodNo { get; set; }

        [DisplayName("Tek Platform Mu?")]
        public bool TekPlatform { get; set; }

        public Oyun()
        {
            BarkodNo = BarkodNoOlustur();
        }   

        private long BarkodNoOlustur()
        {
            Random rnd = new Random();
            long barkodNo = rnd.NextInt64(1000000000000, 9999999999999);
            return barkodNo;
        }




    }
}
