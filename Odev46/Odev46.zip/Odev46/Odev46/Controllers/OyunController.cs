﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev46.Data;

namespace Odev46.Controllers
{
    public class OyunController : Controller
    {
        private readonly UygulamaDBContext _context;

        public OyunController(UygulamaDBContext context)
        {
            _context = context;
        }

        // GET: Oyun
        public async Task<IActionResult> Index()
        {
            return View(await _context.Oyunlar.ToListAsync());
        }

        // GET: Oyun/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oyun == null)
            {
                return NotFound();
            }

            return View(oyun);
        }

        // GET: Oyun/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Oyun/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,OyunAdi,Fiyati,Platform,BarkodNo,TekPlatform")] Oyun oyun)
        {
            if(_context.Oyunlar.Any(o => o.OyunAdi == oyun.OyunAdi && o.TekPlatform))
            {
                ModelState.AddModelError("OyunAdi", "Bu oyun tek platform olarak kayıtlı.");
                return View(oyun);
            }


            if (ModelState.IsValid)
            {
                _context.Add(oyun);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(oyun);
        }

        // GET: Oyun/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar.FindAsync(id);
            if (oyun == null)
            {
                return NotFound();
            }
            return View(oyun);
        }

        // POST: Oyun/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,OyunAdi,Fiyati,Platform,BarkodNo,TekPlatform")] Oyun oyun)
        {
            if (id != oyun.Id)
            {
                return NotFound();
            }

            if (_context.Oyunlar.Any(o => o.OyunAdi == oyun.OyunAdi && o.TekPlatform))
            {
                ModelState.AddModelError("OyunAdi", "Bu oyun tek platform olarak kayıtlı.");
                return View(oyun);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(oyun);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OyunExists(oyun.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oyun);
        }

        // GET: Oyun/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oyun = await _context.Oyunlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oyun == null)
            {
                return NotFound();
            }

            return View(oyun);
        }

        // POST: Oyun/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oyun = await _context.Oyunlar.FindAsync(id);
            if (oyun != null)
            {
                _context.Oyunlar.Remove(oyun);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OyunExists(int id)
        {
            return _context.Oyunlar.Any(e => e.Id == id);
        }
    }
}
