﻿namespace Odev17
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDers = new TextBox();
            label1 = new Label();
            btnEkle = new Button();
            cmbDers = new ComboBox();
            lstDers = new ListBox();
            btnSecme = new Button();
            SuspendLayout();
            // 
            // txtDers
            // 
            txtDers.Location = new Point(65, 18);
            txtDers.Margin = new Padding(4);
            txtDers.Name = "txtDers";
            txtDers.Size = new Size(252, 29);
            txtDers.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 21);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(45, 21);
            label1.TabIndex = 1;
            label1.Text = "Ders:";
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(325, 13);
            btnEkle.Margin = new Padding(4);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(153, 36);
            btnEkle.TabIndex = 2;
            btnEkle.Text = "Ekle >>";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // cmbDers
            // 
            cmbDers.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDers.FormattingEnabled = true;
            cmbDers.Location = new Point(12, 56);
            cmbDers.Name = "cmbDers";
            cmbDers.Size = new Size(466, 29);
            cmbDers.TabIndex = 3;
            cmbDers.SelectedIndexChanged += cmbDers_SelectedIndexChanged;
            // 
            // lstDers
            // 
            lstDers.FormattingEnabled = true;
            lstDers.ItemHeight = 21;
            lstDers.Location = new Point(11, 91);
            lstDers.Name = "lstDers";
            lstDers.Size = new Size(467, 256);
            lstDers.TabIndex = 4;
            lstDers.SelectedIndexChanged += lstDers_SelectedIndexChanged;
            // 
            // btnSecme
            // 
            btnSecme.Location = new Point(12, 353);
            btnSecme.Name = "btnSecme";
            btnSecme.Size = new Size(466, 47);
            btnSecme.TabIndex = 5;
            btnSecme.Text = "Hiçbir Şey Seçme!";
            btnSecme.UseVisualStyleBackColor = true;
            btnSecme.Click += btnSecme_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(491, 408);
            Controls.Add(btnSecme);
            Controls.Add(lstDers);
            Controls.Add(cmbDers);
            Controls.Add(btnEkle);
            Controls.Add(label1);
            Controls.Add(txtDers);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Ders Seçme Ekranı";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDers;
        private Label label1;
        private Button btnEkle;
        private ComboBox cmbDers;
        private ListBox lstDers;
        private Button btnSecme;
    }
}