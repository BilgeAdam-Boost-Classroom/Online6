namespace Odev17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDers.Text != "")
                {
                    cmbDers.Items.Add(txtDers.Text);
                    lstDers.Items.Add(txtDers.Text);
                    txtDers.Text = "";
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Hata: " + ex.Message, "Hata Olu�tu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSecme_Click(object sender, EventArgs e)
        {
            lstDers.SelectedIndex = -1;
            cmbDers.SelectedIndex = -1;
        }

        private void lstDers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDers.SelectedIndex != -1)
                MessageBox.Show("Se�ilen Ders: " + lstDers.Text, "Se�ilen ders", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void cmbDers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbDers.SelectedIndex != -1)
                MessageBox.Show("Se�ilen Ders: " + cmbDers.Text, "Se�ilen ders", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}