﻿namespace odev18_HasanSalgin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSifre = new TextBox();
            label1 = new Label();
            lblZorlukDerecesi = new Label();
            SuspendLayout();
            // 
            // txtSifre
            // 
            txtSifre.Location = new Point(31, 34);
            txtSifre.Name = "txtSifre";
            txtSifre.Size = new Size(459, 29);
            txtSifre.TabIndex = 0;
            txtSifre.TextChanged += txtSifre_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 109);
            label1.Name = "label1";
            label1.Size = new Size(170, 21);
            label1.TabIndex = 1;
            label1.Text = "şifre zorluk derecesi :";
            // 
            // lblZorlukDerecesi
            // 
            lblZorlukDerecesi.AutoSize = true;
            lblZorlukDerecesi.Location = new Point(239, 109);
            lblZorlukDerecesi.Name = "lblZorlukDerecesi";
            lblZorlukDerecesi.Size = new Size(0, 21);
            lblZorlukDerecesi.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(516, 265);
            Controls.Add(lblZorlukDerecesi);
            Controls.Add(label1);
            Controls.Add(txtSifre);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "şifre zorluk derecesinin belirlenmesi";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtSifre;
        private Label label1;
        private Label lblZorlukDerecesi;
    }
}