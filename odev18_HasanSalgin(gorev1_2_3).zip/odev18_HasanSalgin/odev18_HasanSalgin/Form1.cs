using System.Diagnostics.Metrics;

namespace odev18_HasanSalgin
{
    public partial class Form1 : Form
    {
        bool harfVar = false;
        bool rakamVar = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            foreach (char karakter in txtSifre.Text)
            {
                if (char.IsLetter(karakter))
                {
                    harfVar = true;
                }
                else if (char.IsDigit(karakter))
                {
                    rakamVar = true;
                }

                // Hem harf hem rakam bulunduysa d�ng�y� sonland�r
                if (harfVar && rakamVar)
                {
                    break;
                }
            }

            if (txtSifre.Text.Contains(' '))   // bo�luk kontrol�
            {
                lblZorlukDerecesi.ForeColor = Color.Purple;
                lblZorlukDerecesi.Text = "�ifre de space olamaz!!!";
            }
            else if (txtSifre.Text.Length <= 6)
            {
                lblZorlukDerecesi.ForeColor = Color.Red;
                lblZorlukDerecesi.Text = "d���k";
            }
            else if (txtSifre.Text.All(char.IsDigit) || txtSifre.Text.All(char.IsLetter))
            {
                lblZorlukDerecesi.ForeColor = Color.Red;
                lblZorlukDerecesi.Text = "d���k";
            }
            else if (txtSifre.Text.Length == 7 && harfVar && rakamVar)
            {
                lblZorlukDerecesi.ForeColor = Color.Orange;
                lblZorlukDerecesi.Text = "orta";
            }
            else if (txtSifre.Text.Length >= 8 && harfVar && rakamVar)
            {
                lblZorlukDerecesi.ForeColor = Color.Green;
                lblZorlukDerecesi.Text = "y�ksek";
            }

        }
    }
}