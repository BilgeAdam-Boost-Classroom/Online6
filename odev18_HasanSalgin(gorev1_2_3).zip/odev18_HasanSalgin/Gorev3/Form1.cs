namespace Gorev3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            if (txtKullaniciAdi.Text =="admin" && txtParola.Text =="1234")
            {
               Form2 form2 = new Form2();
                form2.Owner = this;
                form2.ShowDialog();
            }
            else if (txtKullaniciAdi.Text == "" || txtParola.Text == "")
            {
                DialogResult dr1 = MessageBox.Show("alanlar bo� kalamaz !!!", "uyar� mesaj�", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
            else
            {
                DialogResult dr2 = MessageBox.Show("kullan�c� ad� veya parola hatal� !!!", "uyar� mesaj�", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
    }
}