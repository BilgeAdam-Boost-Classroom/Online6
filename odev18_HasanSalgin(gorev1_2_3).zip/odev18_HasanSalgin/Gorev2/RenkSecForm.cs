﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gorev2
{
    public partial class RenkSecForm : Form
    {

        public RenkSecForm()
        {
            InitializeComponent();
            cmbRenk.Items.Add(Color.AliceBlue);
            cmbRenk.Items.Add(Color.Red);
            cmbRenk.Items.Add(Color.Green);
            cmbRenk.Items.Add(Color.Blue);
        }


        private void btnTamam_Click(object sender, EventArgs e)
        {
            if (cmbRenk.SelectedItem is Color renk)
            {
                Owner.BackColor = renk;
            }
            Close();
        }


        private void btnIptal_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
