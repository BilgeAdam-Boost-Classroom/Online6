﻿namespace Gorev2
{
    partial class RenkSecForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbRenk = new ComboBox();
            btnTamam = new Button();
            btnIptal = new Button();
            SuspendLayout();
            // 
            // cmbRenk
            // 
            cmbRenk.FormattingEnabled = true;
            cmbRenk.Location = new Point(26, 26);
            cmbRenk.Name = "cmbRenk";
            cmbRenk.Size = new Size(342, 29);
            cmbRenk.TabIndex = 0;
            // 
            // btnTamam
            // 
            btnTamam.Location = new Point(26, 99);
            btnTamam.Name = "btnTamam";
            btnTamam.Size = new Size(159, 123);
            btnTamam.TabIndex = 1;
            btnTamam.Text = "TAMAM";
            btnTamam.UseVisualStyleBackColor = true;
            btnTamam.Click += btnTamam_Click;
            // 
            // btnIptal
            // 
            btnIptal.Location = new Point(209, 99);
            btnIptal.Name = "btnIptal";
            btnIptal.Size = new Size(159, 123);
            btnIptal.TabIndex = 1;
            btnIptal.Text = "İPTAL";
            btnIptal.UseVisualStyleBackColor = true;
            btnIptal.Click += btnIptal_Click;
            // 
            // RenkSecForm
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(417, 293);
            Controls.Add(btnIptal);
            Controls.Add(btnTamam);
            Controls.Add(cmbRenk);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(4);
            Name = "RenkSecForm";
            Text = "RenkSecForm";
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbRenk;
        private Button btnTamam;
        private Button btnIptal;
    }
}