namespace Gorev2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRenk_Click(object sender, EventArgs e)
        {
            RenkSecForm frmDuzenle = new RenkSecForm();
            frmDuzenle.Owner = this;
            frmDuzenle.ShowDialog();
        }
    }
}