﻿/*
1) AyHesapla adında, aldığı DATETIME cinsinden değerin 
üzerinden kaç ay geçtiğini hesaplayan ve bu değeri 
geri döndüren bir fonksiyon oluşturunuz. Ardından, 
Employees tablosundaki her bir çalışan için işe 
başlama tarihinden bu yana kaç ay geçtiğini, 
bu fonksiyonu kullanarak listeleyiniz.
*/

GO
CREATE FUNCTION AyHesapla(@Tarih DATE) 
RETURNS  int
AS
BEGIN
    RETURN DATEDIFF(MONTH, @Tarih, GETDATE() )
END

GO

select FirstName, LastName, dbo.AyHesapla(HireDate)'Kaç Ay Geçmiş' from Employees

/* 2) İki tarih arasındaki farkı alan ve 
bu farkı gün olarak döndüren bir fonksiyon yazınız. 
Daha sonra orders tablosundaki her satır için
OrderDate ile ShippedDate arasındaki gün sayısını, 
bu fonksiyonu kullanarak listeleyiniz.*/

GO
CREATE FUNCTION GunFarkHesapla(@Tarih2 DATE, @Tarih1 DATE) 
RETURNS  int
AS
BEGIN
    RETURN DATEDIFF(DAY, @Tarih1, @Tarih2 )
END

Select OrderID, OrderDate, ShippedDate,
dbo.GunFarkHesapla(ShippedDate, OrderDate)'Gün Farkı' from Orders

/* 3) Employees tablosundan firstname’leri, 
dışarıdan gönderilen harf ile başlayanları tablo 
olarak döndüren fonksiyon yazınız. 
Ardından bu fonksiyonu kullanarak
A ile başlayanları listeleyiniz.*/

GO
CREATE FUNCTION IsimAramaBasHarfIle(@Aranan NVARCHAR(MAX))
  RETURNS TABLE
AS
  RETURN select FirstName, LastName from Employees
  where FirstName LIKE @Aranan+'%'
GO

select * from IsimAramaBasHarfIle('A')

/* 4) Order details tablosundaki unitprice’ların 
kırpılmış ortalamasını hesaplayan stored procedure yazınız.
(Kırpılmış ortalama: En küçük ve en büyük değerler 
dahil edilmeden hesaplanan aritmetik ortalamadır. 
Bölerken, (terim sayısı-2) ’ye bölünmelidir.)*/

CREATE PROCEDURE spKirpilmisOrtalama
AS
BEGIN
	DECLARE @Min DECIMAL(18, 2);
    DECLARE @Max DECIMAL(18, 2);
	DECLARE @Toplam DECIMAL(18, 2);
	DECLARE @KirpilmisToplam DECIMAL(18, 2);
    DECLARE @Adet INT;

	SELECT @Min = MIN(UnitPrice), @Max = MAX(UnitPrice)
    FROM [Order Details];

	SELECT @Toplam = SUM(UnitPrice)
    FROM [Order Details];

	SELECT @KirpilmisToplam = @Toplam - (@Min + @Max);

	SELECT @Adet = COUNT(*) FROM [Order Details];

    SELECT @KirpilmisToplam / (@Adet  - 2) AS KirpilmisOrtalama;
END
GO

spKirpilmisOrtalama
