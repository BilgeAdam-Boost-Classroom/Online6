﻿USE master;
GO

DROP DATABASE IF EXISTS Odev27;
GO

CREATE DATABASE Odev27;
GO

USE Odev27;
GO

CREATE TABLE Ogretmenler  
(
	OgretmenId INT PRIMARY KEY IDENTITY(1, 1),
    OgretmenAd NVARCHAR(50) NOT NULL,
	OgretmenSoyad NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Siniflar
(
    SinifId INT PRIMARY KEY IDENTITY(1, 1),
    SinifAd NVARCHAR(10) NOT NULL UNIQUE,
	OgretmenId INT FOREIGN KEY REFERENCES Ogretmenler(OgretmenId) NULL
);
GO



INSERT INTO Ogretmenler (OgretmenAd, OgretmenSoyad) VALUES
('Salih', 'Yılmaz'),
('Burcu', 'Demir'),
('Nazmi', 'Yıldırım'),
('Pelin', 'Aksoy'),
('Remzi', 'Kaya');
GO

INSERT INTO Siniflar (SinifAd, OgretmenId) VALUES
('A100', 1),  
('A101', 2),  
('A102', 3),  
('A103', 5),  
('A104', 5),  
('A105', 5),  
('A106', NULL),  
('A107', NULL), 
('A108', NULL), 
('A109', NULL); 
GO

SELECT * FROM Ogretmenler;
SELECT * FROM Siniflar;

-- Sınıfı olan öğretmenlerin ad, soyad, sınıfId ve sınıfad listesi
SELECT 
    o.OgretmenAd,
    o.OgretmenSoyad,
    s.SinifId,
    s.SinifAd
FROM Ogretmenler o
JOIN Siniflar s ON o.OgretmenId = s.OgretmenId;

-- Sınıfı olmayan öğretmenlerin ad ve soyad listesi
SELECT 
    OgretmenAd,
    OgretmenSoyad
FROM Ogretmenler
WHERE OgretmenId NOT IN (SELECT DISTINCT OgretmenId FROM Siniflar WHERE OgretmenId IS NOT NULL);

-- Öğretmeni olmayan sınıfların Id’leri ve sınıfadları listesi
SELECT 
    SinifId,
    SinifAd
FROM Siniflar
WHERE OgretmenId IS NULL;

-- GENEL liste: Ogretmen ad, ogretmen soyad, sınıfId ve sınıfad. Değerler varsa yazmalı, yoksa NULL yazmalı.
SELECT 
    o.OgretmenAd,
    o.OgretmenSoyad,
    s.SinifId,
    s.SinifAd
FROM Ogretmenler o
FULL JOIN Siniflar s ON o.OgretmenId = s.OgretmenId;