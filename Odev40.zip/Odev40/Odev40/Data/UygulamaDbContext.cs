﻿using Microsoft.EntityFrameworkCore;

namespace Odev40.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {

        }

        public DbSet<Oyun> Oyunlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Oyun>().HasData(
                new Oyun() { Id = 1, Ad = "God of War", TekPlatform = false },
                new Oyun() { Id = 2, Ad = "Super Mario", TekPlatform = true },
                new Oyun() { Id = 3, Ad = "Fifa 23", TekPlatform = false },
                new Oyun() { Id = 4, Ad = "Contra", TekPlatform = true }
                );
        }
    }
}
