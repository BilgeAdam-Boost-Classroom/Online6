﻿using Microsoft.EntityFrameworkCore;

namespace Odev40.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {

        }

        public DbSet<Oyun> Oyunlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Oyun>().HasData(
                new Oyun { Id = 1, Ad = "The Witcher 3: Wild Hunt", TekPlatform = false },
                new Oyun { Id = 2, Ad = "Grand Theft Auto V", TekPlatform = false },
                new Oyun { Id = 3, Ad = "Red Dead Redemption 2", TekPlatform = false },
                new Oyun { Id = 4, Ad = "FIFA 22", TekPlatform = true },
                new Oyun { Id = 5, Ad = "The Legend of Zelda: Breath of the Wild", TekPlatform = true }
                );
        }
    }
}
