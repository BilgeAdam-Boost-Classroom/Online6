﻿using Microsoft.EntityFrameworkCore;

namespace Odev40.Data
{
    public class UygulamaDbContext: DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options)
        {
            
        }
        public DbSet<Oyun> Oyunlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Oyun>().HasData(
                new Oyun() { Id = 1, Ad = "Fifa", TekPlatform = true },
                new Oyun() { Id = 2, Ad = "Tekken", TekPlatform = false },
                new Oyun() { Id = 3, Ad = "Zuma", TekPlatform = true },
                new Oyun() { Id = 4, Ad = "Counter Strike 1.5", TekPlatform = true }
                );
        }
    }
}
