﻿namespace Odev40.Data
{
    public class Oyun
    {
        public int Id { get; set; }
        public string Ad { get; set; } = null!;
        public bool TekPlatform { get; set; }
    }
}
