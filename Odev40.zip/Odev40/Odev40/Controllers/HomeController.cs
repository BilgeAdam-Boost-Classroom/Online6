using Microsoft.AspNetCore.Mvc;
using Odev40.Data;
using Odev40.Models;
using System.Diagnostics;

namespace Odev40.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly UygulamaDbContext _db;

		public HomeController(ILogger<HomeController> logger,UygulamaDbContext db)
		{
			_logger = logger;
			_db = db;
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
		public IActionResult Index()
		{
			return View(_db.Oyunlar.ToList());
		}
		public IActionResult Ekle()
		{
			return View();
		}
		[HttpPost]
		public IActionResult Ekle(Oyun oyun)
		{
			if (ModelState.IsValid)
			{
				_db.Oyunlar.Add(oyun);
				_db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View();
		}

		public IActionResult Sil(int id)
		{
			return View(_db.Oyunlar.Find(id));
		}
		[HttpPost]
		public IActionResult Sil(Oyun oyun)
		{
			_db.Oyunlar.Remove(oyun);
			_db.SaveChanges();
			return RedirectToAction("Index");
		}
		public IActionResult Guncelle(int id)
		{
			return View(_db.Oyunlar.Find(id));
		}
		[HttpPost]
		public IActionResult Guncelle(Oyun oyun)
		{
			_db.Update(oyun);
			_db.SaveChanges();
			return RedirectToAction("Index");

		}
	}
}
