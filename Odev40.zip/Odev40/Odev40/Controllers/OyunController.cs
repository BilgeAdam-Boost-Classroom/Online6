﻿using Microsoft.AspNetCore.Mvc;
using Odev40.Data;

namespace Odev40.Controllers
{
    public class OyunController : Controller
    {
        private readonly UygulamaDbContext _db;

        public OyunController(UygulamaDbContext db)
        {
            _db = db;
        }
        public IActionResult Listele()
        {
            return View(_db.Oyunlar.ToList());
        }
        public IActionResult Ekle()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Ekle(Oyun oyun)
        {
            _db.Oyunlar.Add(oyun);
            _db.SaveChanges();
            return RedirectToAction("Listele");
        }

        public IActionResult Guncelle(int id)
        {
            Oyun oyun = _db.Oyunlar.Find(id);
            return View(oyun);
        }
        [HttpPost]
        public IActionResult Guncelle(Oyun oyun)
        {
            _db.Oyunlar.Update(oyun);
            _db.SaveChanges();
            return RedirectToAction("Listele");
        }

        public IActionResult Sil(int id)
        {
            Oyun oyun = _db.Oyunlar.Find(id);
            return View(oyun);
        }
        [HttpPost]
        public IActionResult Sil(Oyun oyun)
        {
            _db.Oyunlar.Remove(oyun);
            _db.SaveChanges();
            return RedirectToAction("Listele");
        }
    }
}
