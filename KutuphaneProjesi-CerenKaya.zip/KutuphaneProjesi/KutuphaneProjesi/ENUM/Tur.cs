﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KutuphaneProjesi.ENUM
{
    public enum Tur
    {
        Roman,
        Masal,
        Hikaye,
        Siir,
        CizgiRoman        
    }
}
