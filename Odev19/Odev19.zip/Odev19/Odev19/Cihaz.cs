﻿
namespace Odev19
{
    public class Cihaz
    {
        Random rnd = new Random();
        public Cihaz() {  }
        public Cihaz(string ad, DateOnly uretimTarihi, decimal fiyat)
        {
            Ad = ad;
            Fiyat = fiyat;
            UretimTarihi = uretimTarihi;
            SeriNumarasiUret();
        }
        public string Ad { get; set; } = string.Empty;
        public decimal Fiyat { get; set; } = 0;
        private int SeriNumarasi { get; set; } = 0;
        public DateOnly UretimTarihi { get; set; } = DateOnly.MinValue;

        public void SeriNumarasiUret()
        {
            SeriNumarasi = rnd.Next(1000, 10000);
        }

        public void BilgileriGoster()
        {
            Console.WriteLine("Cihaz Özellikleri:\n" +
                "Adı: " + Ad + "\n" +
                "Seri Numarası: " + SeriNumarasi + "\n" +
                "Üretim tarihi: " + UretimTarihi + "\n" +
                "Fiyatı: " + Fiyat + "\n");
        }
    }
}
