﻿using Odev19;

Cihaz cihaz = new Cihaz("Siemens", new DateOnly(2023, 10, 10), 1249.99m);
Cihaz cihaz2 = new Cihaz("Bosch", new DateOnly(2022, 05, 19), 999.99m);

cihaz.BilgileriGoster();
cihaz2.BilgileriGoster();


Console.ReadLine();