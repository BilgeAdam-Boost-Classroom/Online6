﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace soru2
{
    public partial class form2 : Form
    {
        public form2()
        {
            InitializeComponent();
        }

        public object SecilenRenk { get; internal set; }

        private void btnRenk_Click(object sender, EventArgs e)
        {

            // ComboBox'ta seçilen rengi alın
            string? secilenRenkAdi = cmbRenk.SelectedItem.ToString();
            if(cmbRenk.SelectedItem ==  null )
            {
                MessageBox.Show("Renk seçmediniz.");
            }
            if(secilenRenkAdi != null)
            {

            Color SecilenRenk = Color.FromArgb(255, 255, 255);

            // Seçilen renk adına göre gerçek renk değerini ayarlayın
            if (secilenRenkAdi == "Red")
            {
                SecilenRenk = Color.Red;
            }
            else if (secilenRenkAdi == "Blue")
            {
                SecilenRenk = Color.Blue;
            }
            else if (secilenRenkAdi == "Green")
            {
                SecilenRenk = Color.Green;
            }
            else if (secilenRenkAdi == "AliceBlue")
            {
                SecilenRenk = Color.AliceBlue;
            }

            this.Close();
            }
            



        }
    }
}
