namespace soru2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRenkSec_Click(object sender, EventArgs e)
        {
            form2 form2 = new form2();
            form2.ShowDialog();

            // Form2'den d�nen rengi kontrol edin
            if (form2.SecilenRenk != null)
            {
                this.BackColor = (Color)form2.SecilenRenk;
            }
        }
    }
}