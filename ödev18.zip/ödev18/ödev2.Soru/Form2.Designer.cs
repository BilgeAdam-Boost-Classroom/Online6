﻿namespace ödev2.Soru
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbRenk = new ComboBox();
            btnRenk = new Button();
            btnİptal = new Button();
            SuspendLayout();
            // 
            // cmbRenk
            // 
            cmbRenk.FormattingEnabled = true;
            cmbRenk.Items.AddRange(new object[] { "Renk Seçin", "AliceBlue", "Red", "Green", "Blue" });
            cmbRenk.Location = new Point(65, 74);
            cmbRenk.Name = "cmbRenk";
            cmbRenk.Size = new Size(187, 23);
            cmbRenk.TabIndex = 0;
            cmbRenk.SelectedIndexChanged += cmbRenk_SelectedIndexChanged;
            // 
            // btnRenk
            // 
            btnRenk.Location = new Point(65, 124);
            btnRenk.Name = "btnRenk";
            btnRenk.Size = new Size(75, 23);
            btnRenk.TabIndex = 1;
            btnRenk.Text = "button1";
            btnRenk.UseVisualStyleBackColor = true;
            btnRenk.Click += btnRenk_Click;
            // 
            // btnİptal
            // 
            btnİptal.Location = new Point(177, 124);
            btnİptal.Name = "btnİptal";
            btnİptal.Size = new Size(75, 23);
            btnİptal.TabIndex = 2;
            btnİptal.Text = "button2";
            btnİptal.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(308, 187);
            Controls.Add(btnİptal);
            Controls.Add(btnRenk);
            Controls.Add(cmbRenk);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbRenk;
        private Button btnRenk;
        private Button btnİptal;
    }
}