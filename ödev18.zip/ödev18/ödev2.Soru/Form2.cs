﻿namespace ödev2.Soru
{
    public partial class Form2 : Form
    {
        public Color SecilenRenk { get; private set; }

        public Form2()
        {
            InitializeComponent();
            cmbRenk.SelectedIndex = 0;
        }

        private void tamamButton_Click(object sender, EventArgs e)
        {
            // ComboBox'ta seçilen rengi alın
            string? secilenRenkAdi = cmbRenk.SelectedItem.ToString();

            // Seçilen renk adına göre gerçek renk değerini ayarlayın
            if (secilenRenkAdi == "Kırmızı")
            {
                SecilenRenk = Color.Red;
            }
            else if (secilenRenkAdi == "Mavi")
            {
                SecilenRenk = Color.Blue;
            }
            else if (secilenRenkAdi == "Yeşil")
            {
                SecilenRenk = Color.Green;
            }
            else if (secilenRenkAdi == "Sarı")
            {
                SecilenRenk = Color.Yellow;
            }

            this.Close();
        }

        private void cmbRenk_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnRenk_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();

        }
    }
}