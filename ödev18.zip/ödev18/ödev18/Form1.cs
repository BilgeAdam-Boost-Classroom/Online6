namespace ödev18
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string password = txtSifre.Text;
                if (password.Length <= 6)
                {
                    lblUyari.Text = "Düşük";
                    lblUyari.ForeColor = Color.Red;
                }
                else if (password.All(char.IsDigit) || alfabetikMi(password))
                {
                    lblUyari.Text = "Düşük";
                    lblUyari.ForeColor = Color.Red;

                }
                else if (password.Length == 7 && (!(password.All(char.IsDigit) || alfabetikMi(password))))
                    {

                    lblUyari.Text = "Orta";
                    lblUyari.ForeColor = Color.Orange;

                }
                else if(password.Length>=8 && (!(password.All(char.IsDigit) || alfabetikMi(password))))
                {
                    lblUyari.Text = "Yüksek";
                    lblUyari.ForeColor = Color.Green;
                }
                else if (password.Contains(" "))
                {
                    lblUyari.Text = "parola boşluk içeremez.";
                }
            }

            catch (Exception ex)
            {

                MessageBox.Show("bilinmeyen bir hata oluştu " + ex);
            }

        }


        private bool alfabetikMi(string text)
        {
            foreach (char c in text)
            {
                if (!char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }
    }
}