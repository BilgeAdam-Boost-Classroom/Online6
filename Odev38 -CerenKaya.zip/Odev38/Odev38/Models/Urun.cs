﻿namespace Odev38.Models
{
    public class Urun
    {
        private static Random rnd = new Random();
        public int Numara { get; set; } = rnd.Next();



    }
}
