﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Odev45.Data;
using Odev45.Models;

namespace Odev45.Controllers
{
    public class HayvansController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HayvansController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Hayvans
        public async Task<IActionResult> Index()
        {
            return View(await _context.Hayvanlar.ToListAsync());
        }

        // GET: Hayvans/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvanlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }
           
            return View(hayvan);
        }

        // GET: Hayvans/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Hayvans/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(HayvanViewModel hayvanViewModel)
        {       
            try
            {
                Hayvan yeniHayvan = new Hayvan();

                if (ModelState.IsValid)
                {
                    if (hayvanViewModel.Resim != null)
                    {
                        var dosyaAdi = hayvanViewModel.Resim.FileName;

                        var konum = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/css/resimler", dosyaAdi);

                        var akisOrtami = new FileStream(konum, FileMode.Create);

                        hayvanViewModel.Resim.CopyTo(akisOrtami);

                        akisOrtami.Close();

                     
                        yeniHayvan.Resim = hayvanViewModel.Resim.FileName;

                    }

                    yeniHayvan.Ad = hayvanViewModel.Ad;
                    _context.Add(yeniHayvan);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index");

                }
                else return View();
            }
            catch (Exception ex)
            {
                TempData["Durum"] = "Hata oluştu! " + ex.Message;
                return View();
            }         
        }

        // GET: Hayvanlar/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvanlar.FindAsync(id);
            if (hayvan == null)
            {
                return NotFound();
            }

            HayvanViewModel hayvanViewModel = new HayvanViewModel
            {
                Ad = hayvan.Ad,
            };
            TempData["Id"] = hayvan.Id;
            return View(hayvanViewModel);
        }

        // POST: Hayvans/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(HayvanViewModel hayvanViewModel)
        {
            Hayvan guncellenecek = _context.Hayvanlar.Find(TempData["Id"]);
            

            if (hayvanViewModel == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
               
                    if(hayvanViewModel.Resim != null && hayvanViewModel.Resim.FileName != guncellenecek.Resim)
                    { 

                    ResimSil(guncellenecek);
                    var dosyaAdi = hayvanViewModel.Resim.FileName;

                    var konum = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/css/resimler", dosyaAdi);

                    var akisOrtami = new FileStream(konum, FileMode.Create);

                    hayvanViewModel.Resim.CopyTo(akisOrtami);

                    akisOrtami.Close();
                    guncellenecek.Resim = hayvanViewModel.Resim.FileName;

                    _context.Update(guncellenecek);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Index");
                    }           

            }
            return View(hayvanViewModel);
        }

        public void ResimSil(Hayvan hayvan)
        {
            //Bu resmi kullanan BAŞKA (KENDİSİ DIŞINDA) ürün var mı?
            var resmiKullananBaskaVarMi = _context.Hayvanlar.Any(u => u.Resim == hayvan.Resim && u.Id != hayvan.Id);

            if (hayvan.Resim != null && !resmiKullananBaskaVarMi)
            {
                //o resmin tam adını (patikasıyla beraber) getir.

                string dosya = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/css/Resimler", hayvan.Resim);

                //Silme metoduna bu patikayı gönder.
                System.IO.File.Delete(dosya);
            }

        }

        // GET: Hayvans/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hayvan = await _context.Hayvanlar
                .FirstOrDefaultAsync(m => m.Id == id);
            if (hayvan == null)
            {
                return NotFound();
            }

            return View(hayvan);
        }

        // POST: Hayvans/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var hayvan = await _context.Hayvanlar.FindAsync(id);
            if (hayvan != null)
            {
                _context.Hayvanlar.Remove(hayvan);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HayvanExists(int id)
        {
            return _context.Hayvanlar.Any(e => e.Id == id);
        }
    }
}
