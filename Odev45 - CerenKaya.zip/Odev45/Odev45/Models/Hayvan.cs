﻿namespace Odev45.Models
{
    public class Hayvan
    {
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Resim { get; set; }
    }
}
