﻿namespace Odev45.Models
{
    public class HayvanViewModel
    {
        public string Ad { get; set; }
        public IFormFile Resim { get; set; }
    }
}
