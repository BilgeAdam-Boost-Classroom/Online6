﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine("hasan salgin");

for (int i = 0; i < 10; i++)
{
    Console.WriteLine("merhaba" + i);
}

Console.WriteLine("github kontrol"); //github pushlama ve kontrol etme 