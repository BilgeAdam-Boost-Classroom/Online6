﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1
{
    public class BaseKitap
    {
        public virtual void GetLog()
        {
            Console.WriteLine("BaseKitap get log");
        }
        public virtual void GetUser()
        {
            Console.WriteLine("BaseKitap get user");

        }
    }
    public class Kitap:BaseKitap
    {
        public override void GetLog()
        {
            Console.WriteLine("Kitap get log");
        }
        public override sealed void GetUser()
        {
            Console.WriteLine("Kitap get user");

        }

    }
    public class TuremisKitap:Kitap
    {
        public override void GetLog()
        {
            Console.WriteLine("TuremisKitap get log");
        }
        public override void GetUser()
        {
            Console.WriteLine("TuremisKitap get user");

        }

    }
}
