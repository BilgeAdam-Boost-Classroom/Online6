﻿
using Soru2;
using System;

List<IPiece> taslar = new List<IPiece>();
Random rnd = new Random();
string secim;

do
{
    IPiece tas;
    int randomColor = rnd.Next(2);
    int randomPiece = rnd.Next(6);

    if (randomPiece == 0)
    {
        tas = new Pawn
        {
            Name = "Piyon",
            Color = (PieceColor)randomColor
        };
    }
    else if (randomPiece == 1)
    {
        tas = new Rook
        {
            Name = "Kale",
            Color = (PieceColor)randomColor
        };
    }
    else if (randomPiece == 2)
    {
        tas = new Knight
        {
            Name = "At",
            Color = (PieceColor)randomColor
        };
    }
    else if (randomPiece == 3)
    {
        tas = new Bishop
        {
            Name = "Fil",
            Color = (PieceColor)randomColor
        };
    }
    else if (randomPiece == 4)
    {
        tas = new Queen
        {
            Name = "Vezir",
            Color = (PieceColor)randomColor
        };
    }
    else
    {
        tas = new King
        {
            Name = "Şah",
            Color = (PieceColor)randomColor
        };
    }
    taslar.Add(tas);

    Console.WriteLine("Satranc tasi listeye eklendi. Cikmak icin H/h basiniz. Devam etmek icin herhangi bir tusa basiniz: ");
    secim = Console.ReadLine();

} while (secim.ToUpper() == "H");


var pieceCounts = taslar.GroupBy(x => x.GetType().Name).ToDictionary(g => g.Key, g => g.Count());

foreach (IPiece tas in taslar)
{
    Console.WriteLine("Name: " + tas.Name);
    Console.WriteLine("Color: " + tas.Color);

    tas.Move();

    if (tas is Pawn pawn)
    {
        pawn.Promote();
    }

    string pieceName = tas.GetType().Name;
    if (pieceCounts.ContainsKey(pieceName))
    {
        pieceCounts[pieceName]++;
    }
    else
    {
        pieceCounts.Add(pieceName, 1);
    }
}

string enCokTekrarEdenTas = string.Empty;
int maxCount = 0;

foreach (var item in pieceCounts)
{
    if (item.Value > maxCount)
    {
        maxCount = item.Value;
        enCokTekrarEdenTas = item.Key;
    }
}

Console.WriteLine("En cok tekrar eden tas: " + enCokTekrarEdenTas);

        

Console.ReadKey();
