﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21Uygulama1
{
    public class Kitap : BaseKitap
    {
        public override void GetLog()
        {
            Console.WriteLine("Kitap get log.....");
        }
        public override sealed void GetUser() //Turemis kitap sınıfı bu metodu ezerek kullanamaz!!
        {
            Console.WriteLine("Kitap get user.....");
        }
    }
}
