﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21Uygulama1
{
    public class TuremisKitap : Kitap
    {
        public override void GetLog()
        {
            base.GetLog();
        }
        //public override void GetUser() //Kitap sınıfında sealed keywordü kullanarak bir sonra kendinden miras alan sınıf tarafından ezilmesi engellenmişitr.
        //{
        //    Console.WriteLine("Kitap get user.....");
        //}
    }
}
