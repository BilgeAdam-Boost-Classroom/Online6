﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21Uygulma2
{
    public class Rook : IPiece
    {
        public string Name { get; set; }
        public PieceColors Color { get; set; }

        public void Move()
        {
            Console.WriteLine("\"Ranks and fiels only\"");
        }
    }
}
