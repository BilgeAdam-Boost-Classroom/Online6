﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21Uygulma2
{
    public enum PieceColors 
    {
        Black = 0, //Default olarak 0 degerini almaktadır.
        White =1
    }
}
