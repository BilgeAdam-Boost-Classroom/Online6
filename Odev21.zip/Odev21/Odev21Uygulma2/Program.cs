﻿using System.Drawing;

namespace Odev21Uygulma2
{
    internal class Program
    {
        static Random random = new Random();
        static void Main(string[] args)
        {
            List<IPiece> pieces = new List<IPiece>();
            string statementKey;
            do
            {
                pieces.Add(CreateRandomChessPiece());
                Console.WriteLine("Chess piece added to the list. Press H/h to exit. Press any key to continue.");
                statementKey = Console.ReadLine();
                statementKey = statementKey.ToUpper();

            } while (statementKey != "H");

            Console.WriteLine("You are logged out of the game.");
            Console.WriteLine("Pieces selected by the program for you");
            Console.WriteLine("------------------------------------------");

            foreach (IPiece piece in pieces)
            {
                Console.WriteLine(piece.Name);
                Console.WriteLine(piece.Color);
                piece.Move();
                if (piece.Name == "Piyon")
                {
                    piece.Promote();
                }
                Console.WriteLine("------------------------------------------");
            }
            foreach (IPiece piece in pieces)
            {

            }
            Console.ReadKey();
        }
        public static IPiece CreateRandomChessPiece()
        {
            ChessPieceType randomPieceType = (ChessPieceType)random.Next(0, Enum.GetNames(typeof(ChessPieceType)).Length);
            PieceColors randomPieceColor = (PieceColors)random.Next(0, Enum.GetNames(typeof(PieceColors)).Length);
            switch (randomPieceType)
            {
                case ChessPieceType.King:
                    return new King() { Name = "Şah", Color = randomPieceColor };
                case ChessPieceType.Queen:
                    return new Queen() { Name = "Vezir", Color = randomPieceColor };
                case ChessPieceType.Rook:
                    return new Rook() { Name = "Kale", Color = randomPieceColor };
                case ChessPieceType.Bishop:
                    return new Bishop() { Name = "Fil", Color = randomPieceColor };
                case ChessPieceType.Knight:
                    return new Knight() { Name = "At", Color = randomPieceColor };
                case ChessPieceType.Pawn:
                    return new Pawn() { Name = "Piyon", Color = randomPieceColor };
                default:
                    throw new InvalidOperationException("There is no such chess piece.");
            }
        }

    }
}



