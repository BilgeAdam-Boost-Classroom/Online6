﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev21
{
    public class TuremisKitap : Kitap
    {
        public override void GetLog()
        {
            base.GetLog();
        }

        public override void GetUser()
        {
            base.GetUser();
        }

    }
}
