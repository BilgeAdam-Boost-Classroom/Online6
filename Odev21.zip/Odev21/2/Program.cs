﻿using _2;

List<IPiece> pieces = new List<IPiece>();
int[] adet = new int[6];

while (Console.ReadLine().ToLower() != "h")
{
    int i = new Random().Next(6);
    adet[i]++;
    pieces.Add(i == 0 ? new Pawn() : i == 2 ? new Rook() : i == 3 ? new Knight() : i == 4 ? new Bishop() : i == 5 ? new Queen() : new King());
    Console.WriteLine("Satranç taşı listeye eklendi");
}
foreach (IPiece piece in pieces)
{
    Console.WriteLine(piece.Name+"\n"+piece.Color);
    piece.Move();
    //if(piece.GetType().Name=="Pawn")
    //    ((Pawn)piece).Promote();
    try { ((Pawn)piece).Promote(); }
    catch (Exception) { }
    Console.WriteLine();
}

for (int i = 0; i < adet.Length; i++)
    if (adet[i] == adet.Max())
        Console.WriteLine("En çok tekrar eden: "+(i == 0 ? "Piyon" : i == 2 ? "Kale" : i == 3 ? "At" : i == 4 ? "Fil" : i == 5 ? "Vezir" : "Şah"));

Console.ReadKey();