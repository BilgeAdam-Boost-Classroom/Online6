﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2
{
    public enum PieceColor
    {
        Black = 0, White = 1
    }

    public interface IPiece
    {
        public string Name { get; }
        public PieceColor Color { get; set; }

        public void Move();
    }

    public class Pawn : IPiece
    {
        public string Name => "Piyon";
        public PieceColor Color { get ; set ; } = (PieceColor)new Random().Next(2);

        public void Move() => Console.WriteLine("Two forward at the beginning or one forward");
        public void Promote() => Console.WriteLine("Can promote to rook,knight,bishop or queen");
        
    }
    public class Bishop : IPiece
    {
        public string Name => "Fil";
        public PieceColor Color { get; set; } = (PieceColor)new Random().Next(2);
        public void Move() => Console.WriteLine("Diagonals only");


    }
    public class Rook : IPiece
    {
        public string Name => "Kale";
        public PieceColor Color { get; set; } = (PieceColor)new Random().Next(2);
        public void Move() => Console.WriteLine("Ranks and files only");

    }
    public class Knight : IPiece
    {
        public string Name => "At";
        public PieceColor Color { get; set; } = (PieceColor)new Random().Next(2);
        public void Move() => Console.WriteLine("L shaped only");

    }
    public class Queen : IPiece
    {
        public string Name => "Vezir";
        public PieceColor Color { get; set; } = (PieceColor)new Random().Next(2);
        public void Move() => Console.WriteLine("Rook + Bishop");

    }
    public class King : IPiece
    {
        public string Name => "Şah";
        public PieceColor Color { get; set; } = (PieceColor)new Random().Next(2);
        public void Move() => Console.WriteLine("Rook + Bishop + One");

    }

}
