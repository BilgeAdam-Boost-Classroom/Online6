﻿using Microsoft.EntityFrameworkCore;

namespace Odev48.Data
{
    public class UygulamaDbContext : DbContext
	{
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options) 
        {
            
        }
        public DbSet<Tablo> Tablolar { get; set; }
    }
}
