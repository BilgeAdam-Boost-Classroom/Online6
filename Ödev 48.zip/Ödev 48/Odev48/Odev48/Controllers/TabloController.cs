﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Odev48.Data;

namespace Odev48.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class TabloController : ControllerBase
	{
		private readonly UygulamaDbContext _db;

		public TabloController(UygulamaDbContext db)
        {
			_db = db;
		}
		[HttpGet("{id}")]
		public IActionResult Get2(int id) 
		{
			var tablo= _db.Tablolar.Find(id);
			if(tablo == null)
			{
				return NotFound();
			}
			return Ok(tablo);
		}
		[HttpGet("Tablolar")]
		public IActionResult Get()
		{
			return Ok(_db.Tablolar.ToList());
		}
		[HttpPost]
		public IActionResult Ekle(Tablo tablo)
		{
			if(ModelState.IsValid)
			{
				_db.Tablolar.Add(tablo);
				_db.SaveChanges();
			}
			return Ok("Tablo eklendi");	

		}
		[HttpPut]
		public IActionResult Put(int id,Tablo tablo) 
		{
			if(id != tablo.Id)
				return BadRequest();
			Tablo guncellenecekTablo = _db.Tablolar.FirstOrDefault(x=> x.Id == id)!;
			if(guncellenecekTablo == null)
				return NotFound();
			guncellenecekTablo.Ressam = tablo.Ressam;
			guncellenecekTablo.YapilmaTarihi = tablo.YapilmaTarihi;

			_db.Update(guncellenecekTablo);
			_db.SaveChanges();
			return Ok("Tablo güncellendi");
		}
		[HttpDelete]
		public IActionResult Delete(int id)
		{
			var silinecekTablo = _db.Tablolar.Find(id);
			if(silinecekTablo ==null)
				return NotFound();
			_db.Remove(silinecekTablo);
			_db.SaveChanges();
			return Ok("Tablo silindi");
		}
    }
}
