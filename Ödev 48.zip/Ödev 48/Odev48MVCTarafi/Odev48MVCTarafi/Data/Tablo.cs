﻿namespace Odev48MVCTarafi.Data
{
	public class Tablo
	{
		public int Id { get; set; }
		public string Ressam { get; set; } = null!;
		public DateTime YapilmaTarihi { get; set; }
	}
}
