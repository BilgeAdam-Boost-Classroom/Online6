﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Odev48MVCTarafi.Data;

    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext (DbContextOptions<UygulamaDbContext> options)
            : base(options)
        {
        }

        public DbSet<Odev48MVCTarafi.Data.Tablo> Tablo { get; set; } = default!;
    }
