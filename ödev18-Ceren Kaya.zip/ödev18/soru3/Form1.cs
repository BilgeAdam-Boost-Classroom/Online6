namespace soru3
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();

        }

        public void btnGiris_Click(object sender, EventArgs e)
        {
            if (!(txtAd.Text == "admin" && txtSifre.Text == "1234"))
            {
                MessageBox.Show("parola ad� veya parola hatal� ", "Uyar� Mesaj�", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }

            else
            {
                Form2 form = new Form2();
                form.Show();
                form.Owner = this;




            }
        }

     
    }
}