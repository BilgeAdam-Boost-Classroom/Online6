﻿using Microsoft.AspNetCore.Mvc;
using Odev38.Models;
using System;

namespace Odev38.Controllers
{
    public class UrunController : Controller
    {
        Random rnd = new Random();

        public IActionResult Liste()
        {
            List<Urun> liste = new List<Urun>();
            

            for (int i = 0; i < 5; i++)
            {
                Urun urun = new Urun
                {
                    Numara = rnd.Next(5000), 
                };
                liste.Add(urun);
            }

            return View(liste);
        }
    }
}
