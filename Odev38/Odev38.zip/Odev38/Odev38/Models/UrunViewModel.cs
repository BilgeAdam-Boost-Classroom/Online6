﻿namespace Odev38.Models
{
    public class Urun
    {
        public int Numara { get; set; }
    }
}
