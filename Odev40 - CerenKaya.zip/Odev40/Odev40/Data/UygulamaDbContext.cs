﻿using Microsoft.EntityFrameworkCore;

namespace Odev40.Data
{
    public class UygulamaDbContext : DbContext
    {
        public UygulamaDbContext(DbContextOptions<UygulamaDbContext> options) : base(options) { }

        public DbSet<Oyun> Oyunlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Oyun>().ToTable("Oyunlar");

            modelBuilder.Entity<Oyun>().HasData(
                new Oyun
                {
                    Id = 1,
                    Ad = "Raft",
                    TekPlatform = true
   
                },
                new Oyun
                {
                    Id = 2,
                    Ad = "CS-GO",
                    TekPlatform = true
                },
                new Oyun
                {
                    Id = 3,
                    Ad = "Need For Speed",
                    TekPlatform = false

                },
                new Oyun
                {
                    Id = 4,
                    Ad = "GTA5",
                    TekPlatform = false
                }  
            );

        }
    }
}
