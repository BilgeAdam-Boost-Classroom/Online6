using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using Odev40.Data;
using Odev40.Models;
using System.Diagnostics;

namespace Odev40.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UygulamaDbContext _db;
        public HomeController(ILogger<HomeController> logger, UygulamaDbContext db)
        {
            _db = db;
            _logger = logger;
        }

        public IActionResult Index()
        {
            
            return View(_db.Oyunlar.ToList());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Ekle()
        {
            return View();     
        }

        [HttpPost]
        public IActionResult Ekle(Oyun oyun)
        {
            _db.Oyunlar.Add(oyun);
            _db.SaveChanges();

            return RedirectToAction("Index");  
        }
        public IActionResult Sil(int id)
        {
            Oyun Silinecek = _db.Oyunlar.FirstOrDefault(o => o.Id == id);
            _db.Oyunlar.Remove(Silinecek);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }


        public IActionResult Guncelle(int id)
        {
            Oyun Guncellenecek = _db.Oyunlar.FirstOrDefault(o => o.Id == id);

            return View(Guncellenecek);
        }

        [HttpPost]
        public IActionResult Guncelle(Oyun oyun)
        {
            _db.Oyunlar.Update(oyun);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }




    }
}
