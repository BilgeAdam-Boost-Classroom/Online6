﻿using Microsoft.EntityFrameworkCore;
using ODEV33.Models;
using System.Threading.Channels;

internal class Program
{
    private static void Main(string[] args)
    {
        NorthwndContext db = new NorthwndContext();
        
        /// author: Alican DÖKMEN

        // Tüm employee'leri yazdır.
        Console.WriteLine("--- All Employees ---");
        List<Employee> employeeList = db.Employees.ToList();
        employeeList.ForEach(e => Console.WriteLine(e.FirstName + " " + e.LastName));

        // İlk Employee yi yazdırınız.
        Console.WriteLine("\n--- First Employee ---");
        Employee first = db.Employees.FirstOrDefault()!;
        Console.WriteLine(first.FirstName + " " + first.LastName);

        // Employeeleri , FirstName e göre sıralayıp son employee yi yazdırınız.
        Console.WriteLine("\n--- Employees sorted by FirstName ---");
        List<Employee> sortedList = db.Employees.OrderBy(e => e.FirstName).ToList();
        Employee last = sortedList.Last()!;
        Console.WriteLine("Last employee: " + last.FirstName + " " + last.LastName);

        // İsmi A ile başlayan employee leri listeleyiniz.
        Console.WriteLine("\n--- Employees whose FirstName starts with A ---");
        List<Employee> aList = db.Employees.Where(e => e.FirstName.StartsWith("A")).ToList();
        aList.ForEach(e => Console.WriteLine(e.FirstName + " " + e.LastName));

        // İsmi A ile başlayan ilk Employee yi yazdırınız.
        Console.WriteLine("\n--- First employee whose FirstName starts with A ---");
        Employee aFirst = db.Employees.Where(e => e.FirstName.StartsWith("A")).FirstOrDefault()!;
        Console.WriteLine(aFirst.FirstName + " " + aFirst.LastName);

        // İsmi içerisinde a harfi içeren employeeleri listeleyiniz.
        Console.WriteLine("\n--- Employees whose FirstName contains a ---");
        List<Employee> aContainsList = db.Employees.Where(e => e.FirstName.Contains("a")).ToList();
        aContainsList.ForEach(e => Console.WriteLine(e.FirstName + " " + e.LastName));

        // İsmi içerisinde a harfi içeren ilk employee yi yazdırınız.
        Console.WriteLine("\n--- First employee whose FirstName contains a ---");
        Employee aContainsFirst = db.Employees.Where(e => e.FirstName.Contains("a")).FirstOrDefault()!;
        Console.WriteLine(aContainsFirst.FirstName + " " + aContainsFirst.LastName);

        // Adı Andrew olan employee leri yazdırınız.
        Console.WriteLine("\n--- Employees whose FirstName is Andrew ---"); 
        List<Employee> andrewList = db.Employees.Where(e => e.FirstName == "Andrew").ToList();
        andrewList.ForEach(e => Console.WriteLine(e.FirstName + " " + e.LastName));

        // En pahalı productı yazdırınız.
        Console.WriteLine("\n--- Most expensive product ---");
        Product mostExpensive = db.Products.OrderByDescending(p => p.UnitPrice).FirstOrDefault()!;
        Console.WriteLine(mostExpensive.ProductName + " " + mostExpensive.UnitPrice);

        // En ucuz productı yazdırınız.
        Console.WriteLine("\n--- Cheapest product ---");
        Product cheapest = db.Products.OrderBy(p => p.UnitPrice).FirstOrDefault()!;
        Console.WriteLine(cheapest.ProductName + " " + cheapest.UnitPrice);

        // Fiyatı ortalama fiyat üzerinde olan ürünleri yazdırınız.
        Console.WriteLine("\n--- Products whose price is above average ---");
        Console.WriteLine("Avg Price:" + db.Products.Average(p => p.UnitPrice));
        Console.WriteLine("");
        List<Product> aboveAverage = db.Products.OrderBy(p => p.UnitPrice).Where(p => p.UnitPrice > db.Products.Average(p => p.UnitPrice)).ToList();
        aboveAverage.ForEach(p => Console.WriteLine(p.ProductName + " " + p.UnitPrice));

        // Product ları Stock sayısına göre sıralayınız.
        Console.WriteLine("\n--- Products sorted by Stock ---");
        List<Product> sortedByStock = db.Products.OrderBy(p => p.UnitsInStock).ToList();
        sortedByStock.ForEach(p => Console.WriteLine(p.ProductName + " " + p.UnitsInStock));

        // Product ları önce Stock sayısına göre sonra ProductName e göre büyükten küçüğe sıralayın. (iki sıralama da büyükten küçüğe olmalıdır)
        Console.WriteLine("\n--- Products sorted by Stock then by ProductName ---");
        List<Product> sortedByStockThenName = db.Products.OrderByDescending(p => p.UnitsInStock).ThenByDescending(p => p.ProductName).ToList();
        sortedByStockThenName.ForEach(p => Console.WriteLine(p.ProductName + " " + p.UnitsInStock));

        // Order detaillarda, order bazında toplam satış tutarı 500 ve altında olan orderid'leri getirip, toplam tutara göre sıralayınız.

        Console.WriteLine("\n--- Orders whose total price is below 500 ---");
        List<OrderDetail> orderDetails = db.OrderDetails.Include(od => od.Order).ToList();
        List<Order> orders = db.Orders.ToList();
        List<Order> ordersBelow500 = orders.Where(o => orderDetails.Where(od => od.OrderId == o.OrderId).Sum(od => od.UnitPrice * od.Quantity) <= 500).ToList();
        ordersBelow500.ForEach(o => Console.WriteLine(o.OrderId + " " + orderDetails.Where(od => od.OrderId == o.OrderId).Sum(od => od.UnitPrice * od.Quantity)));

        // Tüm product ları category leri ile birlikte listeleyiniz.
        Console.WriteLine("\n--- Products with their categories ---");
        List<Product> products = db.Products.Include(p => p.Category).ToList();
        products.ForEach(p => Console.WriteLine(p.ProductName + " " + p.Category.CategoryName));

        // ProductName, CategoryName, Suplier'ın CompanyName 'ini ile birlikte yazdırınız. 
        Console.WriteLine("\n--- Products with their categories and suppliers ---");
        List<Product> productsWithCategoriesAndSuppliers = db.Products.Include(p => p.Category).Include(p => p.Supplier).ToList();
        productsWithCategoriesAndSuppliers.ForEach(p => Console.WriteLine(p.ProductName + " " + p.Category.CategoryName + " " + p.Supplier.CompanyName));


        Console.ReadLine();
    }
}