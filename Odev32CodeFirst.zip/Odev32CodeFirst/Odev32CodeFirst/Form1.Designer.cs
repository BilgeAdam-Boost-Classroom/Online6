﻿namespace Odev32CodeFirst
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtId = new TextBox();
            label2 = new Label();
            txtAd = new TextBox();
            label3 = new Label();
            txtKod = new TextBox();
            label4 = new Label();
            txtNot = new TextBox();
            label5 = new Label();
            txtKredi = new TextBox();
            btnEkle = new Button();
            btnGuncelle = new Button();
            btnSil = new Button();
            dgvDersler = new DataGridView();
            btnOrtalama = new Button();
            btnIstatistik = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvDersler).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(15, 18);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 17;
            label1.Text = "Ders ID";
            // 
            // txtId
            // 
            txtId.Location = new Point(99, 15);
            txtId.Name = "txtId";
            txtId.Size = new Size(186, 27);
            txtId.TabIndex = 16;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 71);
            label2.Name = "label2";
            label2.Size = new Size(66, 20);
            label2.TabIndex = 19;
            label2.Text = "Ders Adi";
            // 
            // txtAd
            // 
            txtAd.Location = new Point(99, 71);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(186, 27);
            txtAd.TabIndex = 18;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(15, 132);
            label3.Name = "label3";
            label3.Size = new Size(78, 20);
            label3.TabIndex = 21;
            label3.Text = "Ders Kodu";
            // 
            // txtKod
            // 
            txtKod.Location = new Point(99, 129);
            txtKod.Name = "txtKod";
            txtKod.Size = new Size(186, 27);
            txtKod.TabIndex = 20;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(15, 196);
            label4.Name = "label4";
            label4.Size = new Size(75, 20);
            label4.TabIndex = 23;
            label4.Text = "Harf Notu";
            // 
            // txtNot
            // 
            txtNot.Location = new Point(99, 193);
            txtNot.Name = "txtNot";
            txtNot.Size = new Size(186, 27);
            txtNot.TabIndex = 22;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(15, 260);
            label5.Name = "label5";
            label5.Size = new Size(54, 20);
            label5.TabIndex = 25;
            label5.Text = "Kredisi";
            // 
            // txtKredi
            // 
            txtKredi.Location = new Point(99, 257);
            txtKredi.Name = "txtKredi";
            txtKredi.Size = new Size(186, 27);
            txtKredi.TabIndex = 24;
            // 
            // btnEkle
            // 
            btnEkle.Location = new Point(21, 321);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(94, 29);
            btnEkle.TabIndex = 26;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = true;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.Location = new Point(191, 321);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(94, 29);
            btnGuncelle.TabIndex = 27;
            btnGuncelle.Text = "GÜNCELLE";
            btnGuncelle.UseVisualStyleBackColor = true;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // btnSil
            // 
            btnSil.Location = new Point(109, 376);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(94, 29);
            btnSil.TabIndex = 28;
            btnSil.Text = "KALDIR/SIL";
            btnSil.UseVisualStyleBackColor = true;
            btnSil.Click += btnSil_Click;
            // 
            // dgvDersler
            // 
            dgvDersler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDersler.Location = new Point(301, 17);
            dgvDersler.Name = "dgvDersler";
            dgvDersler.RowHeadersWidth = 51;
            dgvDersler.Size = new Size(569, 388);
            dgvDersler.TabIndex = 29;
            dgvDersler.SelectionChanged += dgvDersler_SelectionChanged;
            // 
            // btnOrtalama
            // 
            btnOrtalama.Location = new Point(893, 132);
            btnOrtalama.Name = "btnOrtalama";
            btnOrtalama.Size = new Size(126, 69);
            btnOrtalama.TabIndex = 30;
            btnOrtalama.Text = "ORTALAMA HESAPLA";
            btnOrtalama.UseVisualStyleBackColor = true;
            btnOrtalama.Click += btnOrtalama_Click;
            // 
            // btnIstatistik
            // 
            btnIstatistik.Location = new Point(893, 207);
            btnIstatistik.Name = "btnIstatistik";
            btnIstatistik.Size = new Size(126, 69);
            btnIstatistik.TabIndex = 31;
            btnIstatistik.Text = "ISTATISTIKLERI GÖSTER";
            btnIstatistik.UseVisualStyleBackColor = true;
            btnIstatistik.Click += btnIstatistik_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1039, 428);
            Controls.Add(btnIstatistik);
            Controls.Add(btnOrtalama);
            Controls.Add(dgvDersler);
            Controls.Add(btnSil);
            Controls.Add(btnGuncelle);
            Controls.Add(btnEkle);
            Controls.Add(label5);
            Controls.Add(txtKredi);
            Controls.Add(label4);
            Controls.Add(txtNot);
            Controls.Add(label3);
            Controls.Add(txtKod);
            Controls.Add(label2);
            Controls.Add(txtAd);
            Controls.Add(label1);
            Controls.Add(txtId);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvDersler).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtId;
        private Label label2;
        private TextBox txtAd;
        private Label label3;
        private TextBox txtKod;
        private Label label4;
        private TextBox txtNot;
        private Label label5;
        private TextBox txtKredi;
        private Button btnEkle;
        private Button btnGuncelle;
        private Button btnSil;
        private DataGridView dgvDersler;
        private Button btnOrtalama;
        private Button btnIstatistik;
    }
}
