﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odev32CodeFirst
{
    public class Odev32DbContext : DbContext
    {
        public DbSet<Ders> Dersler { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("server=.;database=Odev32OkulDb;trusted_connection=true;TrustServerCertificate=True");
        }
    }
}
