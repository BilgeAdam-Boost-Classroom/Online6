﻿
namespace Odev32CodeFirst
{
    public partial class Form1 : Form
    {
        Odev32DbContext db = new Odev32DbContext();

        public Form1()
        {
            InitializeComponent();
            VerileriYukle();
        }

        private void VerileriYukle()
        {
            dgvDersler.DataSource = db.Dersler.ToList();

        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            db.Dersler.Add(new Ders() { Ad = txtAd.Text, Kod = txtKod.Text, HarfNotu = txtNot.Text, Kredi = Convert.ToInt32(txtKredi.Text) });
            db.SaveChanges();

            VerileriYukle();
            MessageBox.Show("Ders eklendi.");
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            int id;
            if (int.TryParse(txtId.Text, out id))
            {
                Ders silinecek = db.Dersler.Find(id);

                if (silinecek != null)
                {
                    db.Dersler.Remove(silinecek);
                    db.SaveChanges();
                    VerileriYukle();
                    MessageBox.Show("Ders kaldırıldı.");
                }
                else
                {
                    MessageBox.Show("Belirtilen ID'ye sahip ders bulunamadı.");
                }
            }
            else
            {
                MessageBox.Show("Geçersiz ID formatı.");
            }
        }

        private void dgvDersler_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDersler.SelectedRows.Count == 0)
                return;
            Ders seciliDers = ((Ders)dgvDersler.SelectedRows[0].DataBoundItem);
            txtAd.Text = seciliDers.Ad;
            txtKod.Text = seciliDers.Kod;
            txtNot.Text = seciliDers.HarfNotu;
            txtKredi.Text = seciliDers.Kredi.ToString();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvDersler.SelectedRows.Count == 0)
                return;

            int id = ((Ders)dgvDersler.SelectedRows[0].DataBoundItem).Id;
            Ders guncellenecekDers = db.Dersler.Find(id);

            if (guncellenecekDers != null)
            {
                guncellenecekDers.Ad = txtAd.Text;
                guncellenecekDers.Kod = txtKod.Text;
                guncellenecekDers.HarfNotu = txtNot.Text;
                guncellenecekDers.Kredi = Convert.ToInt32(txtKredi.Text);

                db.SaveChanges();
                VerileriYukle();
                MessageBox.Show("Ders güncellendi.");
            }
        }

        private double HarfNotKatsayisi(string harfNotu)
        {
            switch (harfNotu)
            {
                case "A":
                    return 4.0;
                case "B":
                    return 3.5;
                case "C":
                    return 2.0;
                case "D":
                    return 1.0;
                case "F":
                    return 0.0;
                default:
                    return 0.0;
            }
        }

        private void btnOrtalama_Click(object sender, EventArgs e)
        {
            double toplamKredi = 0;
            double toplamNotKatsayisi = 0;

            foreach (Ders ders in db.Dersler.ToList())
            {
                double dersNotKatsayisi = HarfNotKatsayisi(ders.HarfNotu);
                toplamKredi += ders.Kredi;
                toplamNotKatsayisi += ders.Kredi * dersNotKatsayisi;
            }

            if (toplamKredi > 0)
            {
                double ortalama = toplamNotKatsayisi / toplamKredi;
                MessageBox.Show($"Ortalama: {ortalama}");
            }
            else
            {
                MessageBox.Show("Dersler bulunamadı veya toplam kredi sıfır.");
            }
        }

        private void btnIstatistik_Click(object sender, EventArgs e)
        {
            int toplamDersSayisi = db.Dersler.Count();
            int basariliDersSayisi = db.Dersler.Count(d => d.HarfNotu == "A" || d.HarfNotu == "B" || d.HarfNotu == "C");
            int basarisizDersSayisi = db.Dersler.Count(d => d.HarfNotu == "F");
            int sinamaliDersSayisi = db.Dersler.Count(d => d.HarfNotu == "D");

            MessageBox.Show($"Toplam Ders Sayısı: {toplamDersSayisi}\nBaşarılı Ders Sayısı: {basariliDersSayisi}\nBaşarısız Ders Sayısı: {basarisizDersSayisi}\nSınamalı Ders Sayısı: {sinamaliDersSayisi}");
        }
    }
}
