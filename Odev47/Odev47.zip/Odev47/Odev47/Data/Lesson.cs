﻿namespace Odev47.Data
{
    public class Lesson
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public int Credit { get; set; }
    }
}
